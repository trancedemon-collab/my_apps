#!/usr/bin/env bash
X="$1"
Y="$2"
if [ -z "$X" ] || [ -z "$Y" ]; then
  echo "Usage: $0 <X> <Y>"
  exit 1
fi
ydotool mousemove --absolute -x "$X" -y "$Y"
sleep 0.1
ydotool click 0xC0
echo "Clicked at X=$X, Y=$Y"
