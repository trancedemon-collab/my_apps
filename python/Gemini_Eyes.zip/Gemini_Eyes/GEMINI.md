# Gemini Eyes - Wayland Analog Visual Automation Bridge

This directory contains helper scripts and assets for interacting with the KDE Plasma Wayland desktop visually.

## Operational Workflow
Whenever the user instructs you to find or click an element on the screen:
1. **Capture:** Execute `./capture.sh` to take a headless screenshot (`captures/screen_latest.png`).
2. **Inspect:** Read and visually inspect `captures/screen_latest.png`.
3. **Estimate:** Determine the center pixel coordinates `(X, Y)` of the requested target element based on the image dimensions.
4. **Click:** Execute `./click.sh X Y` to move the mouse cursor to absolute coordinates `(X, Y)` and perform a left click.
