#!/usr/bin/env bash
cd "$(dirname "$0")"
mkdir -p captures
spectacle -b -n -o "captures/screen_latest.png"
echo "$(pwd)/captures/screen_latest.png"
