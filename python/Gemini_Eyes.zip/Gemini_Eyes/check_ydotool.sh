#!/usr/bin/env bash
if ! systemctl --user is-active --quiet ydotoold; then
  echo "Starting ydotoold user service..."
  systemctl --user start ydotoold
else
  echo "ydotoold is already active."
fi
