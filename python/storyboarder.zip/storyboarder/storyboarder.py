#!/usr/bin/env python3
import sys
import os
import json
import datetime
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, 
    QHBoxLayout, QSplitter, QListWidget, QLineEdit, QPushButton, 
    QComboBox, QLabel, QMessageBox, QFrame, QDialog, QFormLayout, 
    QListWidgetItem, QFileDialog, QPlainTextEdit, QTextEdit, QInputDialog,
    QGridLayout, QScrollArea, QSizePolicy
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont, QKeySequence, QShortcut, QColor

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "storyboarder_data")

def sanitize_filename(name):
    return "".join(c if c.isalnum() or c in (' ', '_', '-') else '_' for c in name).strip().replace(' ', '_')

def get_timestamp():
    now = datetime.datetime.now()
    return now.strftime("%Y%m%d_%H%M%S")

class StoryboarderApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Storyboarder - AI Video Prompt Studio")
        self.resize(1300, 800)
        
        if not os.path.exists(DATA_DIR):
            os.makedirs(DATA_DIR, exist_ok=True)

        self.projects = self.load_all_projects()
        self.current_project_id = None
        self.current_clip_id = None
        self.current_category_id = None
        self.is_updating_ui = False

        self.init_ui()
        self.apply_kde_styling()
        self.load_projects_to_combo()

    def load_all_projects(self):
        projects = []
        if os.path.exists(DATA_DIR):
            for filename in os.listdir(DATA_DIR):
                if filename.endswith(".json") and filename.startswith("storyboarder_data_"):
                    filepath = os.path.join(DATA_DIR, filename)
                    try:
                        with open(filepath, "r", encoding="utf-8") as f:
                            proj = json.load(f)
                            if "id" in proj and "name" in proj and "clips" in proj:
                                proj["_filename"] = filename
                                projects.append(proj)
                    except Exception as e:
                        print(f"Error loading {filename}: {e}")
        return projects

    def save_current_project(self):
        proj = self.get_current_project()
        if not proj:
            return
        
        if "_filename" not in proj or not proj["_filename"]:
            ts = proj.get("created_at", get_timestamp())
            proj["_filename"] = f"storyboarder_data_{sanitize_filename(proj['name'])}_{ts}.json"
        
        filepath = os.path.join(DATA_DIR, proj["_filename"])
        try:
            data_to_save = {k: v for k, v in proj.items() if not k.startswith("_")}
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(data_to_save, f, indent=4)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save project: {e}")

    def apply_kde_styling(self):
        stylesheet = """
            QMainWindow {
                background-color: #1e1e1e;
                color: #f0f0f0;
            }
            QWidget {
                background-color: #2b2b2b;
                color: #f0f0f0;
                font-family: 'Segoe UI', 'Sans-Serif';
                font-size: 10pt;
            }
            QPushButton {
                background-color: #3a3a3a;
                border: 1px solid #555555;
                border-radius: 4px;
                padding: 5px 10px;
                color: #f0f0f0;
            }
            QPushButton:hover {
                background-color: #4a4a4a;
                border: 1px solid #666666;
            }
            QPushButton:pressed {
                background-color: #2a2a2a;
            }
            QComboBox, QLineEdit, QPlainTextEdit, QTextEdit, QListWidget {
                background-color: #222222;
                border: 1px solid #444444;
                border-radius: 4px;
                padding: 6px;
                color: #ffffff;
            }
            QComboBox::drop-down {
                border: 0px;
            }
            QListWidget::item {
                padding: 6px 8px;
                border-bottom: 1px solid #333333;
                border-radius: 3px;
            }
            QListWidget::item:selected {
                background-color: #3daee9;
                color: #ffffff;
            }
            QLabel {
                background-color: transparent;
                color: #cccccc;
                font-weight: bold;
            }
            QSplitter::handle {
                background-color: #444444;
            }
        """
        self.setStyleSheet(stylesheet)

    def init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(8, 8, 8, 8)
        main_layout.setSpacing(8)

        # --- Compact Top Control Bar ---
        top_bar_widget = QWidget()
        top_bar_widget.setFixedHeight(45)
        top_bar_layout = QHBoxLayout(top_bar_widget)
        top_bar_layout.setContentsMargins(0, 0, 0, 0)
        top_bar_layout.setSpacing(6)

        proj_label = QLabel("Project:")
        self.project_combo = QComboBox()
        self.project_combo.currentIndexChanged.connect(self.on_project_changed)
        
        btn_new_proj = QPushButton("New")
        btn_new_proj.setToolTip("Create New Project")
        btn_new_proj.clicked.connect(self.create_new_project)

        btn_rename_proj = QPushButton("Rename")
        btn_rename_proj.setToolTip("Rename Current Project")
        btn_rename_proj.clicked.connect(self.rename_current_project)
        
        btn_del_proj = QPushButton("Delete")
        btn_del_proj.setToolTip("Delete Current Project")
        btn_del_proj.clicked.connect(self.delete_current_project)

        clip_label = QLabel("Clip:")
        self.clip_combo = QComboBox()
        self.clip_combo.currentIndexChanged.connect(self.on_clip_changed)
        
        btn_new_clip = QPushButton("New")
        btn_new_clip.setToolTip("Create New Clip")
        btn_new_clip.clicked.connect(self.create_new_clip)

        btn_rename_clip = QPushButton("Rename")
        btn_rename_clip.setToolTip("Rename Current Clip")
        btn_rename_clip.clicked.connect(self.rename_current_clip)
        
        btn_del_clip = QPushButton("Delete")
        btn_del_clip.setToolTip("Delete Current Clip")
        btn_del_clip.clicked.connect(self.delete_current_clip)

        btn_nuke = QPushButton("Nuke DB")
        btn_nuke.setStyleSheet("background-color: #8b0000; color: white;")
        btn_nuke.clicked.connect(self.nuke_database)

        top_bar_layout.addWidget(proj_label)
        top_bar_layout.addWidget(self.project_combo, 2)
        top_bar_layout.addWidget(btn_new_proj)
        top_bar_layout.addWidget(btn_rename_proj)
        top_bar_layout.addWidget(btn_del_proj)

        top_bar_layout.addSpacing(10)

        top_bar_layout.addWidget(clip_label)
        top_bar_layout.addWidget(self.clip_combo, 2)
        top_bar_layout.addWidget(btn_new_clip)
        top_bar_layout.addWidget(btn_rename_clip)
        top_bar_layout.addWidget(btn_del_clip)

        top_bar_layout.addSpacing(10)
        top_bar_layout.addWidget(btn_nuke)

        main_layout.addWidget(top_bar_widget)

        # --- 3-Panel Layout ---
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setHandleWidth(6)

        # 1. Left Panel: Categories
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(2, 2, 2, 2)
        left_layout.setSpacing(6)
        
        left_header = QLabel("Categories (Toggle Enable/Disable)")
        self.cat_list_widget = QListWidget()
        self.cat_list_widget.currentRowChanged.connect(self.on_category_selected)
        self.cat_list_widget.itemDoubleClicked.connect(self.toggle_category_enabled_by_item)

        cat_btn_layout = QHBoxLayout()
        btn_add_cat = QPushButton("Add")
        btn_add_cat.clicked.connect(self.add_category)
        btn_rename_cat = QPushButton("Rename")
        btn_rename_cat.clicked.connect(self.rename_category)
        btn_toggle_cat = QPushButton("Enable/Disable")
        btn_toggle_cat.clicked.connect(self.toggle_category_enabled_current)
        btn_del_cat = QPushButton("Delete")
        btn_del_cat.clicked.connect(self.delete_category)

        cat_btn_layout.addWidget(btn_add_cat)
        cat_btn_layout.addWidget(btn_rename_cat)
        cat_btn_layout.addWidget(btn_toggle_cat)
        cat_btn_layout.addWidget(btn_del_cat)

        cat_order_layout = QHBoxLayout()
        btn_up_cat = QPushButton("▲ Move Up")
        btn_up_cat.clicked.connect(lambda: self.move_category(-1))
        btn_down_cat = QPushButton("▼ Move Down")
        btn_down_cat.clicked.connect(lambda: self.move_category(1))

        cat_order_layout.addWidget(btn_up_cat)
        cat_order_layout.addWidget(btn_down_cat)

        left_layout.addWidget(left_header)
        left_layout.addWidget(self.cat_list_widget)
        left_layout.addLayout(cat_btn_layout)
        left_layout.addLayout(cat_order_layout)

        # 2. Center Panel: Category Content Editor
        center_widget = QWidget()
        center_layout = QVBoxLayout(center_widget)
        center_layout.setContentsMargins(2, 2, 2, 2)
        center_layout.setSpacing(6)

        self.center_header_label = QLabel("Select a category to edit content")
        self.content_editor = QPlainTextEdit()
        self.content_editor.setPlaceholderText("Enter category content, details, or prompt components here...")
        self.content_editor.textChanged.connect(self.on_content_changed)

        center_layout.addWidget(self.center_header_label)
        center_layout.addWidget(self.content_editor)

        # 3. Right Panel: Markdown Prompt Output
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(2, 2, 2, 2)
        right_layout.setSpacing(6)

        right_header = QLabel("Final Markdown Prompt Output")
        self.markdown_output = QTextEdit()
        self.markdown_output.setReadOnly(True)
        self.markdown_output.setPlaceholderText("Markdown prompt output will appear here...")

        right_layout.addWidget(right_header)
        right_layout.addWidget(self.markdown_output)

        splitter.addWidget(left_widget)
        splitter.addWidget(center_widget)
        splitter.addWidget(right_widget)
        splitter.setSizes([320, 480, 500])

        main_layout.addWidget(splitter)

    # --- Project & Clip Management Helpers ---

    def get_current_project(self):
        for proj in self.projects:
            if proj["id"] == self.current_project_id:
                return proj
        return None

    def get_current_clip(self):
        proj = self.get_current_project()
        if proj:
            for clip in proj["clips"]:
                if clip["id"] == self.current_clip_id:
                    return clip
        return None

    def get_current_category(self):
        clip = self.get_current_clip()
        if clip:
            for cat in clip["categories"]:
                if cat["id"] == self.current_category_id:
                    return cat
        return None

    def load_projects_to_combo(self):
        self.is_updating_ui = True
        self.project_combo.clear()
        for proj in self.projects:
            self.project_combo.addItem(proj["name"], proj["id"])
        
        if self.projects:
            self.project_combo.setCurrentIndex(0)
            self.current_project_id = self.project_combo.currentData()
        else:
            self.current_project_id = None
        self.is_updating_ui = False
        self.load_clips_to_combo()

    def load_clips_to_combo(self):
        self.is_updating_ui = True
        self.clip_combo.clear()
        proj = self.get_current_project()
        if proj:
            for clip in proj["clips"]:
                self.clip_combo.addItem(clip["name"], clip["id"])
            if proj["clips"]:
                self.clip_combo.setCurrentIndex(0)
                self.current_clip_id = self.clip_combo.currentData()
            else:
                self.current_clip_id = None
        else:
            self.current_clip_id = None
        self.is_updating_ui = False
        self.load_categories_to_list()

    def load_categories_to_list(self):
        self.is_updating_ui = True
        self.cat_list_widget.clear()
        clip = self.get_current_clip()
        if clip:
            for cat in clip["categories"]:
                enabled = cat.get("enabled", True)
                status_str = "✓" if enabled else "✗ [Disabled]"
                item_text = f"{status_str}  {cat['name']}"
                item = QListWidgetItem(item_text)
                item.setData(Qt.ItemDataRole.UserRole, cat["id"])
                if not enabled:
                    item.setForeground(QColor("#888888"))
                self.cat_list_widget.addItem(item)
            if clip["categories"]:
                self.cat_list_widget.setCurrentRow(0)
                self.current_category_id = clip["categories"][0]["id"]
            else:
                self.current_category_id = None
                self.content_editor.clear()
                self.center_header_label.setText("No categories available")
        else:
            self.current_category_id = None
            self.content_editor.clear()
            if not self.projects:
                self.center_header_label.setText("Create a new project to begin")
            else:
                self.center_header_label.setText("No clip selected")
        
        self.is_updating_ui = False
        self.update_editor_content()
        self.update_markdown_output()

    def update_editor_content(self):
        cat = self.get_current_category()
        self.is_updating_ui = True
        if cat:
            status = " [Enabled]" if cat.get("enabled", True) else " [Disabled]"
            self.center_header_label.setText(f"Editing Category: {cat['name']}{status}")
            self.content_editor.setPlainText(cat["content"])
            self.content_editor.setEnabled(True)
        else:
            self.center_header_label.setText("Select a category")
            self.content_editor.clear()
            self.content_editor.setEnabled(False)
        self.is_updating_ui = False

    def update_markdown_output(self):
        clip = self.get_current_clip()
        if not clip:
            self.markdown_output.clear()
            return

        md_lines = []
        for cat in clip["categories"]:
            if not cat.get("enabled", True):
                continue
            name = cat["name"].strip()
            content = cat["content"].strip()
            if content:
                md_lines.append(f"# {name}\n\n{content}\n")
        
        full_markdown = "\n".join(md_lines)
        self.markdown_output.setPlainText(full_markdown)

    # --- Slot Event Handlers ---

    def on_project_changed(self, index):
        if self.is_updating_ui or index < 0:
            return
        proj_id = self.project_combo.currentData()
        if proj_id:
            self.current_project_id = proj_id
            self.load_clips_to_combo()

    def on_clip_changed(self, index):
        if self.is_updating_ui or index < 0:
            return
        clip_id = self.clip_combo.currentData()
        if clip_id:
            self.current_clip_id = clip_id
            self.load_categories_to_list()

    def on_category_selected(self, row):
        if self.is_updating_ui or row < 0:
            return
        item = self.cat_list_widget.item(row)
        if item:
            self.current_category_id = item.data(Qt.ItemDataRole.UserRole)
            self.update_editor_content()

    def on_content_changed(self):
        if self.is_updating_ui:
            return
        cat = self.get_current_category()
        if cat:
            cat["content"] = self.content_editor.toPlainText()
            self.save_current_project()
            self.update_markdown_output()

    def toggle_category_enabled_by_item(self, item):
        if not item:
            return
        cat_id = item.data(Qt.ItemDataRole.UserRole)
        clip = self.get_current_clip()
        if clip:
            for cat in clip["categories"]:
                if cat["id"] == cat_id:
                    cat["enabled"] = not cat.get("enabled", True)
                    break
            self.save_current_project()
            self.load_categories_to_list()

    def toggle_category_enabled_current(self):
        item = self.cat_list_widget.currentItem()
        if item:
            self.toggle_category_enabled_by_item(item)

    # --- Project Actions ---

    def create_new_project(self):
        name, ok = QInputDialog.getText(self, "New Project", "Enter project name:")
        if ok and name.strip():
            ts = get_timestamp()
            proj_name = name.strip()
            filename = f"storyboarder_data_{sanitize_filename(proj_name)}_{ts}.json"
            new_proj = {
                "id": f"proj_{ts}",
                "name": proj_name,
                "created_at": ts,
                "_filename": filename,
                "clips": []
            }
            self.projects.append(new_proj)
            self.current_project_id = new_proj["id"]
            self.save_current_project()
            self.load_projects_to_combo()
            for i in range(self.project_combo.count()):
                if self.project_combo.itemData(i) == new_proj["id"]:
                    self.project_combo.setCurrentIndex(i)
                    break

    def rename_current_project(self):
        proj = self.get_current_project()
        if not proj:
            QMessageBox.warning(self, "Warning", "No project selected.")
            return
        name, ok = QInputDialog.getText(self, "Rename Project", "Enter new project name:", text=proj["name"])
        if ok and name.strip():
            new_name = name.strip()
            old_filename = proj.get("_filename")
            if old_filename:
                old_filepath = os.path.join(DATA_DIR, old_filename)
                if os.path.exists(old_filepath):
                    try:
                        os.remove(old_filepath)
                    except Exception as e:
                        print(f"Error removing old project file: {e}")
            
            proj["name"] = new_name
            ts = proj.get("created_at", get_timestamp())
            proj["_filename"] = f"storyboarder_data_{sanitize_filename(new_name)}_{ts}.json"
            self.save_current_project()
            self.load_projects_to_combo()
            for i in range(self.project_combo.count()):
                if self.project_combo.itemData(i) == proj["id"]:
                    self.project_combo.setCurrentIndex(i)
                    break

    def delete_current_project(self):
        proj = self.get_current_project()
        if not proj:
            return
        
        reply = QMessageBox.question(self, "Delete Project", f"Are you sure you want to delete project '{proj['name']}'?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            if "_filename" in proj and proj["_filename"]:
                filepath = os.path.join(DATA_DIR, proj["_filename"])
                if os.path.exists(filepath):
                    try:
                        os.remove(filepath)
                    except Exception as e:
                        print(f"Error removing file: {e}")
            
            self.projects = [p for p in self.projects if p["id"] != proj["id"]]
            self.load_projects_to_combo()

    # --- Clip Actions ---

    def create_new_clip(self):
        proj = self.get_current_project()
        if not proj:
            QMessageBox.warning(self, "Warning", "Please create or select a project first.")
            return
        name, ok = QInputDialog.getText(self, "New Clip", "Enter clip/shot name:")
        if ok and name.strip():
            ts = get_timestamp()
            inherited_categories = []
            if proj["clips"]:
                last_clip = proj["clips"][-1]
                for cat in last_clip["categories"]:
                    inherited_categories.append({
                        "id": f"cat_{int(os.times()[4])}_{os.getpid()}",
                        "name": cat["name"],
                        "content": cat["content"],
                        "enabled": cat.get("enabled", True)
                    })
            else:
                inherited_categories = []

            new_clip = {
                "id": f"clip_{ts}",
                "name": name.strip(),
                "categories": inherited_categories
            }
            proj["clips"].append(new_clip)
            self.save_current_project()
            self.load_clips_to_combo()
            self.clip_combo.setCurrentIndex(self.clip_combo.count() - 1)

    def rename_current_clip(self):
        clip = self.get_current_clip()
        if not clip:
            QMessageBox.warning(self, "Warning", "No clip selected.")
            return
        name, ok = QInputDialog.getText(self, "Rename Clip", "Enter new clip name:", text=clip["name"])
        if ok and name.strip():
            clip["name"] = name.strip()
            self.save_current_project()
            self.load_clips_to_combo()
            for i in range(self.clip_combo.count()):
                if self.clip_combo.itemData(i) == clip["id"]:
                    self.clip_combo.setCurrentIndex(i)
                    break

    def delete_current_clip(self):
        proj = self.get_current_project()
        clip = self.get_current_clip()
        if not proj or not clip:
            return

        reply = QMessageBox.question(self, "Delete Clip", f"Are you sure you want to delete clip '{clip['name']}'?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            proj["clips"] = [c for c in proj["clips"] if c["id"] != clip["id"]]
            self.save_current_project()
            self.load_clips_to_combo()

    # --- Category Actions ---

    def add_category(self):
        clip = self.get_current_clip()
        if not clip:
            QMessageBox.warning(self, "Warning", "Please create or select a clip first.")
            return
        name, ok = QInputDialog.getText(self, "Add Category", "Enter new category name (e.g. lighting, audio, music):")
        if ok and name.strip():
            new_cat = {
                "id": f"cat_{int(os.times()[4])}",
                "name": name.strip().lower(),
                "content": "",
                "enabled": True
            }
            clip["categories"].append(new_cat)
            self.save_current_project()
            self.load_categories_to_list()
            self.cat_list_widget.setCurrentRow(self.cat_list_widget.count() - 1)

    def rename_category(self):
        cat = self.get_current_category()
        if not cat:
            return
        name, ok = QInputDialog.getText(self, "Rename Category", "Enter new category name:", text=cat["name"])
        if ok and name.strip():
            cat["name"] = name.strip().lower()
            self.save_current_project()
            self.load_categories_to_list()

    def delete_category(self):
        clip = self.get_current_clip()
        cat = self.get_current_category()
        if not clip or not cat:
            return

        reply = QMessageBox.question(self, "Delete Category", f"Are you sure you want to delete category '{cat['name']}'?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            clip["categories"] = [c for c in clip["categories"] if c["id"] != cat["id"]]
            self.save_current_project()
            self.load_categories_to_list()

    def move_category(self, direction):
        clip = self.get_current_clip()
        if not clip:
            return
        row = self.cat_list_widget.currentRow()
        new_row = row + direction
        if 0 <= new_row < len(clip["categories"]):
            categories = clip["categories"]
            categories[row], categories[new_row] = categories[new_row], categories[row]
            self.save_current_project()
            self.load_categories_to_list()
            self.cat_list_widget.setCurrentRow(new_row)

    def nuke_database(self):
        reply = QMessageBox.warning(
            self, "Nuke Database",
            "WARNING: This will delete ALL project files permanently from 'storyboarder_data' folder!\nAre you absolutely sure?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            if os.path.exists(DATA_DIR):
                for filename in os.listdir(DATA_DIR):
                    if filename.endswith(".json") and filename.startswith("storyboarder_data_"):
                        try:
                            os.remove(os.path.join(DATA_DIR, filename))
                        except Exception as e:
                            print(f"Error removing {filename}: {e}")
            self.projects = self.load_all_projects()
            self.load_projects_to_combo()
            QMessageBox.information(self, "Database Reset", "All projects cleared and reset.")

def main():
    app = QApplication(sys.argv)
    window = StoryboarderApp()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
