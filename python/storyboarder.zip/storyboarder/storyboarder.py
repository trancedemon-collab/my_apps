#!/usr/bin/env python3
import sys
import os
import json
import datetime
import uuid
import copy
import re
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, 
    QHBoxLayout, QSplitter, QListWidget, QLineEdit, QPushButton, 
    QComboBox, QLabel, QMessageBox, QFrame, QDialog, QFormLayout, 
    QListWidgetItem, QFileDialog, QPlainTextEdit, QTextEdit, QInputDialog,
    QGridLayout, QScrollArea, QSizePolicy
)
from PyQt6.QtCore import Qt, QEvent
from PyQt6.QtGui import QFont, QKeySequence, QShortcut, QColor

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "storyboarder_data")

def sanitize_filename(name):
    return "".join(c if c.isalnum() or c in (' ', '_', '-') else '_' for c in name).strip().replace(' ', '_')

def get_timestamp():
    now = datetime.datetime.now()
    return now.strftime("%Y%m%d_%H%M%S")

class StoryboarderApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Storyboarder - AI Video Prompt Studio")
        self.resize(1300, 800)
        
        if not os.path.exists(DATA_DIR):
            os.makedirs(DATA_DIR, exist_ok=True)

        self.projects = self.load_all_projects()
        self.current_project_id = None
        self.current_clip_id = None
        self.current_category_ref_id = None
        self.is_updating_ui = False

        self.init_ui()
        self.apply_adaptive_styling()
        self.load_projects_to_combo()

    def migrate_project_schema(self, proj):
        if "categories_library" in proj and isinstance(proj["categories_library"], dict):
            return proj

        categories_library = {}
        for clip in proj.get("clips", []):
            new_clip_categories = []
            legacy_cats = clip.get("categories", [])
            for cat in legacy_cats:
                if isinstance(cat, dict):
                    cat_id = cat.get("id") or str(uuid.uuid4())
                    cat_name = cat.get("name", "category")
                    cat_content = cat.get("content", "")
                    cat_enabled = cat.get("enabled", True)

                    existing_lib_id = None
                    for lib_id, lib_cat in categories_library.items():
                        if lib_cat["name"] == cat_name and lib_cat["content"] == cat_content:
                            existing_lib_id = lib_id
                            break

                    if existing_lib_id:
                        ref_id = existing_lib_id
                    else:
                        ref_id = cat_id
                        categories_library[ref_id] = {
                            "id": ref_id,
                            "name": cat_name,
                            "content": cat_content
                        }

                    new_clip_categories.append({
                        "category_id": ref_id,
                        "enabled": cat_enabled,
                        "content_override": None
                    })
                elif isinstance(cat, str):
                    ref_id = str(uuid.uuid4())
                    categories_library[ref_id] = {
                        "id": ref_id,
                        "name": cat,
                        "content": ""
                    }
                    new_clip_categories.append({
                        "category_id": ref_id,
                        "enabled": True,
                        "content_override": None
                    })
            clip["categories"] = new_clip_categories

        proj["categories_library"] = categories_library
        return proj

    def load_all_projects(self):
        projects = []
        if os.path.exists(DATA_DIR):
            for filename in os.listdir(DATA_DIR):
                if filename.endswith(".json") and filename.startswith("storyboarder_data_"):
                    filepath = os.path.join(DATA_DIR, filename)
                    try:
                        with open(filepath, "r", encoding="utf-8") as f:
                            proj = json.load(f)
                            if "id" in proj and "name" in proj and "clips" in proj:
                                proj = self.migrate_project_schema(proj)
                                proj["_filename"] = filename
                                projects.append(proj)
                    except Exception as e:
                        print(f"Error loading {filename}: {e}")
        return projects

    def save_current_project(self):
        proj = self.get_current_project()
        if not proj:
            return
        
        if "_filename" not in proj or not proj["_filename"]:
            ts = proj.get("created_at", get_timestamp())
            proj["_filename"] = f"storyboarder_data_{sanitize_filename(proj['name'])}_{ts}.json"
        
        filepath = os.path.join(DATA_DIR, proj["_filename"])
        try:
            data_to_save = {k: v for k, v in proj.items() if not k.startswith("_")}
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(data_to_save, f, indent=4)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save project: {e}")

    def changeEvent(self, event):
        if event.type() == QEvent.Type.PaletteChange:
            if not getattr(self, "_in_palette_change", False):
                self._in_palette_change = True
                self.apply_adaptive_styling()
                self._in_palette_change = False
        super().changeEvent(event)

    def apply_adaptive_styling(self):
        palette = self.palette()
        bg_color = palette.color(palette.ColorRole.Window)
        is_dark = bg_color.lightness() < 128

        if is_dark:
            stylesheet = """
                QMainWindow {
                    background-color: #1e1e1e;
                    color: #f0f0f0;
                }
                QWidget {
                    background-color: #2b2b2b;
                    color: #f0f0f0;
                    font-family: 'Segoe UI', 'Sans-Serif';
                    font-size: 10pt;
                }
                QPushButton {
                    background-color: #3a3a3a;
                    border: 1px solid #555555;
                    border-radius: 4px;
                    padding: 5px 10px;
                    color: #f0f0f0;
                }
                QPushButton:hover {
                    background-color: #4a4a4a;
                    border: 1px solid #666666;
                }
                QPushButton:pressed {
                    background-color: #2a2a2a;
                }
                QComboBox, QLineEdit, QPlainTextEdit, QTextEdit, QListWidget {
                    background-color: #222222;
                    border: 1px solid #444444;
                    border-radius: 4px;
                    padding: 6px;
                    color: #ffffff;
                }
                QComboBox::drop-down {
                    border: 0px;
                }
                QListWidget::item {
                    padding: 6px 8px;
                    border-bottom: 1px solid #333333;
                    border-radius: 3px;
                }
                QListWidget::item:selected {
                    background-color: #3daee9;
                    color: #ffffff;
                }
                QLabel {
                    background-color: transparent;
                    color: #cccccc;
                    font-weight: bold;
                }
                QSplitter::handle {
                    background-color: #444444;
                }
            """
        else:
            stylesheet = """
                QMainWindow {
                    background-color: #f0f0f0;
                    color: #1e1e1e;
                }
                QWidget {
                    background-color: #ffffff;
                    color: #1e1e1e;
                    font-family: 'Segoe UI', 'Sans-Serif';
                    font-size: 10pt;
                }
                QPushButton {
                    background-color: #e0e0e0;
                    border: 1px solid #cccccc;
                    border-radius: 4px;
                    padding: 5px 10px;
                    color: #1e1e1e;
                }
                QPushButton:hover {
                    background-color: #d0d0d0;
                    border: 1px solid #bbbbbb;
                }
                QPushButton:pressed {
                    background-color: #c0c0c0;
                }
                QComboBox, QLineEdit, QPlainTextEdit, QTextEdit, QListWidget {
                    background-color: #f9f9f9;
                    border: 1px solid #cccccc;
                    border-radius: 4px;
                    padding: 6px;
                    color: #000000;
                }
                QComboBox::drop-down {
                    border: 0px;
                }
                QListWidget::item {
                    padding: 6px 8px;
                    border-bottom: 1px solid #e0e0e0;
                    border-radius: 3px;
                }
                QListWidget::item:selected {
                    background-color: #3daee9;
                    color: #ffffff;
                }
                QLabel {
                    background-color: transparent;
                    color: #333333;
                    font-weight: bold;
                }
                QSplitter::handle {
                    background-color: #cccccc;
                }
            """
        self.setStyleSheet(stylesheet)

    def init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(8, 8, 8, 8)
        main_layout.setSpacing(8)

        # --- Compact Top Control Bar ---
        top_bar_widget = QWidget()
        top_bar_widget.setFixedHeight(45)
        top_bar_layout = QHBoxLayout(top_bar_widget)
        top_bar_layout.setContentsMargins(0, 0, 0, 0)
        top_bar_layout.setSpacing(6)

        proj_label = QLabel("Project:")
        self.project_combo = QComboBox()
        self.project_combo.currentIndexChanged.connect(self.on_project_changed)
        
        btn_new_proj = QPushButton("New")
        btn_new_proj.setToolTip("Create New Project")
        btn_new_proj.clicked.connect(self.create_new_project)

        btn_rename_proj = QPushButton("Rename")
        btn_rename_proj.setToolTip("Rename Current Project")
        btn_rename_proj.clicked.connect(self.rename_current_project)
        
        btn_del_proj = QPushButton("Delete")
        btn_del_proj.setToolTip("Delete Current Project")
        btn_del_proj.clicked.connect(self.delete_current_project)

        clip_label = QLabel("Clip:")
        self.clip_combo = QComboBox()
        self.clip_combo.currentIndexChanged.connect(self.on_clip_changed)
        
        btn_new_clip = QPushButton("New")
        btn_new_clip.setToolTip("Create New Clip")
        btn_new_clip.clicked.connect(self.create_new_clip)

        btn_rename_clip = QPushButton("Rename")
        btn_rename_clip.setToolTip("Rename Current Clip")
        btn_rename_clip.clicked.connect(self.rename_current_clip)
        
        btn_del_clip = QPushButton("Delete")
        btn_del_clip.setToolTip("Delete Current Clip")
        btn_del_clip.clicked.connect(self.delete_current_clip)

        btn_nuke = QPushButton("Nuke DB")
        btn_nuke.setStyleSheet("background-color: #8b0000; color: white;")
        btn_nuke.clicked.connect(self.nuke_database)

        top_bar_layout.addWidget(proj_label)
        top_bar_layout.addWidget(self.project_combo, 2)
        top_bar_layout.addWidget(btn_new_proj)
        top_bar_layout.addWidget(btn_rename_proj)
        top_bar_layout.addWidget(btn_del_proj)

        top_bar_layout.addSpacing(10)

        top_bar_layout.addWidget(clip_label)
        top_bar_layout.addWidget(self.clip_combo, 2)
        top_bar_layout.addWidget(btn_new_clip)
        top_bar_layout.addWidget(btn_rename_clip)
        top_bar_layout.addWidget(btn_del_clip)

        top_bar_layout.addSpacing(10)
        top_bar_layout.addWidget(btn_nuke)

        main_layout.addWidget(top_bar_widget)

        # --- 3-Panel Layout ---
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setHandleWidth(6)

        # 1. Left Panel: Categories
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(2, 2, 2, 2)
        left_layout.setSpacing(6)
        
        left_header = QLabel("Categories (Toggle Enable/Disable)")
        self.cat_list_widget = QListWidget()
        self.cat_list_widget.currentRowChanged.connect(self.on_category_selected)
        self.cat_list_widget.itemDoubleClicked.connect(self.toggle_category_enabled_by_item)

        cat_btn_layout = QHBoxLayout()
        btn_add_cat = QPushButton("Add")
        btn_add_cat.clicked.connect(self.add_category)
        btn_rename_cat = QPushButton("Rename")
        btn_rename_cat.clicked.connect(self.rename_category)
        btn_toggle_cat = QPushButton("Enable/Disable")
        btn_toggle_cat.clicked.connect(self.toggle_category_enabled_current)
        btn_del_cat = QPushButton("Delete")
        btn_del_cat.clicked.connect(self.delete_category)

        cat_btn_layout.addWidget(btn_add_cat)
        cat_btn_layout.addWidget(btn_rename_cat)
        cat_btn_layout.addWidget(btn_toggle_cat)
        cat_btn_layout.addWidget(btn_del_cat)

        cat_order_layout = QHBoxLayout()
        btn_up_cat = QPushButton("▲ Move Up")
        btn_up_cat.clicked.connect(lambda: self.move_category(-1))
        btn_down_cat = QPushButton("▼ Move Down")
        btn_down_cat.clicked.connect(lambda: self.move_category(1))

        cat_order_layout.addWidget(btn_up_cat)
        cat_order_layout.addWidget(btn_down_cat)

        left_layout.addWidget(left_header)
        left_layout.addWidget(self.cat_list_widget)
        left_layout.addLayout(cat_btn_layout)
        left_layout.addLayout(cat_order_layout)

        # 2. Center Panel: Category Content Editor + Formatting Tools
        center_widget = QWidget()
        center_layout = QVBoxLayout(center_widget)
        center_layout.setContentsMargins(2, 2, 2, 2)
        center_layout.setSpacing(6)

        self.center_header_label = QLabel("Select a category to edit content")
        
        # Text formatting toolbar
        format_tool_layout = QHBoxLayout()
        btn_para = QPushButton("1 Paragraph")
        btn_para.setToolTip("Remove line breaks and extra whitespace, converting to a single clean paragraph")
        btn_para.clicked.connect(self.format_to_paragraph)

        btn_clean = QPushButton("Clean Odd Chars")
        btn_clean.setToolTip("Remove semicolons, colons, dashes, and odd punctuation")
        btn_clean.clicked.connect(self.clean_odd_characters)

        btn_upper = QPushButton("UPPER")
        btn_upper.clicked.connect(lambda: self.convert_case("upper"))

        btn_lower = QPushButton("lower")
        btn_lower.clicked.connect(lambda: self.convert_case("lower"))

        format_tool_layout.addWidget(btn_para)
        format_tool_layout.addWidget(btn_clean)
        format_tool_layout.addWidget(btn_upper)
        format_tool_layout.addWidget(btn_lower)

        self.content_editor = QPlainTextEdit()
        self.content_editor.setPlaceholderText("Enter category content, details, or prompt components here...")
        self.content_editor.textChanged.connect(self.on_content_changed)

        center_layout.addWidget(self.center_header_label)
        center_layout.addLayout(format_tool_layout)
        center_layout.addWidget(self.content_editor)

        # 3. Right Panel: Prompt Output (with Format & Copy)
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(2, 2, 2, 2)
        right_layout.setSpacing(6)

        right_header_layout = QHBoxLayout()
        right_header = QLabel("Prompt Output")
        
        self.format_combo = QComboBox()
        self.format_combo.addItems(["Markdown", "Plain Text"])
        self.format_combo.currentIndexChanged.connect(self.update_markdown_output)

        btn_copy = QPushButton("Copy All Text")
        btn_copy.clicked.connect(self.copy_all_text)

        right_header_layout.addWidget(right_header)
        right_header_layout.addStretch()
        right_header_layout.addWidget(QLabel("Format:"))
        right_header_layout.addWidget(self.format_combo)
        right_header_layout.addWidget(btn_copy)

        self.markdown_output = QTextEdit()
        self.markdown_output.setReadOnly(True)
        self.markdown_output.setPlaceholderText("Prompt output will appear here...")

        right_layout.addLayout(right_header_layout)
        right_layout.addWidget(self.markdown_output)

        splitter.addWidget(left_widget)
        splitter.addWidget(center_widget)
        splitter.addWidget(right_widget)
        splitter.setSizes([320, 480, 500])

        main_layout.addWidget(splitter)

    # --- Project & Clip Management Helpers ---

    def get_current_project(self):
        for proj in self.projects:
            if proj["id"] == self.current_project_id:
                return proj
        return None

    def get_current_clip(self):
        proj = self.get_current_project()
        if proj:
            for clip in proj["clips"]:
                if clip["id"] == self.current_clip_id:
                    return clip
        return None

    def get_current_category_ref(self):
        clip = self.get_current_clip()
        if clip:
            for ref in clip["categories"]:
                if ref.get("category_id") == self.current_category_ref_id:
                    return ref
        return None

    def get_current_library_category(self):
        proj = self.get_current_project()
        ref = self.get_current_category_ref()
        if proj and ref:
            lib_id = ref.get("category_id")
            return proj.get("categories_library", {}).get(lib_id)
        return None

    def load_projects_to_combo(self):
        self.is_updating_ui = True
        self.project_combo.clear()
        for proj in self.projects:
            self.project_combo.addItem(proj["name"], proj["id"])
        
        if self.projects:
            self.project_combo.setCurrentIndex(0)
            self.current_project_id = self.project_combo.currentData()
        else:
            self.current_project_id = None
        self.is_updating_ui = False
        self.load_clips_to_combo()

    def load_clips_to_combo(self):
        self.is_updating_ui = True
        self.clip_combo.clear()
        proj = self.get_current_project()
        if proj:
            for clip in proj["clips"]:
                self.clip_combo.addItem(clip["name"], clip["id"])
            if proj["clips"]:
                self.clip_combo.setCurrentIndex(0)
                self.current_clip_id = self.clip_combo.currentData()
            else:
                self.current_clip_id = None
        else:
            self.current_clip_id = None
        self.is_updating_ui = False
        self.load_categories_to_list()

    def load_categories_to_list(self):
        self.is_updating_ui = True
        previous_ref_id = self.current_category_ref_id
        self.cat_list_widget.clear()
        proj = self.get_current_project()
        clip = self.get_current_clip()
        target_row = 0

        if proj and clip:
            lib = proj.get("categories_library", {})
            for idx, ref in enumerate(clip["categories"]):
                lib_id = ref.get("category_id")
                lib_cat = lib.get(lib_id, {"name": "unknown", "content": ""})
                name = lib_cat.get("name", "unknown")
                enabled = ref.get("enabled", True)
                has_override = ref.get("content_override") is not None
                
                status_str = "✓" if enabled else "✗ [Disabled]"
                override_str = " [Override]" if has_override else ""
                item_text = f"{status_str}  {name}{override_str}"
                
                item = QListWidgetItem(item_text)
                item.setData(Qt.ItemDataRole.UserRole, lib_id)
                if not enabled:
                    item.setForeground(QColor("#888888" if self.palette().color(self.palette().ColorRole.Window).lightness() < 128 else "#777777"))
                self.cat_list_widget.addItem(item)
                
                if lib_id == previous_ref_id:
                    target_row = idx

            if clip["categories"]:
                # Ensure target_row is within bounds
                if target_row >= len(clip["categories"]):
                    target_row = 0
                self.cat_list_widget.setCurrentRow(target_row)
                self.current_category_ref_id = clip["categories"][target_row].get("category_id")
            else:
                self.current_category_ref_id = None
                self.content_editor.clear()
                self.center_header_label.setText("No categories available")
        else:
            self.current_category_ref_id = None
            self.content_editor.clear()
            if not self.projects:
                self.center_header_label.setText("Create a new project to begin")
            else:
                self.center_header_label.setText("No clip selected")
        
        self.is_updating_ui = False
        self.update_editor_content()
        self.update_markdown_output()

    def update_editor_content(self):
        proj = self.get_current_project()
        ref = self.get_current_category_ref()
        self.is_updating_ui = True
        if proj and ref:
            lib_id = ref.get("category_id")
            lib_cat = proj.get("categories_library", {}).get(lib_id, {})
            name = lib_cat.get("name", "category")
            enabled = ref.get("enabled", True)
            status = " [Enabled]" if enabled else " [Disabled]"
            
            override = ref.get("content_override")
            content = override if override is not None else lib_cat.get("content", "")
            override_status = " (Local Override)" if override is not None else " (Global)"
            
            self.center_header_label.setText(f"Editing: {name}{status}{override_status}")
            self.content_editor.setPlainText(content)
            self.content_editor.setEnabled(True)
        else:
            self.center_header_label.setText("Select a category")
            self.content_editor.clear()
            self.content_editor.setEnabled(False)
        self.is_updating_ui = False

    def update_markdown_output(self):
        proj = self.get_current_project()
        clip = self.get_current_clip()
        if not proj or not clip:
            self.markdown_output.clear()
            return

        lib = proj.get("categories_library", {})
        fmt = self.format_combo.currentText() if hasattr(self, 'format_combo') else "Markdown"
        lines = []
        for ref in clip["categories"]:
            if not ref.get("enabled", True):
                continue
            lib_id = ref.get("category_id")
            lib_cat = lib.get(lib_id, {})
            name = lib_cat.get("name", "").strip()
            
            override = ref.get("content_override")
            content = (override if override is not None else lib_cat.get("content", "")).strip()
            
            if content and name:
                if fmt == "Markdown":
                    lines.append(f"# {name}\n\n{content}\n")
                else:
                    lines.append(f"{name.upper()}:\n{content}\n")
        
        full_text = "\n".join(lines)
        self.markdown_output.setPlainText(full_text)

    def copy_all_text(self):
        clipboard = QApplication.clipboard()
        clipboard.setText(self.markdown_output.toPlainText())
        QMessageBox.information(self, "Copied", "All prompt output copied to clipboard!")

    # --- Text Formatting Tool Methods ---

    def format_to_paragraph(self):
        text = self.content_editor.toPlainText()
        cleaned = " ".join(text.split())
        self.content_editor.setPlainText(cleaned)
        self.on_content_changed()

    def clean_odd_characters(self):
        text = self.content_editor.toPlainText()
        # Remove semicolons, colons, dashes, etc.
        cleaned = re.sub(r'[;:\-—–]', '', text)
        cleaned = " ".join(cleaned.split())
        self.content_editor.setPlainText(cleaned)
        self.on_content_changed()

    def convert_case(self, mode):
        text = self.content_editor.toPlainText()
        if mode == "upper":
            self.content_editor.setPlainText(text.upper())
        elif mode == "lower":
            self.content_editor.setPlainText(text.lower())
        self.on_content_changed()

    # --- Slot Event Handlers ---

    def on_project_changed(self, index):
        if self.is_updating_ui or index < 0:
            return
        proj_id = self.project_combo.currentData()
        if proj_id:
            self.current_project_id = proj_id
            self.load_clips_to_combo()

    def on_clip_changed(self, index):
        if self.is_updating_ui or index < 0:
            return
        clip_id = self.clip_combo.currentData()
        if clip_id:
            self.current_clip_id = clip_id
            self.load_categories_to_list()

    def on_category_selected(self, row):
        if self.is_updating_ui or row < 0:
            return
        item = self.cat_list_widget.item(row)
        if item:
            self.current_category_ref_id = item.data(Qt.ItemDataRole.UserRole)
            self.update_editor_content()

    def on_content_changed(self):
        if self.is_updating_ui:
            return
        proj = self.get_current_project()
        ref = self.get_current_category_ref()
        if not proj or not ref:
            return

        new_text = self.content_editor.toPlainText()
        lib_id = ref.get("category_id")
        lib_cat = proj.get("categories_library", {}).get(lib_id, {})

        has_override = ref.get("content_override") is not None
        update_globally_flag = ref.get("_update_globally", False)

        if has_override:
            ref["content_override"] = new_text
        elif update_globally_flag:
            lib_cat["content"] = new_text
        else:
            other_clips_ref = 0
            for c in proj.get("clips", []):
                for r in c.get("categories", []):
                    if r.get("category_id") == lib_id:
                        other_clips_ref += 1

            if other_clips_ref > 1:
                msg = QMessageBox(self)
                msg.setWindowTitle("Edit Category Scope")
                msg.setText("This category is shared across multiple clips.")
                msg.setInformativeText("Do you want to update it globally for all clips, or create a local override for this clip only?")
                btn_global = msg.addButton("Update Globally", QMessageBox.ButtonRole.AcceptRole)
                btn_override = msg.addButton("Create Local Override", QMessageBox.ButtonRole.ActionRole)
                msg.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
                msg.exec()

                clicked = msg.clickedButton()
                if clicked == btn_global:
                    ref["_update_globally"] = True
                    lib_cat["content"] = new_text
                elif clicked == btn_override:
                    ref["content_override"] = new_text
                else:
                    return
            else:
                lib_cat["content"] = new_text

        self.save_current_project()
        self.update_markdown_output()

    def toggle_category_enabled_by_item(self, item):
        if not item:
            return
        lib_id = item.data(Qt.ItemDataRole.UserRole)
        clip = self.get_current_clip()
        if clip:
            for ref in clip["categories"]:
                if ref.get("category_id") == lib_id:
                    ref["enabled"] = not ref.get("enabled", True)
                    break
            self.save_current_project()
            self.load_categories_to_list()

    def toggle_category_enabled_current(self):
        item = self.cat_list_widget.currentItem()
        if item:
            self.toggle_category_enabled_by_item(item)

    # --- Project Actions ---

    def create_new_project(self):
        name, ok = QInputDialog.getText(self, "New Project", "Enter project name:")
        if ok and name.strip():
            ts = get_timestamp()
            proj_name = name.strip()
            filename = f"storyboarder_data_{sanitize_filename(proj_name)}_{ts}.json"
            new_proj = {
                "id": str(uuid.uuid4()),
                "name": proj_name,
                "created_at": ts,
                "_filename": filename,
                "categories_library": {},
                "clips": []
            }
            self.projects.append(new_proj)
            self.current_project_id = new_proj["id"]
            self.save_current_project()
            self.load_projects_to_combo()
            for i in range(self.project_combo.count()):
                if self.project_combo.itemData(i) == new_proj["id"]:
                    self.project_combo.setCurrentIndex(i)
                    break

    def rename_current_project(self):
        proj = self.get_current_project()
        if not proj:
            QMessageBox.warning(self, "Warning", "No project selected.")
            return
        name, ok = QInputDialog.getText(self, "Rename Project", "Enter new project name:", text=proj["name"])
        if ok and name.strip():
            new_name = name.strip()
            old_filename = proj.get("_filename")
            if old_filename:
                old_filepath = os.path.join(DATA_DIR, old_filename)
                if os.path.exists(old_filepath):
                    try:
                        os.remove(old_filepath)
                    except Exception as e:
                        print(f"Error removing old project file: {e}")
            
            proj["name"] = new_name
            ts = proj.get("created_at", get_timestamp())
            proj["_filename"] = f"storyboarder_data_{sanitize_filename(new_name)}_{ts}.json"
            self.save_current_project()
            self.load_projects_to_combo()
            for i in range(self.project_combo.count()):
                if self.project_combo.itemData(i) == proj["id"]:
                    self.project_combo.setCurrentIndex(i)
                    break

    def delete_current_project(self):
        proj = self.get_current_project()
        if not proj:
            return
        
        reply = QMessageBox.question(self, "Delete Project", f"Are you sure you want to delete project '{proj['name']}'?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            if "_filename" in proj and proj["_filename"]:
                filepath = os.path.join(DATA_DIR, proj["_filename"])
                if os.path.exists(filepath):
                    try:
                        os.remove(filepath)
                    except Exception as e:
                        print(f"Error removing file: {e}")
            
            self.projects = [p for p in self.projects if p["id"] != proj["id"]]
            self.load_projects_to_combo()

    # --- Clip Actions ---

    def create_new_clip(self):
        proj = self.get_current_project()
        if not proj:
            QMessageBox.warning(self, "Warning", "Please create or select a project first.")
            return
        name, ok = QInputDialog.getText(self, "New Clip", "Enter clip/shot name:")
        if ok and name.strip():
            inherited_categories = []
            if proj["clips"]:
                last_clip = proj["clips"][-1]
                for ref in last_clip["categories"]:
                    inherited_categories.append({
                        "category_id": ref.get("category_id"),
                        "enabled": ref.get("enabled", True),
                        "content_override": ref.get("content_override")
                    })
            else:
                inherited_categories = []

            new_clip = {
                "id": str(uuid.uuid4()),
                "name": name.strip(),
                "categories": inherited_categories
            }
            proj["clips"].append(new_clip)
            self.save_current_project()
            self.load_clips_to_combo()
            self.clip_combo.setCurrentIndex(self.clip_combo.count() - 1)

    def rename_current_clip(self):
        clip = self.get_current_clip()
        if not clip:
            QMessageBox.warning(self, "Warning", "No clip selected.")
            return
        name, ok = QInputDialog.getText(self, "Rename Clip", "Enter new clip name:", text=clip["name"])
        if ok and name.strip():
            clip["name"] = name.strip()
            self.save_current_project()
            self.load_clips_to_combo()
            for i in range(self.clip_combo.count()):
                if self.clip_combo.itemData(i) == clip["id"]:
                    self.clip_combo.setCurrentIndex(i)
                    break

    def delete_current_clip(self):
        proj = self.get_current_project()
        clip = self.get_current_clip()
        if not proj or not clip:
            return

        reply = QMessageBox.question(self, "Delete Clip", f"Are you sure you want to delete clip '{clip['name']}'?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            proj["clips"] = [c for c in proj["clips"] if c["id"] != clip["id"]]
            self.save_current_project()
            self.load_clips_to_combo()

    # --- Category Actions ---

    def add_category(self):
        proj = self.get_current_project()
        clip = self.get_current_clip()
        if not proj or not clip:
            QMessageBox.warning(self, "Warning", "Please create or select a clip first.")
            return
        name, ok = QInputDialog.getText(self, "Add Category", "Enter new category name (e.g. lighting, audio, music):")
        if ok and name.strip():
            cat_name = name.strip().lower()
            lib_id = str(uuid.uuid4())
            
            if "categories_library" not in proj:
                proj["categories_library"] = {}
            proj["categories_library"][lib_id] = {
                "id": lib_id,
                "name": cat_name,
                "content": ""
            }

            new_ref = {
                "category_id": lib_id,
                "enabled": True,
                "content_override": None
            }
            clip["categories"].append(new_ref)
            self.save_current_project()
            self.load_categories_to_list()
            self.cat_list_widget.setCurrentRow(self.cat_list_widget.count() - 1)

    def rename_category(self):
        proj = self.get_current_project()
        ref = self.get_current_category_ref()
        if not proj or not ref:
            return
        lib_id = ref.get("category_id")
        lib_cat = proj.get("categories_library", {}).get(lib_id)
        if not lib_cat:
            return

        name, ok = QInputDialog.getText(self, "Rename Category", "Enter new category name:", text=lib_cat["name"])
        if ok and name.strip():
            lib_cat["name"] = name.strip().lower()
            self.save_current_project()
            self.load_categories_to_list()

    def delete_category(self):
        proj = self.get_current_project()
        clip = self.get_current_clip()
        ref = self.get_current_category_ref()
        if not proj or not clip or not ref:
            return

        reply = QMessageBox.question(self, "Delete Category", "Are you sure you want to remove this category from this clip?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            clip["categories"] = [r for r in clip["categories"] if r.get("category_id") != ref.get("category_id")]
            self.save_current_project()
            self.load_categories_to_list()

    def move_category(self, direction):
        clip = self.get_current_clip()
        if not clip:
            return
        row = self.cat_list_widget.currentRow()
        new_row = row + direction
        if 0 <= new_row < len(clip["categories"]):
            categories = clip["categories"]
            categories[row], categories[new_row] = categories[new_row], categories[row]
            self.save_current_project()
            self.load_categories_to_list()
            self.cat_list_widget.setCurrentRow(new_row)

    def nuke_database(self):
        reply = QMessageBox.warning(
            self,
            "Nuke Database",
            "WARNING: This will delete ALL project files permanently from 'storyboarder_data' folder!\nAre you absolutely sure?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            if os.path.exists(DATA_DIR):
                for filename in os.listdir(DATA_DIR):
                    if filename.endswith(".json") and filename.startswith("storyboarder_data_"):
                        try:
                            os.remove(os.path.join(DATA_DIR, filename))
                        except Exception as e:
                            print(f"Error removing {filename}: {e}")
            self.projects = self.load_all_projects()
            self.load_projects_to_combo()
            QMessageBox.information(self, "Database Reset", "All projects cleared and reset.")

def main():
    app = QApplication(sys.argv)
    window = StoryboarderApp()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
