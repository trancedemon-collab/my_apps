#!/usr/bin/env python3
import sys
import os
import json
import datetime
import uuid
import copy
import re
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, 
    QHBoxLayout, QSplitter, QListWidget, QLineEdit, QPushButton, 
    QComboBox, QLabel, QMessageBox, QFrame, QDialog, QFormLayout, 
    QListWidgetItem, QFileDialog, QPlainTextEdit, QTextEdit, QInputDialog,
    QGridLayout, QScrollArea, QSizePolicy, QCheckBox, QLayout
)
from PyQt6.QtCore import Qt, QEvent, QByteArray, QRect, QPoint, QSize
from PyQt6.QtGui import QFont, QKeySequence, QShortcut, QColor

class FlowLayout(QLayout):
    def __init__(self, parent=None, margin=0, spacing=-1):
        super().__init__(parent)
        if parent is not None:
            self.setContentsMargins(margin, margin, margin, margin)
        self.setSpacing(spacing)
        self.itemList = []

    def __del__(self):
        item = self.takeAt(0)
        while item:
            item = self.takeAt(0)

    def addItem(self, item):
        self.itemList.append(item)

    def count(self):
        return len(self.itemList)

    def itemAt(self, index):
        if 0 <= index < len(self.itemList):
            return self.itemList[index]
        return None

    def takeAt(self, index):
        if 0 <= index < len(self.itemList):
            return self.itemList.pop(index)
        return None

    def expandingDirections(self):
        return Qt.Orientation(0)

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, width):
        return self.doLayout(QRect(0, 0, width, 0), True)

    def setGeometry(self, rect):
        super().setGeometry(rect)
        self.doLayout(rect, False)

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        size = QSize()
        for item in self.itemList:
            size = size.expandedTo(item.minimumSize())
        margins = self.contentsMargins()
        size += QSize(margins.left() + margins.right(), margins.top() + margins.bottom())
        return size

    def doLayout(self, rect, testOnly):
        x = rect.x()
        y = rect.y()
        lineHeight = 0
        spaceX = self.spacing()
        spaceY = self.spacing()
        if spaceX < 0:
            spaceX = 6
        if spaceY < 0:
            spaceY = 6

        for item in self.itemList:
            item_size = item.sizeHint()
            nextX = x + item_size.width() + spaceX
            if nextX - spaceX > rect.right() and lineHeight > 0:
                x = rect.x()
                y = y + lineHeight + spaceY
                nextX = x + item_size.width() + spaceX
                lineHeight = 0

            if not testOnly:
                item.setGeometry(QRect(QPoint(x, y), item_size))

            x = nextX
            lineHeight = max(lineHeight, item_size.height())

        return y + lineHeight - rect.y()

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "storyboarder_data")
SETTINGS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "storyboarder_settings.json")
PRESETS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "storyboarder_presets.json")

DEFAULT_PRESETS = {
    "Cinematic Standard": [
        {"name": "Rules", "is_dynamic": False, "content": "Maintain photorealistic film continuity, authentic lighting, no uncanny valley artifacts."},
        {"name": "Style", "is_dynamic": False, "content": "35mm anamorphic film, cinematic color grading, natural depth of field."},
        {"name": "Character - Hero", "is_dynamic": False, "content": "Male protagonist, late 30s, rugged build, weather-beaten brown leather jacket."},
        {"name": "Environment", "is_dynamic": False, "content": "Gloomy overcast rocky coastline, turbulent waves and crashing spray."},
        {"name": "Camera Angle", "is_dynamic": False, "content": "Medium tracking shot at eye level with slight handheld camera drift."},
        {"name": "Action / Beat", "is_dynamic": True, "default_placeholder": "Describe scene action for this clip..."}
    ],
    "Character & Dialogue": [
        {"name": "Rules", "is_dynamic": False, "content": "Consistent facial anatomy, subtle eye movements, natural micro-expressions."},
        {"name": "Protagonist", "is_dynamic": False, "content": "Female scientist, early 30s, sleek glasses, dark hair in practical ponytail."},
        {"name": "Antagonist", "is_dynamic": False, "content": "Corporate executive, sharp tailored charcoal suit, impassive demeanor."},
        {"name": "Setting", "is_dynamic": False, "content": "Minimalist high-tech laboratory with soft ambient fluorescent backlighting."},
        {"name": "Dialogue / Interaction", "is_dynamic": True, "default_placeholder": "Character speaking lines and reactions..."},
        {"name": "Action / Beat", "is_dynamic": True, "default_placeholder": "Physical action or gestures during conversation..."}
    ]
}

def sanitize_filename(name):
    return "".join(c if c.isalnum() or c in (' ', '_', '-') else '_' for c in name).strip().replace(' ', '_')

def get_timestamp():
    now = datetime.datetime.now()
    return now.strftime("%Y%m%d_%H%M%S")

class StoryboarderApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Storyboarder - AI Video Prompt Studio (V2 Architecture)")
        self.resize(1300, 800)
        
        if not os.path.exists(DATA_DIR):
            os.makedirs(DATA_DIR, exist_ok=True)

        self.settings = self.load_settings()
        self.presets = self.load_presets()
        self.projects = self.load_all_projects()
        
        self.current_project_id = None
        self.current_clip_id = None
        self.current_category_id = None
        self.is_updating_ui = False

        self.init_ui()
        self.apply_adaptive_styling()
        self.load_projects_to_combo()
        self.restore_ui_state()

    # --- Settings and Presets Management ---

    def load_settings(self):
        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                print(f"Error loading settings: {e}")
        return {"splitter_sizes": [320, 480, 500]}

    def save_settings(self):
        try:
            if hasattr(self, 'splitter'):
                self.settings["splitter_sizes"] = self.splitter.sizes()
            with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
                json.dump(self.settings, f, indent=4)
        except Exception as e:
            print(f"Error saving settings: {e}")

    def load_presets(self):
        if os.path.exists(PRESETS_FILE):
            try:
                with open(PRESETS_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        return data
            except Exception as e:
                print(f"Error loading presets: {e}")
        return copy.deepcopy(DEFAULT_PRESETS)

    def save_presets(self):
        try:
            with open(PRESETS_FILE, "w", encoding="utf-8") as f:
                json.dump(self.presets, f, indent=4)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save presets: {e}")

    def closeEvent(self, event):
        self.save_settings()
        super().closeEvent(event)

    def restore_ui_state(self):
        saved_sizes = self.settings.get("splitter_sizes")
        if saved_sizes and len(saved_sizes) == 3 and hasattr(self, 'splitter'):
            self.splitter.setSizes(saved_sizes)

    def on_splitter_moved(self, pos, index):
        self.save_settings()

    # --- Schema Migration & Project IO ---

    def migrate_v1_to_v2(self, proj):
        """Migrates v1 normalized schema (categories_library & references) to v2 architecture."""
        if "project_title" not in proj:
            proj["project_title"] = proj.get("name") or proj.get("title") or "Untitled Project"
        if "name" in proj:
            del proj["name"]

        for clip in proj.get("clips", []):
            if "clip_id" not in clip and "id" in clip:
                clip["clip_id"] = clip["id"]
            if "clip_id" not in clip:
                clip["clip_id"] = f"clip_{uuid.uuid4().hex[:8]}"
            if "id" in clip:
                del clip["id"]

            if "title" not in clip and "name" in clip:
                clip["title"] = clip["name"]
            if "title" not in clip:
                clip["title"] = "Shot 1"
            if "name" in clip:
                del clip["name"]

        if "categories_library" in proj:
            lib = proj.get("categories_library", {})
            categories = []
            for lib_id, cat_data in lib.items():
                categories.append({
                    "id": lib_id,
                    "name": cat_data.get("name", "category"),
                    "is_dynamic": False,
                    "content": cat_data.get("content", "")
                })
            
            for clip in proj.get("clips", []):
                enabled_cats = []
                dynamic_data = {}
                for ref in clip.get("categories", []):
                    cat_id = ref.get("category_id")
                    if ref.get("enabled", True):
                        enabled_cats.append(cat_id)
                    override = ref.get("content_override")
                    if override is not None:
                        dynamic_data[cat_id] = override
                clip["enabled_categories"] = enabled_cats
                clip["dynamic_data"] = dynamic_data
                if "categories" in clip:
                    del clip["categories"]

            proj["categories"] = categories
            del proj["categories_library"]
            proj["version"] = "2.0"
            return proj

        if "categories" in proj and isinstance(proj["categories"], list):
            all_cat_ids = [c["id"] for c in proj["categories"]]
            for clip in proj.get("clips", []):
                if "enabled_categories" not in clip:
                    if "categories" in clip and isinstance(clip["categories"], list):
                        clip["enabled_categories"] = [r.get("category_id") for r in clip["categories"] if r.get("enabled", True)]
                    else:
                        clip["enabled_categories"] = list(all_cat_ids)
                if "dynamic_data" not in clip:
                    clip["dynamic_data"] = {}
                    if "categories" in clip and isinstance(clip["categories"], list):
                        for r in clip["categories"]:
                            override = r.get("content_override")
                            if override is not None:
                                clip["dynamic_data"][r.get("category_id")] = override
                if "categories" in clip:
                    del clip["categories"]
            return proj

        if "categories" not in proj:
            proj["categories"] = [
                {"id": f"cat_{uuid.uuid4().hex[:8]}", "name": "Rules", "is_dynamic": False, "content": "Film perspective, cinematic continuity rules..."},
                {"id": f"cat_{uuid.uuid4().hex[:8]}", "name": "Style", "is_dynamic": False, "content": "Cinematic realism, high-end photography..."},
                {"id": f"cat_{uuid.uuid4().hex[:8]}", "name": "Action / Beat", "is_dynamic": True, "default_placeholder": "Describe scene action..."}
            ]
            for clip in proj.get("clips", []):
                if "enabled_categories" not in clip:
                    clip["enabled_categories"] = [c["id"] for c in proj["categories"]]
                if "dynamic_data" not in clip:
                    clip["dynamic_data"] = {}

        proj["version"] = "2.0"
        return proj

    def load_all_projects(self):
        projects = []
        if os.path.exists(DATA_DIR):
            for filename in os.listdir(DATA_DIR):
                if filename.endswith(".json"):
                    filepath = os.path.join(DATA_DIR, filename)
                    try:
                        with open(filepath, "r", encoding="utf-8") as f:
                            proj = json.load(f)
                            proj = self.migrate_v1_to_v2(proj)
                            proj["_filename"] = filename
                            if "id" not in proj:
                                proj["id"] = str(uuid.uuid4())
                            projects.append(proj)
                    except Exception as e:
                        print(f"Error loading {filename}: {e}")
        return projects

    def save_current_project(self):
        proj = self.get_current_project()
        if not proj:
            return
        
        title = proj.get("project_title", "Untitled Project")
        filename = f"{sanitize_filename(title)}.json"
        
        old_filename = proj.get("_filename")
        if old_filename and old_filename != filename:
            old_filepath = os.path.join(DATA_DIR, old_filename)
            if os.path.exists(old_filepath):
                try:
                    os.remove(old_filepath)
                except Exception as e:
                    print(f"Error removing old project file: {e}")
        
        proj["_filename"] = filename
        filepath = os.path.join(DATA_DIR, filename)
        
        try:
            data_to_save = {k: v for k, v in proj.items() if not k.startswith("_")}
            data_to_save["version"] = "2.0"
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(data_to_save, f, indent=4)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save project: {e}")

    def changeEvent(self, event):
        if event.type() == QEvent.Type.PaletteChange:
            if not getattr(self, "_in_palette_change", False):
                self._in_palette_change = True
                self.apply_adaptive_styling()
                self._in_palette_change = False
        super().changeEvent(event)

    def apply_adaptive_styling(self):
        palette = self.palette()
        bg_color = palette.color(palette.ColorRole.Window)
        is_dark = bg_color.lightness() < 128

        if is_dark:
            stylesheet = """
                QMainWindow {
                    background-color: #1e1e1e;
                    color: #f0f0f0;
                }
                QWidget {
                    background-color: #2b2b2b;
                    color: #f0f0f0;
                    font-family: 'Segoe UI', 'Sans-Serif';
                    font-size: 10pt;
                }
                QPushButton {
                    background-color: #3a3a3a;
                    border: 1px solid #555555;
                    border-radius: 4px;
                    padding: 5px 10px;
                    color: #f0f0f0;
                }
                QPushButton:hover {
                    background-color: #4a4a4a;
                    border: 1px solid #666666;
                }
                QPushButton:pressed {
                    background-color: #2a2a2a;
                }
                QComboBox, QLineEdit, QPlainTextEdit, QTextEdit, QListWidget {
                    background-color: #222222;
                    border: 1px solid #444444;
                    border-radius: 4px;
                    padding: 6px;
                    color: #ffffff;
                }
                QComboBox::drop-down {
                    border: 0px;
                }
                QListWidget::item {
                    padding: 6px 8px;
                    border-bottom: 1px solid #333333;
                    border-radius: 3px;
                }
                QListWidget::item:selected {
                    background-color: #3daee9;
                    color: #ffffff;
                }
                QLabel {
                    background-color: transparent;
                    color: #cccccc;
                    font-weight: bold;
                }
                QSplitter::handle {
                    background-color: #555555;
                    width: 6px;
                }
                QSplitter::handle:hover {
                    background-color: #3daee9;
                }
            """
        else:
            stylesheet = """
                QMainWindow {
                    background-color: #f0f0f0;
                    color: #1e1e1e;
                }
                QWidget {
                    background-color: #ffffff;
                    color: #1e1e1e;
                    font-family: 'Segoe UI', 'Sans-Serif';
                    font-size: 10pt;
                }
                QPushButton {
                    background-color: #e0e0e0;
                    border: 1px solid #cccccc;
                    border-radius: 4px;
                    padding: 5px 10px;
                    color: #1e1e1e;
                }
                QPushButton:hover {
                    background-color: #d0d0d0;
                    border: 1px solid #bbbbbb;
                }
                QPushButton:pressed {
                    background-color: #c0c0c0;
                }
                QComboBox, QLineEdit, QPlainTextEdit, QTextEdit, QListWidget {
                    background-color: #f9f9f9;
                    border: 1px solid #cccccc;
                    border-radius: 4px;
                    padding: 6px;
                    color: #000000;
                }
                QComboBox::drop-down {
                    border: 0px;
                }
                QListWidget::item {
                    padding: 6px 8px;
                    border-bottom: 1px solid #e0e0e0;
                    border-radius: 3px;
                }
                QListWidget::item:selected {
                    background-color: #3daee9;
                    color: #ffffff;
                }
                QLabel {
                    background-color: transparent;
                    color: #333333;
                    font-weight: bold;
                }
                QSplitter::handle {
                    background-color: #cccccc;
                    width: 6px;
                }
                QSplitter::handle:hover {
                    background-color: #3daee9;
                }
            """
        self.setStyleSheet(stylesheet)

    def init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(8, 8, 8, 8)
        main_layout.setSpacing(8)

        # --- Compact Top Control Bar ---
        top_bar_widget = QWidget()
        top_bar_widget.setFixedHeight(45)
        top_bar_layout = QHBoxLayout(top_bar_widget)
        top_bar_layout.setContentsMargins(0, 0, 0, 0)
        top_bar_layout.setSpacing(6)

        proj_label = QLabel("Project:")
        self.project_combo = QComboBox()
        self.project_combo.currentIndexChanged.connect(self.on_project_changed)
        
        btn_new_proj = QPushButton("New")
        btn_new_proj.setToolTip("Create New Project")
        btn_new_proj.clicked.connect(self.create_new_project)

        btn_rename_proj = QPushButton("Rename")
        btn_rename_proj.setToolTip("Rename Current Project")
        btn_rename_proj.clicked.connect(self.rename_current_project)
        
        btn_del_proj = QPushButton("Delete")
        btn_del_proj.setToolTip("Delete Current Project")
        btn_del_proj.clicked.connect(self.delete_current_project)

        clip_label = QLabel("Clip:")
        self.clip_combo = QComboBox()
        self.clip_combo.currentIndexChanged.connect(self.on_clip_changed)
        
        btn_new_clip = QPushButton("New")
        btn_new_clip.setToolTip("Create New Clip")
        btn_new_clip.clicked.connect(self.create_new_clip)

        btn_rename_clip = QPushButton("Rename")
        btn_rename_clip.setToolTip("Rename Current Clip")
        btn_rename_clip.clicked.connect(self.rename_current_clip)
        
        btn_del_clip = QPushButton("Delete")
        btn_del_clip.setToolTip("Delete Current Clip")
        btn_del_clip.clicked.connect(self.delete_current_clip)

        btn_export_txt = QPushButton("Export TXT")
        btn_export_txt.setToolTip("Export entire project as a neatly formatted portfolio .txt file")
        btn_export_txt.clicked.connect(self.export_project_txt)

        btn_nuke = QPushButton("Nuke DB")
        btn_nuke.setStyleSheet("background-color: #8b0000; color: white;")
        btn_nuke.clicked.connect(self.nuke_database)

        top_bar_layout.addWidget(proj_label)
        top_bar_layout.addWidget(self.project_combo, 2)
        top_bar_layout.addWidget(btn_new_proj)
        top_bar_layout.addWidget(btn_rename_proj)
        top_bar_layout.addWidget(btn_del_proj)

        top_bar_layout.addSpacing(10)

        top_bar_layout.addWidget(clip_label)
        top_bar_layout.addWidget(self.clip_combo, 2)
        top_bar_layout.addWidget(btn_new_clip)
        top_bar_layout.addWidget(btn_rename_clip)
        top_bar_layout.addWidget(btn_del_clip)

        top_bar_layout.addSpacing(10)
        top_bar_layout.addWidget(btn_export_txt)
        top_bar_layout.addWidget(btn_nuke)

        main_layout.addWidget(top_bar_widget)

        # --- 3-Panel Resizable Layout (Splitter) ---
        self.splitter = QSplitter(Qt.Orientation.Horizontal)
        self.splitter.setHandleWidth(6)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.splitterMoved.connect(self.on_splitter_moved)

        # 1. Left Panel: Categories (Global Assets, Visibility & Presets)
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(2, 2, 2, 2)
        left_layout.setSpacing(6)
        
        left_header = QLabel("Global Categories (Double-click: Enable/Disable)")
        self.cat_list_widget = QListWidget()
        self.cat_list_widget.currentRowChanged.connect(self.on_category_selected)
        self.cat_list_widget.itemDoubleClicked.connect(self.toggle_category_enabled_by_item)

        cat_btn_layout = FlowLayout(margin=0, spacing=4)
        btn_add_cat = QPushButton("Add Asset")
        btn_add_cat.clicked.connect(self.add_category)
        btn_rename_cat = QPushButton("Rename")
        btn_rename_cat.clicked.connect(self.rename_category)
        btn_toggle_type = QPushButton("Toggle Type")
        btn_toggle_type.setToolTip("Toggle category between Static (Global Asset) and Dynamic (Per-Clip)")
        btn_toggle_type.clicked.connect(self.toggle_category_type)
        btn_toggle_cat = QPushButton("Enable/Disable")
        btn_toggle_cat.clicked.connect(self.toggle_category_enabled_current)
        btn_del_cat = QPushButton("Delete")
        btn_del_cat.clicked.connect(self.delete_category)

        cat_btn_layout.addWidget(btn_add_cat)
        cat_btn_layout.addWidget(btn_rename_cat)
        cat_btn_layout.addWidget(btn_toggle_type)
        cat_btn_layout.addWidget(btn_toggle_cat)
        cat_btn_layout.addWidget(btn_del_cat)

        cat_order_layout = FlowLayout(margin=0, spacing=4)
        btn_up_cat = QPushButton("▲ Move Up")
        btn_up_cat.clicked.connect(lambda: self.move_category(-1))
        btn_down_cat = QPushButton("▼ Move Down")
        btn_down_cat.clicked.connect(lambda: self.move_category(1))

        cat_order_layout.addWidget(btn_up_cat)
        cat_order_layout.addWidget(btn_down_cat)

        # Category Presets Toolbar
        preset_layout = FlowLayout(margin=0, spacing=4)
        btn_load_preset = QPushButton("📁 Load Preset")
        btn_load_preset.setToolTip("Load a pre-defined set of categories into the current project")
        btn_load_preset.clicked.connect(self.load_category_preset)

        btn_save_preset = QPushButton("💾 Save Preset")
        btn_save_preset.setToolTip("Save current project categories as a reusable preset template")
        btn_save_preset.clicked.connect(self.save_category_preset)

        btn_manage_presets = QPushButton("⚙ Manage")
        btn_manage_presets.setToolTip("Delete or manage custom category presets")
        btn_manage_presets.clicked.connect(self.manage_category_presets)

        preset_layout.addWidget(btn_load_preset)
        preset_layout.addWidget(btn_save_preset)
        preset_layout.addWidget(btn_manage_presets)

        left_layout.addWidget(left_header)
        left_layout.addWidget(self.cat_list_widget)
        left_layout.addLayout(cat_btn_layout)
        left_layout.addLayout(cat_order_layout)
        left_layout.addLayout(preset_layout)

        # 2. Center Panel: Category Content Editor + Formatting Tools
        center_widget = QWidget()
        center_layout = QVBoxLayout(center_widget)
        center_layout.setContentsMargins(2, 2, 2, 2)
        center_layout.setSpacing(6)

        self.center_header_label = QLabel("Select a category to edit content")
        
        format_tool_layout = QHBoxLayout()
        btn_para = QPushButton("1 Paragraph")
        btn_para.setToolTip("Remove line breaks and extra whitespace, converting to a single clean paragraph")
        btn_para.clicked.connect(self.format_to_paragraph)

        btn_clean = QPushButton("Clean Odd Chars")
        btn_clean.setToolTip("Remove semicolons, colons, dashes, and odd punctuation")
        btn_clean.clicked.connect(self.clean_odd_characters)

        btn_upper = QPushButton("UPPER")
        btn_upper.clicked.connect(lambda: self.convert_case("upper"))

        btn_lower = QPushButton("lower")
        btn_lower.clicked.connect(lambda: self.convert_case("lower"))

        format_tool_layout.addWidget(btn_para)
        format_tool_layout.addWidget(btn_clean)
        format_tool_layout.addWidget(btn_upper)
        format_tool_layout.addWidget(btn_lower)

        self.content_editor = QPlainTextEdit()
        self.content_editor.setPlaceholderText("Enter category content, details, or prompt components here...")
        self.content_editor.textChanged.connect(self.on_content_changed)

        center_layout.addWidget(self.center_header_label)
        center_layout.addLayout(format_tool_layout)
        center_layout.addWidget(self.content_editor)

        # 3. Right Panel: Prompt Output (with Format & Copy)
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(2, 2, 2, 2)
        right_layout.setSpacing(6)

        right_header_layout = QHBoxLayout()
        right_header = QLabel("Prompt Output")
        
        self.format_combo = QComboBox()
        self.format_combo.addItems(["Markdown", "Plain Text"])
        self.format_combo.currentIndexChanged.connect(self.update_markdown_output)

        btn_copy = QPushButton("Copy All Text")
        btn_copy.clicked.connect(self.copy_all_text)

        right_header_layout.addWidget(right_header)
        right_header_layout.addStretch()
        right_header_layout.addWidget(QLabel("Format:"))
        right_header_layout.addWidget(self.format_combo)
        right_header_layout.addWidget(btn_copy)

        self.markdown_output = QTextEdit()
        self.markdown_output.setReadOnly(True)
        self.markdown_output.setPlaceholderText("Prompt output will appear here...")

        right_layout.addLayout(right_header_layout)
        right_layout.addWidget(self.markdown_output)

        self.splitter.addWidget(left_widget)
        self.splitter.addWidget(center_widget)
        self.splitter.addWidget(right_widget)
        
        # Initial default sizes (overridden by restore_ui_state)
        self.splitter.setSizes(self.settings.get("splitter_sizes", [320, 480, 500]))

        main_layout.addWidget(self.splitter)

    # --- Category Preset Methods ---

    def save_category_preset(self):
        proj = self.get_current_project()
        if not proj:
            QMessageBox.warning(self, "Warning", "Please select a project first.")
            return

        categories = proj.get("categories", [])
        if not categories:
            QMessageBox.warning(self, "Warning", "Current project has no categories to save as a preset.")
            return

        name, ok = QInputDialog.getText(self, "Save Preset", "Enter a name for this category preset:")
        if ok and name.strip():
            preset_name = name.strip()
            preset_data = []
            for cat in categories:
                item = {
                    "name": cat["name"],
                    "is_dynamic": cat.get("is_dynamic", False)
                }
                if cat.get("is_dynamic", False):
                    item["default_placeholder"] = cat.get("default_placeholder", "Enter content for this clip...")
                else:
                    item["content"] = cat.get("content", "")
                preset_data.append(item)

            self.presets[preset_name] = preset_data
            self.save_presets()
            QMessageBox.information(self, "Success", f"Preset '{preset_name}' saved successfully!")

    def load_category_preset(self):
        proj = self.get_current_project()
        if not proj:
            QMessageBox.warning(self, "Warning", "Please select a project first.")
            return

        if not self.presets:
            QMessageBox.warning(self, "Warning", "No presets available.")
            return

        preset_names = list(self.presets.keys())
        selected_name, ok = QInputDialog.getItem(
            self, "Load Category Preset", "Select a preset to load into this project:",
            preset_names, 0, False
        )
        if not ok or not selected_name:
            return

        preset_cats = self.presets[selected_name]

        # Ask user whether to append or replace
        msg = QMessageBox(self)
        msg.setWindowTitle("Load Preset Options")
        msg.setText(f"How would you like to apply preset '{selected_name}'?")
        btn_append = msg.addButton("Append Categories", QMessageBox.ButtonRole.AcceptRole)
        btn_replace = msg.addButton("Replace All Categories", QMessageBox.ButtonRole.DestructiveRole)
        msg.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
        msg.exec()

        clicked = msg.clickedButton()
        if clicked == btn_replace:
            proj["categories"] = []
            for clip in proj.get("clips", []):
                clip["enabled_categories"] = []
                clip["dynamic_data"] = {}
        elif clicked != btn_append:
            return

        # Add categories from preset with fresh UUIDs
        new_cat_ids = []
        for item in preset_cats:
            cat_id = f"cat_{uuid.uuid4().hex[:8]}"
            new_cat = {
                "id": cat_id,
                "name": item["name"],
                "is_dynamic": item.get("is_dynamic", False)
            }
            if item.get("is_dynamic", False):
                new_cat["default_placeholder"] = item.get("default_placeholder", "Enter content for this clip...")
            else:
                new_cat["content"] = item.get("content", "")
            
            proj["categories"].append(new_cat)
            new_cat_ids.append(cat_id)

        # Enable new categories in all clips
        for clip in proj.get("clips", []):
            if "enabled_categories" not in clip:
                clip["enabled_categories"] = []
            for cid in new_cat_ids:
                if cid not in clip["enabled_categories"]:
                    clip["enabled_categories"].append(cid)

        self.save_current_project()
        self.load_categories_to_list()
        QMessageBox.information(self, "Success", f"Preset '{selected_name}' loaded successfully into the project!")

    def manage_category_presets(self):
        if not self.presets:
            QMessageBox.information(self, "Presets", "No presets found.")
            return

        preset_names = list(self.presets.keys())
        selected_name, ok = QInputDialog.getItem(
            self, "Manage Presets", "Select a preset to delete:",
            preset_names, 0, False
        )
        if ok and selected_name:
            reply = QMessageBox.question(
                self, "Delete Preset", f"Are you sure you want to delete preset '{selected_name}'?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.Yes:
                del self.presets[selected_name]
                self.save_presets()
                QMessageBox.information(self, "Deleted", f"Preset '{selected_name}' has been deleted.")

    # --- Project & Clip Management Helpers ---

    def get_current_project(self):
        for proj in self.projects:
            if proj["id"] == self.current_project_id:
                return proj
        return None

    def get_current_clip(self):
        proj = self.get_current_project()
        if proj:
            for clip in proj.get("clips", []):
                if clip["clip_id"] == self.current_clip_id:
                    return clip
        return None

    def get_current_category(self):
        proj = self.get_current_project()
        if proj:
            for cat in proj.get("categories", []):
                if cat["id"] == self.current_category_id:
                    return cat
        return None

    def load_projects_to_combo(self):
        self.is_updating_ui = True
        self.project_combo.clear()
        for proj in self.projects:
            self.project_combo.addItem(proj["project_title"], proj["id"])
        
        if self.projects:
            self.project_combo.setCurrentIndex(0)
            self.current_project_id = self.project_combo.currentData()
        else:
            self.current_project_id = None
        self.is_updating_ui = False
        self.load_clips_to_combo()

    def load_clips_to_combo(self):
        self.is_updating_ui = True
        self.clip_combo.clear()
        proj = self.get_current_project()
        if proj:
            for clip in proj.get("clips", []):
                self.clip_combo.addItem(clip["title"], clip["clip_id"])
            if proj.get("clips"):
                self.clip_combo.setCurrentIndex(0)
                self.current_clip_id = self.clip_combo.currentData()
            else:
                self.current_clip_id = None
        else:
            self.current_clip_id = None
        self.is_updating_ui = False
        self.load_categories_to_list()

    def load_categories_to_list(self):
        self.is_updating_ui = True
        previous_cat_id = self.current_category_id
        self.cat_list_widget.clear()
        proj = self.get_current_project()
        clip = self.get_current_clip()
        target_row = 0

        if proj:
            categories = proj.get("categories", [])
            enabled_set = set(clip.get("enabled_categories", [])) if clip else set()

            for idx, cat in enumerate(categories):
                cat_id = cat["id"]
                name = cat["name"]
                is_dyn = cat.get("is_dynamic", False)
                enabled = cat_id in enabled_set if clip else True

                status_str = "✓" if enabled else "✗ [Hidden]"
                dyn_str = " (Dynamic)" if is_dyn else ""
                item_text = f"{status_str}  {name}{dyn_str}"

                item = QListWidgetItem(item_text)
                item.setData(Qt.ItemDataRole.UserRole, cat_id)
                if not enabled:
                    item.setForeground(QColor("#888888" if self.palette().color(self.palette().ColorRole.Window).lightness() < 128 else "#777777"))
                self.cat_list_widget.addItem(item)

                if cat_id == previous_cat_id:
                    target_row = idx

            if categories:
                if target_row >= len(categories):
                    target_row = 0
                self.cat_list_widget.setCurrentRow(target_row)
                self.current_category_id = categories[target_row]["id"]
            else:
                self.current_category_id = None
                self.content_editor.clear()
                self.center_header_label.setText("No categories available")
        else:
            self.current_category_id = None
            self.content_editor.clear()
            if not self.projects:
                self.center_header_label.setText("Create a new project to begin")
            else:
                self.center_header_label.setText("No clip selected")

        self.is_updating_ui = False
        self.update_editor_content()
        self.update_markdown_output()

    def update_editor_content(self):
        proj = self.get_current_project()
        clip = self.get_current_clip()
        cat = self.get_current_category()
        self.is_updating_ui = True
        if proj and cat:
            cat_id = cat["id"]
            name = cat["name"]
            is_dyn = cat.get("is_dynamic", False)
            enabled = (clip and cat_id in clip.get("enabled_categories", [])) if clip else True
            status = " [Enabled]" if enabled else " [Hidden]"

            if is_dyn:
                content = clip.get("dynamic_data", {}).get(cat_id, "") if clip else ""
                type_label = " (Dynamic - Clip Specific)"
            else:
                content = cat.get("content", "")
                type_label = " (Global Asset)"

            self.center_header_label.setText(f"Editing: {name}{status}{type_label}")
            self.content_editor.setPlainText(content)
            self.content_editor.setEnabled(bool(clip))
        else:
            self.center_header_label.setText("Select a category")
            self.content_editor.clear()
            self.content_editor.setEnabled(False)
        self.is_updating_ui = False

    def update_markdown_output(self):
        proj = self.get_current_project()
        clip = self.get_current_clip()
        if not proj or not clip:
            self.markdown_output.clear()
            return

        fmt = self.format_combo.currentText() if hasattr(self, 'format_combo') else "Markdown"
        lines = []
        enabled_set = set(clip.get("enabled_categories", []))

        for cat in proj.get("categories", []):
            cat_id = cat["id"]
            if cat_id not in enabled_set:
                continue
            name = cat.get("name", "").strip()
            is_dyn = cat.get("is_dynamic", False)

            if is_dyn:
                content = clip.get("dynamic_data", {}).get(cat_id, "").strip()
            else:
                content = cat.get("content", "").strip()

            if content and name:
                if fmt == "Markdown":
                    lines.append(f"# {name}\n\n{content}\n")
                else:
                    lines.append(f"{name.upper()}:\n{content}\n")

        full_text = "\n".join(lines)
        self.markdown_output.setPlainText(full_text)

    def copy_all_text(self):
        clipboard = QApplication.clipboard()
        clipboard.setText(self.markdown_output.toPlainText())
        QMessageBox.information(self, "Copied", "All prompt output copied to clipboard!")

    def export_project_txt(self):
        proj = self.get_current_project()
        if not proj:
            QMessageBox.warning(self, "Warning", "No project selected.")
            return

        default_filename = f"{sanitize_filename(proj.get('project_title', 'project'))}.txt"
        file_path, _ = QFileDialog.getSaveFileName(self, "Export Project Portfolio TXT", default_filename, "Text Files (*.txt)")
        if file_path:
            try:
                fmt = self.format_combo.currentText() if hasattr(self, 'format_combo') else "Markdown"
                
                output_lines = []
                output_lines.append(f"PROJECT: {proj.get('project_title', 'Untitled Project')}")
                output_lines.append("=" * 60)
                output_lines.append("")

                for clip in proj.get("clips", []):
                    output_lines.append(f"CLIP: {clip.get('title', 'Untitled Shot')}")
                    output_lines.append("-" * 40)
                    
                    clip_lines = []
                    enabled_set = set(clip.get("enabled_categories", []))
                    for cat in proj.get("categories", []):
                        cat_id = cat["id"]
                        if cat_id not in enabled_set:
                            continue
                        name = cat.get("name", "").strip()
                        is_dyn = cat.get("is_dynamic", False)

                        if is_dyn:
                            content = clip.get("dynamic_data", {}).get(cat_id, "").strip()
                        else:
                            content = cat.get("content", "").strip()

                        if content and name:
                            if fmt == "Markdown":
                                clip_lines.append(f"# {name}\n\n{content}\n")
                            else:
                                clip_lines.append(f"{name.upper()}:\n{content}\n")

                    output_lines.append("\n".join(clip_lines))
                    output_lines.append("")
                    output_lines.append("=" * 60)
                    output_lines.append("")

                with open(file_path, "w", encoding="utf-8") as f:
                    f.write("\n".join(output_lines))

                QMessageBox.information(self, "Export Successful", f"Project portfolio exported successfully to:\n{file_path}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to export project: {e}")

    # --- Text Formatting Tool Methods ---

    def format_to_paragraph(self):
        text = self.content_editor.toPlainText()
        cleaned = " ".join(text.split())
        self.content_editor.setPlainText(cleaned)
        self.on_content_changed()

    def clean_odd_characters(self):
        text = self.content_editor.toPlainText()
        cleaned = re.sub(r'[;:\-—–]', '', text)
        cleaned = " ".join(cleaned.split())
        self.content_editor.setPlainText(cleaned)
        self.on_content_changed()

    def convert_case(self, mode):
        text = self.content_editor.toPlainText()
        if mode == "upper":
            self.content_editor.setPlainText(text.upper())
        elif mode == "lower":
            self.content_editor.setPlainText(text.lower())
        self.on_content_changed()

    # --- Slot Event Handlers ---

    def on_project_changed(self, index):
        if self.is_updating_ui or index < 0:
            return
        proj_id = self.project_combo.currentData()
        if proj_id:
            self.current_project_id = proj_id
            self.load_clips_to_combo()

    def on_clip_changed(self, index):
        if self.is_updating_ui or index < 0:
            return
        clip_id = self.clip_combo.currentData()
        if clip_id:
            self.current_clip_id = clip_id
            self.load_categories_to_list()

    def on_category_selected(self, row):
        if self.is_updating_ui or row < 0:
            return
        item = self.cat_list_widget.item(row)
        if item:
            self.current_category_id = item.data(Qt.ItemDataRole.UserRole)
            self.update_editor_content()

    def on_content_changed(self):
        if self.is_updating_ui:
            return
        proj = self.get_current_project()
        clip = self.get_current_clip()
        cat = self.get_current_category()
        if not proj or not clip or not cat:
            return

        new_text = self.content_editor.toPlainText()
        cat_id = cat["id"]
        is_dyn = cat.get("is_dynamic", False)

        if is_dyn:
            if "dynamic_data" not in clip:
                clip["dynamic_data"] = {}
            clip["dynamic_data"][cat_id] = new_text
        else:
            cat["content"] = new_text

        self.save_current_project()
        self.update_markdown_output()

    def toggle_category_enabled_by_item(self, item):
        if not item:
            return
        cat_id = item.data(Qt.ItemDataRole.UserRole)
        clip = self.get_current_clip()
        proj = self.get_current_project()
        if clip and proj:
            if "enabled_categories" not in clip:
                clip["enabled_categories"] = [c["id"] for c in proj.get("categories", [])]
            
            enabled_set = set(clip["enabled_categories"])
            if cat_id in enabled_set:
                enabled_set.remove(cat_id)
            else:
                enabled_set.add(cat_id)
            
            clip["enabled_categories"] = [c["id"] for c in proj.get("categories", []) if c["id"] in enabled_set]
            
            self.save_current_project()
            self.load_categories_to_list()

    def toggle_category_enabled_current(self):
        item = self.cat_list_widget.currentItem()
        if item:
            self.toggle_category_enabled_by_item(item)

    def toggle_category_type(self):
        proj = self.get_current_project()
        cat = self.get_current_category()
        if not proj or not cat:
            QMessageBox.warning(self, "Warning", "Please select a category first.")
            return

        is_currently_dyn = cat.get("is_dynamic", False)
        
        if not is_currently_dyn:
            reply = QMessageBox.question(
                self, "Convert to Dynamic",
                f"Convert category '{cat['name']}' to Dynamic (per-clip content)?\nExisting content will be copied to all clips as a starting point.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.Yes:
                global_content = cat.get("content", "")
                cat["is_dynamic"] = True
                if "content" in cat:
                    del cat["content"]
                cat["default_placeholder"] = "Enter content for this clip..."
                
                for clip in proj.get("clips", []):
                    if "dynamic_data" not in clip:
                        clip["dynamic_data"] = {}
                    if cat["id"] not in clip["dynamic_data"]:
                        clip["dynamic_data"][cat["id"]] = global_content

                self.save_current_project()
                self.load_categories_to_list()
                QMessageBox.information(self, "Success", "Category converted to Dynamic successfully.")
        else:
            reply = QMessageBox.warning(
                self, "Convert to Static (Warning)",
                f"Convert category '{cat['name']}' to Static (Global Asset)?\n\nWARNING: Dynamic categories have separate text per clip. Converting to static will take the text from the CURRENT active clip as the global master content, and clip-specific variations in other clips will be lost!\n\nDo you wish to proceed?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.Yes:
                clip = self.get_current_clip()
                active_content = ""
                if clip and "dynamic_data" in clip:
                    active_content = clip["dynamic_data"].get(cat["id"], "")

                cat["is_dynamic"] = False
                cat["content"] = active_content
                if "default_placeholder" in cat:
                    del cat["default_placeholder"]

                for c in proj.get("clips", []):
                    if "dynamic_data" in c and cat["id"] in c["dynamic_data"]:
                        del c["dynamic_data"][cat["id"]]

                self.save_current_project()
                self.load_categories_to_list()
                QMessageBox.information(self, "Success", "Category converted to Static successfully.")

    # --- Project Actions ---

    def create_new_project(self):
        name, ok = QInputDialog.getText(self, "New Project", "Enter project title:")
        if ok and name.strip():
            title = name.strip()
            new_proj = {
                "project_title": title,
                "version": "2.0",
                "categories": [
                    {"id": f"cat_{uuid.uuid4().hex[:8]}", "name": "Rules", "is_dynamic": False, "content": "Film perspective, cinematic continuity rules..."},
                    {"id": f"cat_{uuid.uuid4().hex[:8]}", "name": "Style", "is_dynamic": False, "content": "Cinematic realism, high-end photography..."},
                    {"id": f"cat_{uuid.uuid4().hex[:8]}", "name": "Action / Beat", "is_dynamic": True, "default_placeholder": "Describe scene action..."}
                ],
                "clips": [
                    {
                        "clip_id": f"clip_{uuid.uuid4().hex[:8]}",
                        "order": 1,
                        "title": "Shot 1 - Opening",
                        "enabled_categories": [],
                        "dynamic_data": {}
                    }
                ],
                "id": str(uuid.uuid4())
            }
            new_proj["clips"][0]["enabled_categories"] = [c["id"] for c in new_proj["categories"]]

            self.projects.append(new_proj)
            self.current_project_id = new_proj["id"]
            self.save_current_project()
            self.load_projects_to_combo()
            for i in range(self.project_combo.count()):
                if self.project_combo.itemData(i) == new_proj["id"]:
                    self.project_combo.setCurrentIndex(i)
                    break

    def rename_current_project(self):
        proj = self.get_current_project()
        if not proj:
            QMessageBox.warning(self, "Warning", "No project selected.")
            return
        name, ok = QInputDialog.getText(self, "Rename Project", "Enter new project title:", text=proj["project_title"])
        if ok and name.strip():
            proj["project_title"] = name.strip()
            self.save_current_project()
            self.load_projects_to_combo()
            for i in range(self.project_combo.count()):
                if self.project_combo.itemData(i) == proj["id"]:
                    self.project_combo.setCurrentIndex(i)
                    break

    def delete_current_project(self):
        proj = self.get_current_project()
        if not proj:
            return
        
        reply = QMessageBox.question(self, "Delete Project", f"Are you sure you want to delete project '{proj['project_title']}'?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            if "_filename" in proj and proj["_filename"]:
                filepath = os.path.join(DATA_DIR, proj["_filename"])
                if os.path.exists(filepath):
                    try:
                        os.remove(filepath)
                    except Exception as e:
                        print(f"Error removing file: {e}")
            
            self.projects = [p for p in self.projects if p["id"] != proj["id"]]
            self.load_projects_to_combo()

    # --- Clip Actions ---

    def create_new_clip(self):
        proj = self.get_current_project()
        if not proj:
            QMessageBox.warning(self, "Warning", "Please create or select a project first.")
            return
        name, ok = QInputDialog.getText(self, "New Clip", "Enter clip/shot title:")
        if ok and name.strip():
            last_clip = proj["clips"][-1] if proj["clips"] else None
            enabled_cats = copy.deepcopy(last_clip.get("enabled_categories", [])) if last_clip else [c["id"] for c in proj.get("categories", [])]
            dyn_data = copy.deepcopy(last_clip.get("dynamic_data", {})) if last_clip else {}

            new_clip = {
                "clip_id": f"clip_{uuid.uuid4().hex[:8]}",
                "order": len(proj["clips"]) + 1,
                "title": name.strip(),
                "enabled_categories": enabled_cats,
                "dynamic_data": dyn_data
            }
            proj["clips"].append(new_clip)
            self.save_current_project()
            self.load_clips_to_combo()
            self.clip_combo.setCurrentIndex(self.clip_combo.count() - 1)

    def rename_current_clip(self):
        clip = self.get_current_clip()
        if not clip:
            QMessageBox.warning(self, "Warning", "No clip selected.")
            return
        name, ok = QInputDialog.getText(self, "Rename Clip", "Enter new clip title:", text=clip["title"])
        if ok and name.strip():
            clip["title"] = name.strip()
            self.save_current_project()
            self.load_clips_to_combo()
            for i in range(self.clip_combo.count()):
                if self.clip_combo.itemData(i) == clip["clip_id"]:
                    self.clip_combo.setCurrentIndex(i)
                    break

    def delete_current_clip(self):
        proj = self.get_current_project()
        clip = self.get_current_clip()
        if not proj or not clip:
            return

        reply = QMessageBox.question(self, "Delete Clip", f"Are you sure you want to delete clip '{clip['title']}'?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            proj["clips"] = [c for c in proj["clips"] if c["clip_id"] != clip["clip_id"]]
            self.save_current_project()
            self.load_clips_to_combo()

    # --- Category Actions ---

    def add_category(self):
        proj = self.get_current_project()
        clip = self.get_current_clip()
        if not proj:
            QMessageBox.warning(self, "Warning", "Please create or select a project first.")
            return
        
        name, ok = QInputDialog.getText(self, "Add Global Category", "Enter category name (e.g. Character - Hero, Action):")
        if ok and name.strip():
            cat_name = name.strip()
            
            dyn_item, dyn_ok = QInputDialog.getItem(
                self, "Category Type", 
                "Is this category dynamic (changes per clip) or static (global asset shared across all clips)?",
                ["Static (Global Asset)", "Dynamic (Per-Clip Content)"], 0, False
            )
            is_dynamic = (dyn_ok and dyn_item.startswith("Dynamic"))

            cat_id = f"cat_{uuid.uuid4().hex[:8]}"
            new_cat = {
                "id": cat_id,
                "name": cat_name,
                "is_dynamic": is_dynamic
            }
            if is_dynamic:
                new_cat["default_placeholder"] = "Enter content for this clip..."
            else:
                new_cat["content"] = ""

            if "categories" not in proj:
                proj["categories"] = []
            proj["categories"].append(new_cat)

            for c in proj.get("clips", []):
                if "enabled_categories" not in c:
                    c["enabled_categories"] = []
                c["enabled_categories"].append(cat_id)

            self.save_current_project()
            self.load_categories_to_list()
            for i in range(self.cat_list_widget.count()):
                item = self.cat_list_widget.item(i)
                if item.data(Qt.ItemDataRole.UserRole) == cat_id:
                    self.cat_list_widget.setCurrentRow(i)
                    break

    def rename_category(self):
        proj = self.get_current_project()
        cat = self.get_current_category()
        if not proj or not cat:
            return

        name, ok = QInputDialog.getText(self, "Rename Category", "Enter new category name:", text=cat["name"])
        if ok and name.strip():
            cat["name"] = name.strip()
            self.save_current_project()
            self.load_categories_to_list()

    def delete_category(self):
        proj = self.get_current_project()
        cat = self.get_current_category()
        if not proj or not cat:
            return

        reply = QMessageBox.question(
            self, "Delete Global Category", 
            f"Are you sure you want to permanently delete global category '{cat['name']}' from the project?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            cat_id = cat["id"]
            proj["categories"] = [c for c in proj["categories"] if c["id"] != cat_id]
            for c in proj.get("clips", []):
                if "enabled_categories" in c and cat_id in c["enabled_categories"]:
                    c["enabled_categories"].remove(cat_id)
                if "dynamic_data" in c and cat_id in c["dynamic_data"]:
                    del c["dynamic_data"][cat_id]

            self.save_current_project()
            self.load_categories_to_list()

    def move_category(self, direction):
        proj = self.get_current_project()
        if not proj:
            return
        categories = proj.get("categories", [])
        row = self.cat_list_widget.currentRow()
        new_row = row + direction
        if 0 <= new_row < len(categories):
            categories[row], categories[new_row] = categories[new_row], categories[row]
            for clip in proj.get("clips", []):
                if "enabled_categories" in clip:
                    enabled_set = set(clip["enabled_categories"])
                    clip["enabled_categories"] = [c["id"] for c in categories if c["id"] in enabled_set]
            self.save_current_project()
            self.load_categories_to_list()
            self.cat_list_widget.setCurrentRow(new_row)
            self.update_markdown_output()

    def nuke_database(self):
        reply = QMessageBox.warning(
            self,
            "Nuke Database",
            "WARNING: This will delete ALL project files permanently from 'storyboarder_data' folder!\nAre you absolutely sure?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            if os.path.exists(DATA_DIR):
                for filename in os.listdir(DATA_DIR):
                    if filename.endswith(".json"):
                        try:
                            os.remove(os.path.join(DATA_DIR, filename))
                        except Exception as e:
                            print(f"Error removing {filename}: {e}")
            self.projects = self.load_all_projects()
            self.load_projects_to_combo()
            QMessageBox.information(self, "Database Reset", "All projects cleared and reset.")

def main():
    app = QApplication(sys.argv)
    window = StoryboarderApp()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
