#!/usr/bin/env bash
set -e

# Target directory
TARGET_DIR="$HOME/Desktop/cpu_temp_alarm"
cd "$TARGET_DIR"

echo "[*] Setting up Python virtual environment..."
if [ ! -d ".venv" ]; then
    python3 -m venv .venv
fi
source .venv/bin/activate

echo "[*] Upgrading pip and installing requirements..."
pip install --upgrade pip
pip install -r requirements.txt

echo "[*] Generating application icon using PyQt6..."
python3 -c "
from PyQt6.QtGui import QImage, QPainter, QColor, QBrush
from PyQt6.QtCore import Qt

img = QImage(256, 256, QImage.Format.Format_ARGB32)
img.fill(Qt.GlobalColor.transparent)
painter = QPainter(img)
painter.setRenderHint(QPainter.RenderHint.Antialiasing)

# Draw thermometer body
painter.setBrush(QBrush(QColor(53, 132, 228)))
painter.setPen(Qt.PenStyle.NoPen)
painter.drawRoundedRect(96, 32, 64, 160, 32, 32)

# Bulb
painter.setBrush(QBrush(QColor(224, 27, 36)))
painter.drawEllipse(80, 160, 96, 96)

# Inner highlight
painter.setBrush(QBrush(QColor(255, 255, 255, 220)))
painter.drawRect(112, 64, 32, 110)
painter.end()
img.save('icon.png')
print('Icon generated successfully: icon.png')
"

echo "[*] Creating XDG Desktop entry in ~/.local/share/applications/..."
mkdir -p "$HOME/.local/share/applications"
cat << EOF > "$HOME/.local/share/applications/cpu-temp-alarm.desktop"
[Desktop Entry]
Type=Application
Name=CPU Temp Alarm
Comment=Monitor CPU temperatures and trigger multi-tiered audio alerts
Exec=$TARGET_DIR/.venv/bin/python $TARGET_DIR/main.py
Icon=$TARGET_DIR/icon.png
Terminal=false
Categories=System;Monitor;Utility;Qt;
StartupNotify=true
EOF

echo "[*] Creating Desktop shortcut..."
cp "$HOME/.local/share/applications/cpu-temp-alarm.desktop" "$HOME/Desktop/cpu-temp-alarm.desktop"
chmod +x "$HOME/Desktop/cpu-temp-alarm.desktop"
gio set "$HOME/Desktop/cpu-temp-alarm.desktop" metadata::trusted true 2>/dev/null || true

echo "[+] Setup completed successfully!"
