#!/usr/bin/env python3
import sys
import os
import json
import time
from pathlib import Path
import numpy as np
import sounddevice as sd
import psutil

from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt6.QtGui import QIcon, QPalette, QColor, QAction
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QPushButton,
    QVBoxLayout, QHBoxLayout, QTabWidget, QSlider, QSpinBox,
    QCheckBox, QGroupBox, QFormLayout, QSystemTrayIcon, QMenu,
    QMessageBox, QFrame
)

CONFIG_DIR = Path.home() / ".config" / "cpu_temp_alarm"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULT_CONFIG = {
    "polling_interval": 5,
    "alarm_repeat_interval": 10,
    "min_alert_temp": 60.0,
    "tier1_temp": 55.0,
    "tier2_temp": 65.0,
    "tier3_temp": 75.0,
    "tier4_temp": 85.0,
    "base_freq": 880,
    "volume": 50,
    "dynamic_freq_scaling": False,
    "beep_duration_ms": 150,
    "inter_beep_ms": 100,
    "muted": False,
    "simulation_mode": False
}

def load_config():
    try:
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE, "r") as f:
                cfg = json.load(f)
                return {**DEFAULT_CONFIG, **cfg}
    except Exception as e:
        print(f"Error loading config: {e}")
    return DEFAULT_CONFIG.copy()

def save_config(cfg):
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        with open(CONFIG_FILE, "w") as f:
            json.dump(cfg, f, indent=4)
    except Exception as e:
        print(f"Error saving config: {e}")


def synthesize_pattern_audio(freq, duration_ms, inter_beep_ms, count, volume):
    """
    Synthesizes a multi-beep pattern as a single concatenated NumPy buffer
    with attack/release fade envelopes and volume scaling.
    """
    fs = 44100
    dur_sec = duration_ms / 1000.0
    gap_sec = inter_beep_ms / 1000.0
    
    t_beep = np.linspace(0, dur_sec, int(fs * dur_sec), endpoint=False)
    # Attack/release envelope (10ms fade in/out) to prevent audio clicks
    fade_len = int(fs * 0.01)
    envelope = np.ones_like(t_beep)
    if len(t_beep) > 2 * fade_len:
        envelope[:fade_len] = np.linspace(0, 1, fade_len)
        envelope[-fade_len:] = np.linspace(1, 0, fade_len)
    
    # Base amplitude scaled by volume (0 to 100)
    amp = (max(0.0, min(100.0, volume)) / 100.0) * 0.35
    beep_wave = amp * np.sin(2 * np.pi * freq * t_beep) * envelope

    if count <= 1 or gap_sec <= 0:
        return beep_wave

    gap_samples = int(fs * gap_sec)
    silence = np.zeros(gap_samples)

    parts = []
    for i in range(count):
        parts.append(beep_wave)
        if i < count - 1:
            parts.append(silence)

    return np.concatenate(parts)


class ThermalWorker(QThread):
    temperatureUpdated = pyqtSignal(float, dict, str)

    def __init__(self, interval=5, simulation=False):
        super().__init__()
        self.interval = interval
        self.simulation = simulation
        self._running = True
        self.sim_temp = 50.0

    def run(self):
        while self._running:
            temp = 0.0
            sensors_info = {}
            status_source = "None"

            if self.simulation:
                self.sim_temp += np.random.uniform(-1.5, 2.0)
                self.sim_temp = max(40.0, min(95.0, self.sim_temp))
                temp = self.sim_temp
                sensors_info = {"simulation": [{"current": temp}]}
                status_source = "Simulation Mode"
            else:
                try:
                    temps = psutil.sensors_temperatures()
                    if temps:
                        priority_keys = ["coretemp", "k10temp", "acpitz", "cpu_thermal", "soc_thermal", "cpu"]
                        chosen_key = None
                        for pk in priority_keys:
                            for key in temps:
                                if pk in key.lower():
                                    chosen_key = key
                                    break
                            if chosen_key:
                                break
                        
                        if not chosen_key and temps:
                            chosen_key = list(temps.keys())[0]

                        if chosen_key:
                            sensor_list = temps[chosen_key]
                            sensors_info = {chosen_key: [{"label": s.label, "current": s.current} for s in sensor_list]}
                            valid_temps = [s.current for s in sensor_list if s.current > 0]
                            if valid_temps:
                                temp = max(valid_temps)
                                status_source = chosen_key
                    if temp == 0.0:
                        temp = 45.0
                        status_source = "Fallback (No sensor found)"
                except Exception as e:
                    print(f"Error reading sensors: {e}")
                    temp = 45.0
                    status_source = "Error / Fallback"

            self.temperatureUpdated.emit(temp, sensors_info, status_source)
            
            elapsed = 0
            while elapsed < self.interval and self._running:
                time.sleep(0.2)
                elapsed += 0.2

    def stop(self):
        self._running = False
        self.wait()

    def update_interval(self, new_interval):
        self.interval = new_interval


class AudioWorker(QThread):
    def __init__(self):
        super().__init__()
        self._running = True
        self.play_request = None

    def play_alarm(self, freq, duration_ms, pattern_count, inter_beep_ms, volume):
        self.play_request = {
            "freq": freq,
            "duration_ms": duration_ms,
            "count": pattern_count,
            "inter_ms": inter_beep_ms,
            "volume": volume
        }

    def run(self):
        fs = 44100
        while self._running:
            if self.play_request:
                req = self.play_request
                self.play_request = None
                try:
                    audio_buf = synthesize_pattern_audio(
                        freq=req["freq"],
                        duration_ms=req["duration_ms"],
                        inter_beep_ms=req["inter_ms"],
                        count=req["count"],
                        volume=req["volume"]
                    )
                    sd.play(audio_buf, fs, blocking=True)
                except Exception as e:
                    print(f"Audio playback error: {e}")
            else:
                time.sleep(0.05)

    def stop(self):
        self._running = False
        self.wait()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.config = load_config()
        self.muted = self.config.get("muted", False)
        self.paused = False
        self.current_temp = 0.0
        self.last_alarm_time = 0.0

        self.init_ui()
        self.init_tray()
        self.init_workers()

    def init_ui(self):
        self.setWindowTitle("CPU Temp Alarm")
        self.setFixedSize(620, 520)

        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)

        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(12, 12, 12, 12)

        # Tab Widget
        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)

        # Tabs
        self.tab_dashboard = QWidget()
        self.tab_thresholds = QWidget()
        self.tab_audio = QWidget()
        self.tab_polling = QWidget()

        self.tabs.addTab(self.tab_dashboard, "Dashboard")
        self.tabs.addTab(self.tab_thresholds, "Thresholds")
        self.tabs.addTab(self.tab_audio, "Audio & Patterns")
        self.tabs.addTab(self.tab_polling, "Polling & Intervals")

        self.setup_dashboard_tab()
        self.setup_thresholds_tab()
        self.setup_audio_tab()
        self.setup_polling_tab()

    def setup_dashboard_tab(self):
        layout = QVBoxLayout(self.tab_dashboard)

        # Status Display Group
        status_group = QGroupBox("Live Thermal Status")
        status_layout = QVBoxLayout(status_group)

        self.temp_label = QLabel("-- °C")
        self.temp_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.temp_label.setStyleSheet("font-size: 48px; font-weight: bold; color: #3584e4;")
        status_layout.addWidget(self.temp_label)

        self.tier_badge = QLabel("Status: Normal")
        self.tier_badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.tier_badge.setStyleSheet("font-size: 16px; font-weight: bold; padding: 6px; background-color: #2ec27e; color: white; border-radius: 4px;")
        status_layout.addWidget(self.tier_badge)

        self.source_label = QLabel("Sensor Source: Detecting...")
        self.source_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.source_label.setStyleSheet("color: gray; font-size: 12px;")
        status_layout.addWidget(self.source_label)

        layout.addWidget(status_group)

        # Quick Toggles Group
        toggles_group = QGroupBox("Quick Controls")
        toggles_layout = QHBoxLayout(toggles_group)

        self.mute_btn = QPushButton("Mute Audio")
        self.mute_btn.setCheckable(True)
        self.mute_btn.setChecked(self.muted)
        self.mute_btn.clicked.connect(self.toggle_mute)
        toggles_layout.addWidget(self.mute_btn)

        self.pause_btn = QPushButton("Pause Monitoring")
        self.pause_btn.setCheckable(True)
        self.pause_btn.setChecked(self.paused)
        self.pause_btn.clicked.connect(self.toggle_pause)
        toggles_layout.addWidget(self.pause_btn)

        self.test_sound_btn = QPushButton("Test Sound")
        self.test_sound_btn.clicked.connect(self.test_audio_playback)
        toggles_layout.addWidget(self.test_sound_btn)

        layout.addWidget(toggles_group)

    def setup_thresholds_tab(self):
        layout = QFormLayout(self.tab_thresholds)

        self.min_alert_spin = QSpinBox()
        self.min_alert_spin.setRange(30, 110)
        self.min_alert_spin.setValue(int(self.config.get("min_alert_temp", 60)))
        self.min_alert_spin.valueChanged.connect(self.update_settings_from_ui)
        layout.addRow("Minimum Alert Temp (°C):", self.min_alert_spin)

        self.tier1_spin = QSpinBox()
        self.tier1_spin.setRange(30, 100)
        self.tier1_spin.setValue(int(self.config.get("tier1_temp", 55)))
        self.tier1_spin.valueChanged.connect(self.update_settings_from_ui)
        layout.addRow("Tier 1 (Warm) Threshold (°C):", self.tier1_spin)

        self.tier2_spin = QSpinBox()
        self.tier2_spin.setRange(40, 105)
        self.tier2_spin.setValue(int(self.config.get("tier2_temp", 65)))
        self.tier2_spin.valueChanged.connect(self.update_settings_from_ui)
        layout.addRow("Tier 2 (Elevated) Threshold (°C):", self.tier2_spin)

        self.tier3_spin = QSpinBox()
        self.tier3_spin.setRange(50, 110)
        self.tier3_spin.setValue(int(self.config.get("tier3_temp", 75)))
        self.tier3_spin.valueChanged.connect(self.update_settings_from_ui)
        layout.addRow("Tier 3 (High) Threshold (°C):", self.tier3_spin)

        self.tier4_spin = QSpinBox()
        self.tier4_spin.setRange(60, 120)
        self.tier4_spin.setValue(int(self.config.get("tier4_temp", 85)))
        self.tier4_spin.valueChanged.connect(self.update_settings_from_ui)
        layout.addRow("Tier 4 (Critical) Threshold (°C):", self.tier4_spin)

    def setup_audio_tab(self):
        layout = QFormLayout(self.tab_audio)

        # Dynamic Frequency Scaling Toggle
        self.dynamic_freq_check = QCheckBox("Enable Dynamic Temperature-Based Frequency Scaling")
        self.dynamic_freq_check.setChecked(bool(self.config.get("dynamic_freq_scaling", False)))
        self.dynamic_freq_check.stateChanged.connect(self.update_settings_from_ui)
        layout.addRow("Frequency Mode:", self.dynamic_freq_check)

        # Base Frequency Slider
        self.freq_slider = QSlider(Qt.Orientation.Horizontal)
        self.freq_slider.setRange(200, 2500)
        self.freq_slider.setValue(int(self.config.get("base_freq", 880)))
        self.freq_label = QLabel(f"{self.freq_slider.value()} Hz")
        self.freq_slider.valueChanged.connect(lambda v: (self.freq_label.setText(f"{v} Hz"), self.update_settings_from_ui()))
        
        freq_layout = QHBoxLayout()
        freq_layout.addWidget(self.freq_slider)
        freq_layout.addWidget(self.freq_label)
        layout.addRow("Base Audio Frequency (Static Mode):", freq_layout)

        # Volume Slider
        self.vol_slider = QSlider(Qt.Orientation.Horizontal)
        self.vol_slider.setRange(0, 100)
        self.vol_slider.setValue(int(self.config.get("volume", 50)))
        self.vol_label = QLabel(f"{self.vol_slider.value()}%")
        self.vol_slider.valueChanged.connect(lambda v: (self.vol_label.setText(f"{v}%"), self.update_settings_from_ui()))

        vol_layout = QHBoxLayout()
        vol_layout.addWidget(self.vol_slider)
        vol_layout.addWidget(self.vol_label)
        layout.addRow("Volume Level:", vol_layout)

        self.dur_spin = QSpinBox()
        self.dur_spin.setRange(50, 1000)
        self.dur_spin.setValue(int(self.config.get("beep_duration_ms", 150)))
        self.dur_spin.valueChanged.connect(self.update_settings_from_ui)
        layout.addRow("Beep Duration (ms):", self.dur_spin)

        self.gap_spin = QSpinBox()
        self.gap_spin.setRange(0, 1000)
        self.gap_spin.setValue(int(self.config.get("inter_beep_ms", 100)))
        self.gap_spin.valueChanged.connect(self.update_settings_from_ui)
        layout.addRow("Inter-Beep Gap (ms):", self.gap_spin)

    def setup_polling_tab(self):
        layout = QFormLayout(self.tab_polling)

        # Polling Interval (Sensors)
        self.poll_slider = QSlider(Qt.Orientation.Horizontal)
        self.poll_slider.setRange(1, 30)
        self.poll_slider.setValue(int(self.config.get("polling_interval", 5)))
        self.poll_label = QLabel(f"{self.poll_slider.value()} s")
        self.poll_slider.valueChanged.connect(lambda v: (self.poll_label.setText(f"{v} s"), self.update_polling_interval(v)))

        poll_layout = QHBoxLayout()
        poll_layout.addWidget(self.poll_slider)
        poll_layout.addWidget(self.poll_label)
        layout.addRow("Hardware Polling Interval:", poll_layout)

        # Alarm Repeat Interval (Cooldown between alert cycles)
        self.repeat_slider = QSlider(Qt.Orientation.Horizontal)
        self.repeat_slider.setRange(1, 30)
        self.repeat_slider.setValue(int(self.config.get("alarm_repeat_interval", 10)))
        self.repeat_label = QLabel(f"{self.repeat_slider.value()} s")
        self.repeat_slider.valueChanged.connect(lambda v: (self.repeat_label.setText(f"{v} s"), self.update_settings_from_ui()))

        repeat_layout = QHBoxLayout()
        repeat_layout.addWidget(self.repeat_slider)
        repeat_layout.addWidget(self.repeat_label)
        layout.addRow("Alarm Repeat Interval (Cooldown):", repeat_layout)

        self.sim_check = QCheckBox("Enable Simulation Mode (Test without real hardware sensors)")
        self.sim_check.setChecked(bool(self.config.get("simulation_mode", False)))
        self.sim_check.stateChanged.connect(self.toggle_simulation_mode)
        layout.addRow("Simulation:", self.sim_check)

    def init_tray(self):
        self.tray_icon = QSystemTrayIcon(self)
        
        icon_path = Path(__file__).parent / "icon.png"
        if icon_path.exists():
            self.setWindowIcon(QIcon(str(icon_path)))
            self.tray_icon.setIcon(QIcon(str(icon_path)))
        else:
            self.tray_icon.setIcon(self.style().standardIcon(QSystemTrayIcon.MessageIcon.Information))

        tray_menu = QMenu()
        show_action = QAction("Show / Hide", self)
        show_action.triggered.connect(self.toggle_window_visibility)
        tray_menu.addAction(show_action)

        mute_action = QAction("Mute / Unmute Audio", self)
        mute_action.triggered.connect(lambda: self.mute_btn.click())
        tray_menu.addAction(mute_action)

        tray_menu.addSeparator()
        quit_action = QAction("Quit", self)
        quit_action.triggered.connect(QApplication.quit)
        tray_menu.addAction(quit_action)

        self.tray_icon.setContextMenu(tray_menu)
        self.tray_icon.show()
        self.tray_icon.activated.connect(self.tray_icon_activated)

    def tray_icon_activated(self, reason):
        if reason == QSystemTrayIcon.ActivationReason.Trigger:
            self.toggle_window_visibility()

    def toggle_window_visibility(self):
        if self.isVisible():
            self.hide()
        else:
            self.show()
            self.raise_()
            self.activateWindow()

    def init_workers(self):
        self.audio_worker = AudioWorker()
        self.audio_worker.start()

        sim_mode = self.config.get("simulation_mode", False)
        poll_int = self.config.get("polling_interval", 5)
        self.thermal_worker = ThermalWorker(interval=poll_int, simulation=sim_mode)
        self.thermal_worker.temperatureUpdated.connect(self.on_temperature_updated)
        self.thermal_worker.start()

    def on_temperature_updated(self, temp, sensors_info, source):
        if self.paused:
            return

        self.current_temp = temp
        self.temp_label.setText(f"{temp:.1f} °C")
        self.source_label.setText(f"Sensor Source: {source}")
        self.tray_icon.setToolTip(f"CPU Temp Alarm: {temp:.1f} °C ({source})")

        t1 = self.tier1_spin.value()
        t2 = self.tier2_spin.value()
        t3 = self.tier3_spin.value()
        t4 = self.tier4_spin.value()
        min_alert = self.min_alert_spin.value()
        dynamic_scaling = self.dynamic_freq_check.isChecked()
        base_freq = self.freq_slider.value()
        volume = self.vol_slider.value()

        badge_text = "Status: Normal"
        badge_style = "font-size: 16px; font-weight: bold; padding: 6px; background-color: #2ec27e; color: white; border-radius: 4px;"
        tier_level = 0
        freq = base_freq
        pattern_count = 1

        if temp >= t4:
            badge_text = f"CRITICAL THERMAL LEVEL ({temp:.1f}°C)!"
            badge_style = "font-size: 16px; font-weight: bold; padding: 6px; background-color: #e01b24; color: white; border-radius: 4px;"
            tier_level = 4
            freq = 1800 if dynamic_scaling else base_freq
            pattern_count = 4
        elif temp >= t3:
            badge_text = f"HIGH TEMPERATURE WARNING ({temp:.1f}°C)"
            badge_style = "font-size: 16px; font-weight: bold; padding: 6px; background-color: #ff7800; color: white; border-radius: 4px;"
            tier_level = 3
            freq = 1400 if dynamic_scaling else base_freq
            pattern_count = 3
        elif temp >= t2:
            badge_text = f"ELEVATED TEMPERATURE ({temp:.1f}°C)"
            badge_style = "font-size: 16px; font-weight: bold; padding: 6px; background-color: #f6d32d; color: #2e3436; border-radius: 4px;"
            tier_level = 2
            freq = 900 if dynamic_scaling else base_freq
            pattern_count = 2
        elif temp >= t1:
            badge_text = f"WARM ({temp:.1f}°C)"
            badge_style = "font-size: 16px; font-weight: bold; padding: 6px; background-color: #3584e4; color: white; border-radius: 4px;"
            tier_level = 1
            freq = 500 if dynamic_scaling else base_freq
            pattern_count = 1
        else:
            badge_text = f"Normal ({temp:.1f}°C)"
            badge_style = "font-size: 16px; font-weight: bold; padding: 6px; background-color: #2ec27e; color: white; border-radius: 4px;"
            tier_level = 0

        self.tier_badge.setText(badge_text)
        self.tier_badge.setStyleSheet(badge_style)

        # Trigger audio alarm governed strictly by Alarm Repeat Interval (Cooldown)
        if not self.muted and tier_level > 0 and temp >= min_alert:
            current_time = time.time()
            repeat_interval = self.repeat_slider.value()
            if current_time - self.last_alarm_time >= repeat_interval:
                self.last_alarm_time = current_time
                dur = self.dur_spin.value()
                gap = self.gap_spin.value()
                self.audio_worker.play_alarm(freq, dur, pattern_count, gap, volume)

    def toggle_mute(self, checked):
        self.muted = checked
        self.update_settings_from_ui()

    def toggle_pause(self, checked):
        self.paused = checked
        if self.paused:
            self.tier_badge.setText("Paused")
            self.tier_badge.setStyleSheet("font-size: 16px; font-weight: bold; padding: 6px; background-color: gray; color: white; border-radius: 4px;")

    def toggle_simulation_mode(self, state):
        sim = bool(self.sim_check.isChecked())
        if self.thermal_worker:
            self.thermal_worker.stop()
        poll_int = self.poll_slider.value()
        self.thermal_worker = ThermalWorker(interval=poll_int, simulation=sim)
        self.thermal_worker.temperatureUpdated.connect(self.on_temperature_updated)
        self.thermal_worker.start()
        self.update_settings_from_ui()

    def update_polling_interval(self, val):
        if self.thermal_worker:
            self.thermal_worker.update_interval(val)
        self.update_settings_from_ui()

    def test_audio_playback(self):
        freq = self.freq_slider.value()
        dur = self.dur_spin.value()
        gap = self.gap_spin.value()
        volume = self.vol_slider.value()
        # Test sound plays a double pattern honoring current volume & base frequency
        self.audio_worker.play_alarm(freq, dur, 2, gap, volume)

    def update_settings_from_ui(self):
        self.config["polling_interval"] = self.poll_slider.value()
        self.config["alarm_repeat_interval"] = self.repeat_slider.value()
        self.config["min_alert_temp"] = self.min_alert_spin.value()
        self.config["tier1_temp"] = self.tier1_spin.value()
        self.config["tier2_temp"] = self.tier2_spin.value()
        self.config["tier3_temp"] = self.tier3_spin.value()
        self.config["tier4_temp"] = self.tier4_spin.value()
        self.config["base_freq"] = self.freq_slider.value()
        self.config["volume"] = self.vol_slider.value()
        self.config["dynamic_freq_scaling"] = self.dynamic_freq_check.isChecked()
        self.config["beep_duration_ms"] = self.dur_spin.value()
        self.config["inter_beep_ms"] = self.gap_spin.value()
        self.config["muted"] = self.muted
        self.config["simulation_mode"] = self.sim_check.isChecked()
        save_config(self.config)

    def closeEvent(self, event):
        if self.tray_icon.isVisible():
            self.hide()
            event.ignore()
        else:
            event.accept()

    def cleanup(self):
        if self.thermal_worker:
            self.thermal_worker.stop()
        if self.audio_worker:
            self.audio_worker.stop()


def main():
    app = QApplication(sys.argv)
    app.setStyle("Breeze")
    window = MainWindow()
    window.show()
    exit_code = app.exec()
    window.cleanup()
    sys.exit(exit_code)

if __name__ == "__main__":
    main()
