#!/usr/bin/env python3
"""
macr0s - Lightweight In-App Text Expansion & Macro Manager for Linux (KDE Plasma Breeze Theme)
"""

import sys
import os
import json
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTableWidget, QTableWidgetItem, QLineEdit, QTextEdit, QPushButton,
    QLabel, QMessageBox, QDialog, QFormLayout, QHeaderView, QFileDialog,
    QTabWidget
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont, QPalette, QTextCursor

MACROS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "macros.json")


class MacroEditDialog(QDialog):
    def __init__(self, parent=None, trigger="", expansion="", description=""):
        super().__init__(parent)
        self.setWindowTitle("Edit Macro" if trigger else "Add Macro")
        self.resize(450, 320)
        
        layout = QFormLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        self.trigger_input = QLineEdit(trigger)
        self.trigger_input.setPlaceholderText("e.g. ;sig or !email")
        
        self.expansion_input = QTextEdit()
        self.expansion_input.setPlainText(expansion)
        self.expansion_input.setPlaceholderText("Text or template to expand when trigger is typed...")
        
        self.desc_input = QLineEdit(description)
        self.desc_input.setPlaceholderText("Brief description of what this macro does")

        layout.addRow("Trigger:", self.trigger_input)
        layout.addRow("Expansion:", self.expansion_input)
        layout.addRow("Description:", self.desc_input)

        btn_layout = QHBoxLayout()
        self.save_btn = QPushButton("Save")
        self.save_btn.setDefault(True)
        self.save_btn.clicked.connect(self.validate_and_accept)
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.reject)

        btn_layout.addStretch()
        btn_layout.addWidget(self.cancel_btn)
        btn_layout.addWidget(self.save_btn)
        layout.addRow(btn_layout)

    def validate_and_accept(self):
        trigger = self.trigger_input.text().strip()
        expansion = self.expansion_input.toPlainText()
        if not trigger:
            QMessageBox.warning(self, "Validation Error", "Trigger cannot be empty.")
            return
        if not expansion:
            QMessageBox.warning(self, "Validation Error", "Expansion text cannot be empty.")
            return
        self.accept()

    def get_data(self):
        return {
            "trigger": self.trigger_input.text().strip(),
            "expansion": self.expansion_input.toPlainText(),
            "description": self.desc_input.text().strip()
        }


class ScratchpadTextEdit(QTextEdit):
    def __init__(self, get_macros_func, parent=None):
        super().__init__(parent)
        self.get_macros = get_macros_func
        self.setPlaceholderText(
            "Macro Tester & Scratchpad\n\n"
            "Type your text here and test your macros in real-time.\n"
            "Example: Type ';sig', ';date', ';shrug', or ';email' followed by Space, Tab, or Enter to expand."
        )
        font = QFont("Monospace")
        font.setStyleHint(QFont.StyleHint.Monospace)
        font.setPointSize(11)
        self.setFont(font)

    def keyPressEvent(self, event):
        super().keyPressEvent(event)
        if event.key() in (Qt.Key.Key_Space, Qt.Key.Key_Return, Qt.Key.Key_Enter, Qt.Key.Key_Tab):
            cursor = self.textCursor()
            block_cursor = QTextCursor(cursor)
            block_cursor.movePosition(QTextCursor.MoveOperation.StartOfBlock)
            
            full_block_cursor = QTextCursor(block_cursor)
            full_block_cursor.setPosition(cursor.position(), QTextCursor.MoveMode.KeepAnchor)
            text_before = full_block_cursor.selectedText()
            
            if len(text_before) > 1:
                prefix = text_before[:-1]  # exclude the just-inserted delimiter
                macros = self.get_macros()
                for macro in macros:
                    trigger = macro.get("trigger", "")
                    expansion = macro.get("expansion", "")
                    if trigger and prefix.endswith(trigger):
                        # Calculate exact absolute positions
                        trigger_len = len(trigger)
                        end_pos = cursor.position() - 1  # right before delimiter
                        start_pos = end_pos - trigger_len  # start of trigger
                        
                        replace_cursor = QTextCursor(self.document())
                        replace_cursor.setPosition(start_pos)
                        replace_cursor.setPosition(end_pos, QTextCursor.MoveMode.KeepAnchor)
                        replace_cursor.removeSelectedText()
                        replace_cursor.insertText(expansion)
                        break


class MacroWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("macr0s - Text Expander & Macro Manager")
        self.resize(850, 560)

        self.macros = []
        self.load_macros()
        self.init_ui()

    def init_ui(self):
        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(10)

        # Tabs: 1. Macro Manager, 2. Scratchpad & Tester
        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)

        # Tab 1: Manager
        manager_widget = QWidget()
        manager_layout = QVBoxLayout(manager_widget)
        manager_layout.setContentsMargins(10, 10, 10, 10)
        manager_layout.setSpacing(10)

        # Top Bar: Search
        top_layout = QHBoxLayout()
        
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search macros by trigger or text...")
        self.search_input.textChanged.connect(self.filter_macros)
        top_layout.addWidget(self.search_input)

        manager_layout.addLayout(top_layout)

        # Table for Macros
        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["Trigger", "Expansion", "Description"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.ExtendedSelection)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.doubleClicked.connect(self.edit_macro)
        manager_layout.addWidget(self.table)

        # Bottom Controls
        bottom_layout = QHBoxLayout()

        self.add_btn = QPushButton("Add Macro")
        self.add_btn.clicked.connect(self.add_macro)
        
        self.edit_btn = QPushButton("Edit Macro")
        self.edit_btn.clicked.connect(self.edit_selected_macro)
        
        self.del_btn = QPushButton("Delete Macro")
        self.del_btn.clicked.connect(self.delete_macro)

        self.import_btn = QPushButton("Import")
        self.import_btn.clicked.connect(self.import_macros)

        self.export_btn = QPushButton("Export")
        self.export_btn.clicked.connect(self.export_macros)

        bottom_layout.addStretch()
        bottom_layout.addWidget(self.add_btn)
        bottom_layout.addWidget(self.edit_btn)
        bottom_layout.addWidget(self.del_btn)
        bottom_layout.addWidget(self.import_btn)
        bottom_layout.addWidget(self.export_btn)

        manager_layout.addLayout(bottom_layout)
        self.tabs.addTab(manager_widget, "Macro Manager")

        # Tab 2: Scratchpad
        scratchpad_widget = QWidget()
        scratchpad_layout = QVBoxLayout(scratchpad_widget)
        scratchpad_layout.setContentsMargins(10, 10, 10, 10)
        scratchpad_layout.setSpacing(10)

        top_sp_layout = QHBoxLayout()
        info_label = QLabel("💡 Scratchpad: Type any defined trigger (e.g. ;sig, ;date, ;shrug) followed by Space, Tab, or Enter to expand.")
        info_label.setWordWrap(True)
        info_label.setStyleSheet("color: #3daee9; font-weight: 500;")
        top_sp_layout.addWidget(info_label, stretch=3)

        self.undo_btn = QPushButton("Undo")
        self.undo_btn.clicked.connect(lambda: self.scratchpad.undo())
        self.redo_btn = QPushButton("Redo")
        self.redo_btn.clicked.connect(lambda: self.scratchpad.redo())
        top_sp_layout.addWidget(self.undo_btn)
        top_sp_layout.addWidget(self.redo_btn)

        scratchpad_layout.addLayout(top_sp_layout)

        self.scratchpad = ScratchpadTextEdit(lambda: self.macros)
        scratchpad_layout.addWidget(self.scratchpad)
        
        self.tabs.addTab(scratchpad_widget, "Scratchpad")

        self.populate_table()
        self.apply_breeze_styling()

    def apply_breeze_styling(self):
        palette = self.palette()
        is_dark = palette.color(QPalette.ColorRole.Window).lightness() < 128
        
        if is_dark:
            bg_color = "#232629"
            alt_bg = "#31363b"
            text_color = "#eff0f1"
            accent = "#3daee9"
            border = "#4d4d4d"
        else:
            bg_color = "#fcfcfc"
            alt_bg = "#eff0f1"
            text_color = "#31363b"
            accent = "#1d99f3"
            border = "#bdc3c7"

        stylesheet = f"""
            QMainWindow {{
                background-color: {bg_color};
                color: {text_color};
            }}
            QWidget {{
                color: {text_color};
                font-size: 10pt;
            }}
            QTableWidget {{
                background-color: {bg_color};
                alternate-background-color: {alt_bg};
                gridline-color: {border};
                border: 1px solid {border};
                border-radius: 4px;
            }}
            QHeaderView::section {{
                background-color: {alt_bg};
                padding: 6px;
                border: none;
                border-bottom: 1px solid {border};
                font-weight: bold;
            }}
            QPushButton {{
                background-color: {alt_bg};
                border: 1px solid {border};
                border-radius: 4px;
                padding: 6px 14px;
                font-weight: 500;
            }}
            QPushButton:hover {{
                background-color: {accent};
                color: white;
                border-color: {accent};
            }}
            QLineEdit, QTextEdit {{
                background-color: {bg_color};
                border: 1px solid {border};
                border-radius: 4px;
                padding: 5px;
            }}
            QLineEdit:focus, QTextEdit:focus {{
                border: 1px solid {accent};
            }}
        """
        self.setStyleSheet(stylesheet)

    def load_macros(self):
        if os.path.exists(MACROS_FILE):
            try:
                with open(MACROS_FILE, "r", encoding="utf-8") as f:
                    self.macros = json.load(f)
            except Exception as e:
                print(f"Error loading macros: {e}", file=sys.stderr)
                self.macros = []
        else:
            self.macros = []

    def save_macros(self):
        try:
            with open(MACROS_FILE, "w", encoding="utf-8") as f:
                json.dump(self.macros, f, indent=2, ensure_ascii=False)
        except Exception as e:
            QMessageBox.critical(self, "Save Error", f"Failed to save macros: {e}")

    def populate_table(self, filter_text=""):
        self.table.setRowCount(0)
        filter_text = filter_text.lower()

        for macro in self.macros:
            trigger = macro.get("trigger", "")
            expansion = macro.get("expansion", "")
            desc = macro.get("description", "")

            if filter_text and filter_text not in trigger.lower() and filter_text not in expansion.lower() and filter_text not in desc.lower():
                continue

            row = self.table.rowCount()
            self.table.insertRow(row)
            
            exp_preview = expansion.replace("\n", " ↵ ")

            self.table.setItem(row, 0, QTableWidgetItem(trigger))
            self.table.setItem(row, 1, QTableWidgetItem(exp_preview))
            self.table.setItem(row, 2, QTableWidgetItem(desc))

    def filter_macros(self, text):
        self.populate_table(text)

    def add_macro(self):
        dialog = MacroEditDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            data = dialog.get_data()
            self.macros.append(data)
            self.save_macros()
            self.populate_table(self.search_input.text())

    def edit_selected_macro(self):
        selected = self.table.selectedItems()
        if not selected:
            QMessageBox.information(self, "Selection", "Please select a macro to edit.")
            return
        row = selected[0].row()
        trigger = self.table.item(row, 0).text()

        for macro in self.macros:
            if macro.get("trigger") == trigger:
                dialog = MacroEditDialog(self, macro.get("trigger"), macro.get("expansion"), macro.get("description"))
                if dialog.exec() == QDialog.DialogCode.Accepted:
                    macro.update(dialog.get_data())
                    self.save_macros()
                    self.populate_table(self.search_input.text())
                break

    def edit_macro(self, index):
        self.edit_selected_macro()

    def delete_macro(self):
        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            QMessageBox.information(self, "Selection", "Please select one or more macros to delete.")
            return

        triggers = [self.table.item(row.row(), 0).text() for row in selected_rows]
        count = len(triggers)
        msg = f"Are you sure you want to delete {count} selected macros?" if count > 1 else f"Are you sure you want to delete macro '{triggers[0]}'?"

        reply = QMessageBox.question(self, "Confirm Delete", msg,
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.macros = [m for m in self.macros if m.get("trigger") not in triggers]
            self.save_macros()
            self.populate_table(self.search_input.text())

    def import_macros(self):
        filename, _ = QFileDialog.getOpenFileName(self, "Import Macros", "", "JSON Files (*.json);;All Files (*)")
        if filename:
            try:
                with open(filename, "r", encoding="utf-8") as f:
                    imported = json.load(f)
                    if isinstance(imported, list):
                        self.macros.extend(imported)
                        self.save_macros()
                        self.populate_table()
                        QMessageBox.information(self, "Success", "Successfully imported macros.")
                    else:
                        QMessageBox.warning(self, "Invalid Format", "JSON file must contain a list of macros.")
            except Exception as e:
                QMessageBox.critical(self, "Import Error", f"Failed to import: {e}")

    def export_macros(self):
        filename, _ = QFileDialog.getSaveFileName(self, "Export Macros", "macros_backup.json", "JSON Files (*.json)")
        if filename:
            try:
                with open(filename, "w", encoding="utf-8") as f:
                    json.dump(self.macros, f, indent=2, ensure_ascii=False)
                QMessageBox.information(self, "Success", "Successfully exported macros.")
            except Exception as e:
                QMessageBox.critical(self, "Export Error", f"Failed to export: {e}")


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("macr0s")
    
    window = MacroWindow()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
