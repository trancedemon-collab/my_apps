# macr0s

A lightweight, clean Python/PyQt6 GUI application for macro management and in-app text expansion, designed with native KDE Plasma Breeze Light/Dark/Auto theme support.

## Features
- **Mass Selection & Deletion**: Select multiple macros in the Macro Manager table (using Shift/Ctrl + click or drag) and delete them in batch.
- **Scratchpad with Undo/Redo**: An interactive text area tab renamed to "Scratchpad" where you can type triggers (e.g. `;sig`, `;date`, `;shrug`) followed by Space, Tab, or Enter to instantly expand them, complete with Undo and Redo buttons.
- **KDE Plasma Breeze Theme**: Automatically adapts to system light and dark themes using native palette integration and clean stylesheets.
- **Macro Manager**: Easy-to-use table interface to add, edit, delete, search, import, and export macros (`macros.json`).
- **Clean Exit**: Operates as a self-contained window that closes cleanly without lingering in the system tray.

## Usage
Run the application:
```bash
python3 macr0s.py
```
