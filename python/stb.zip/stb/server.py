from http.server import HTTPServer, SimpleHTTPRequestHandler
import json
from pathlib import Path

# Sets the storage file right next to this Python script
BASE_DIR = Path(__file__).parent.resolve()
DATA_FILE = BASE_DIR / "prompt_data.json"


class DataBridgeHandler(SimpleHTTPRequestHandler):

    def __init__(self, *args, **kwargs):
        # Ensures static files (HTML, JS, CSS) are served from this folder
        super().__init__(*args, directory=str(BASE_DIR), **kwargs)

    def do_GET(self):
        if self.path == "/api/data":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            if DATA_FILE.exists():
                self.wfile.write(DATA_FILE.read_bytes())
            else:
                self.wfile.write(b"{}")
        else:
            super().do_GET()

    def do_POST(self):
        if self.path == "/api/data":
            content_length = int(self.headers["Content-Length"])
            payload = self.rfile.read(content_length)

            try:
                data = json.loads(payload)
                with open(DATA_FILE, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2)

                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"status": "saved"}')
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(str(e).encode())
        else:
            self.send_response(404)
            self.end_headers()


if __name__ == "__main__":
    server = HTTPServer(("localhost", 8000), DataBridgeHandler)
    print("Server running at: http://localhost:8000/ai_video_prompt_builder.html")
    print(f"JSON saving to:    {DATA_FILE}")
    server.serve_forever()