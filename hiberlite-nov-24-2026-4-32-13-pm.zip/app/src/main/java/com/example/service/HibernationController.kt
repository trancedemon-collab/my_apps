package com.example.service

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import com.example.MainActivity
import com.example.model.HibernationRunState
import com.example.model.HibernationTarget
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class TargetStep {
    WAITING_FOR_APP_INFO,
    WAITING_FOR_CONFIRM_DIALOG,
    ADVANCING,
}

enum class TargetOutcome {
    HIBERNATED,
    ALREADY_STOPPED,
    SKIPPED,
}

/**
 * Lightweight singleton coordinator between UI and [HibernationAccessibilityService].
 * Stays completely idle (zero polling, zero background jobs) until a manual run starts.
 */
object HibernationController {

    private const val TARGET_TIMEOUT_MS = 3_800L
    private const val POST_CLICK_DELAY_MS = 320L

    private val mainHandler = Handler(Looper.getMainLooper())

    private val _isServiceConnected = MutableStateFlow(false)
    val isServiceConnected: StateFlow<Boolean> = _isServiceConnected.asStateFlow()

    private val _runState = MutableStateFlow<HibernationRunState>(HibernationRunState.Idle)
    val runState: StateFlow<HibernationRunState> = _runState.asStateFlow()

    @Volatile
    private var running: Boolean = false

    @Volatile
    private var currentStep: TargetStep = TargetStep.WAITING_FOR_APP_INFO

    private var queue: ArrayDeque<HibernationTarget> = ArrayDeque()
    private var activeTarget: HibernationTarget? = null
    private var totalCount: Int = 0
    private var completedCount: Int = 0
    private var hibernatedCount: Int = 0
    private var alreadyStoppedCount: Int = 0
    private var skippedCount: Int = 0
    private var lastActionTimeMs: Long = 0L

    private var timeoutRunnable: Runnable? = null
    private var advanceRunnable: Runnable? = null

    fun isRunning(): Boolean = running

    fun currentTarget(): HibernationTarget? = activeTarget

    fun currentStep(): TargetStep = currentStep

    fun setServiceConnected(connected: Boolean) {
        _isServiceConnected.value = connected
        if (!connected && running) {
            cancelInternal()
        }
    }

    fun isAccessibilityEnabled(context: Context): Boolean {
        if (_isServiceConnected.value) return true
        val expectedComponent = ComponentName(context, HibernationAccessibilityService::class.java)
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
        ) ?: return false

        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabledServices)
        while (splitter.hasNext()) {
            val componentName = ComponentName.unflattenFromString(splitter.next())
            if (componentName != null && componentName == expectedComponent) {
                return true
            }
        }
        return false
    }

    fun startHibernation(context: Context, targets: List<HibernationTarget>) {
        if (targets.isEmpty()) return
        val appContext = context.applicationContext

        clearScheduledCallbacks()
        queue = ArrayDeque(targets)
        totalCount = targets.size
        completedCount = 0
        hibernatedCount = 0
        alreadyStoppedCount = 0
        skippedCount = 0
        running = true

        launchNextTarget(appContext)
    }

    fun stopHibernation(context: Context) {
        if (!running) return
        val appContext = context.applicationContext
        finishRun(appContext)
    }

    fun onForceStopClicked() {
        currentStep = TargetStep.WAITING_FOR_CONFIRM_DIALOG
        lastActionTimeMs = System.currentTimeMillis()
    }

    fun canPerformAction(minIntervalMs: Long = 220L): Boolean {
        return System.currentTimeMillis() - lastActionTimeMs >= minIntervalMs
    }

    fun completeCurrentTarget(context: Context, outcome: TargetOutcome, delayMs: Long = 0L) {
        if (!running || currentStep == TargetStep.ADVANCING) return
        currentStep = TargetStep.ADVANCING
        lastActionTimeMs = System.currentTimeMillis()
        clearScheduledCallbacks()

        when (outcome) {
            TargetOutcome.HIBERNATED -> hibernatedCount++
            TargetOutcome.ALREADY_STOPPED -> alreadyStoppedCount++
            TargetOutcome.SKIPPED -> skippedCount++
        }
        completedCount++

        val appContext = context.applicationContext
        val runnable = Runnable {
            if (running) {
                launchNextTarget(appContext)
            }
        }
        advanceRunnable = runnable
        if (delayMs > 0L) {
            mainHandler.postDelayed(runnable, delayMs)
        } else {
            mainHandler.post(runnable)
        }
    }

    fun completeConfirmedStop(context: Context) {
        completeCurrentTarget(context, TargetOutcome.HIBERNATED, delayMs = POST_CLICK_DELAY_MS)
    }

    fun acknowledgeCompletion() {
        if (_runState.value is HibernationRunState.Completed) {
            _runState.value = HibernationRunState.Idle
        }
    }

    fun openAppInfoSettings(context: Context, packageName: String) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_NO_HISTORY or
                    Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS,
            )
        }
        runCatching { context.startActivity(intent) }
    }

    fun openAccessibilitySettings(context: Context) {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
    }

    private fun launchNextTarget(appContext: Context) {
        clearScheduledCallbacks()
        val next = queue.removeFirstOrNull()
        if (next == null) {
            finishRun(appContext)
            return
        }

        activeTarget = next
        currentStep = TargetStep.WAITING_FOR_APP_INFO
        lastActionTimeMs = 0L
        _runState.value = HibernationRunState.Running(
            currentPackage = next.packageName,
            currentLabel = next.label,
            completedCount = completedCount,
            totalCount = totalCount,
        )

        openAppInfoSettings(appContext, next.packageName)

        val watchdog = Runnable {
            if (running && activeTarget?.packageName == next.packageName) {
                completeCurrentTarget(appContext, TargetOutcome.SKIPPED)
            }
        }
        timeoutRunnable = watchdog
        mainHandler.postDelayed(watchdog, TARGET_TIMEOUT_MS)
    }

    private fun finishRun(appContext: Context) {
        clearScheduledCallbacks()
        running = false
        activeTarget = null
        currentStep = TargetStep.WAITING_FOR_APP_INFO

        _runState.value = HibernationRunState.Completed(
            hibernatedCount = hibernatedCount,
            alreadyStoppedCount = alreadyStoppedCount,
            skippedCount = skippedCount,
            timestampMs = System.currentTimeMillis(),
        )

        val returnIntent = Intent(appContext, MainActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP,
            )
        }
        runCatching { appContext.startActivity(returnIntent) }
    }

    private fun cancelInternal() {
        clearScheduledCallbacks()
        running = false
        activeTarget = null
        currentStep = TargetStep.WAITING_FOR_APP_INFO
        _runState.value = HibernationRunState.Idle
    }

    private fun clearScheduledCallbacks() {
        timeoutRunnable?.let { mainHandler.removeCallbacks(it) }
        timeoutRunnable = null
        advanceRunnable?.let { mainHandler.removeCallbacks(it) }
        advanceRunnable = null
    }
}
