package com.example.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Minimal-footprint AccessibilityService for manual app hibernation.
 *
 * When no manual run is active, [onAccessibilityEvent] returns immediately with zero
 * node inspection or memory allocation. During an active run, it inspects only the
 * Android Settings App Info screen and Force Stop confirmation dialog.
 */
class HibernationAccessibilityService : AccessibilityService() {

    private val forceStopViewIds = listOf(
        "com.android.settings:id/force_stop_button",
        "com.android.settings:id/right_button",
        "com.android.settings:id/button2",
        "com.android.settings:id/action_button",
        "com.android.settings:id/button3",
        "com.samsung.android.settings:id/button2",
        "com.miui.securitycenter:id/action_force_stop",
    )

    private val forceStopLabels = listOf(
        "force stop",
        "force close",
    )

    private val confirmButtonIds = listOf(
        "android:id/button1",
        "com.android.settings:id/button1",
    )

    private val confirmLabels = listOf(
        "ok",
        "force stop",
        "stop",
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        HibernationController.setServiceConnected(true)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // O(1) fast-path exit when dormant so system footprint stays effectively zero.
        if (!HibernationController.isRunning()) return
        val activeEvent = event ?: return
        val pkgName = activeEvent.packageName?.toString()?.lowercase() ?: return

        if (!isSettingsPackage(pkgName)) return
        if (!HibernationController.canPerformAction()) return

        val root = rootInActiveWindow ?: return
        when (HibernationController.currentStep()) {
            TargetStep.WAITING_FOR_APP_INFO -> handleAppInfoScreen(root)
            TargetStep.WAITING_FOR_CONFIRM_DIALOG -> handleConfirmDialog(root)
            TargetStep.ADVANCING -> Unit
        }
    }

    override fun onInterrupt() {
        HibernationController.stopHibernation(this)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        HibernationController.setServiceConnected(false)
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        HibernationController.setServiceConnected(false)
        super.onDestroy()
    }

    private fun handleAppInfoScreen(root: AccessibilityNodeInfo) {
        val forceStopNode = findForceStopNode(root) ?: return
        val clickableTarget = findClickableSelfOrAncestor(forceStopNode) ?: forceStopNode

        if (!forceStopNode.isEnabled || !clickableTarget.isEnabled) {
            // App is already stopped; skip cleanly and move to next app.
            HibernationController.completeCurrentTarget(this, TargetOutcome.ALREADY_STOPPED)
            return
        }

        val clicked = clickableTarget.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        if (clicked) {
            HibernationController.onForceStopClicked()
        }
    }

    private fun handleConfirmDialog(root: AccessibilityNodeInfo) {
        // First look for standard Android AlertDialog positive button ID.
        for (id in confirmButtonIds) {
            val matches = root.findAccessibilityNodeInfosByViewId(id)
            val button = matches.firstOrNull { it.isEnabled && it.isClickable }
            if (button != null) {
                if (button.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    HibernationController.completeConfirmedStop(this)
                    return
                }
            }
        }

        // Fallback: look for dialog confirmation button by text when a dialog alert is visible.
        val isLikelyDialog = root.findAccessibilityNodeInfosByViewId("android:id/alertTitle").isNotEmpty() ||
            root.findAccessibilityNodeInfosByViewId("android:id/message").isNotEmpty() ||
            root.findAccessibilityNodeInfosByViewId("android:id/content").isNotEmpty()

        if (!isLikelyDialog) return

        for (label in confirmLabels) {
            val matches = root.findAccessibilityNodeInfosByText(label)
            for (node in matches) {
                val text = node.text?.toString()?.trim()?.lowercase() ?: continue
                if (text == label && node.isEnabled) {
                    val clickable = findClickableSelfOrAncestor(node) ?: continue
                    if (clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        HibernationController.completeConfirmedStop(this)
                        return
                    }
                }
            }
        }
    }

    private fun findForceStopNode(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (viewId in forceStopViewIds) {
            val nodes = root.findAccessibilityNodeInfosByViewId(viewId)
            for (node in nodes) {
                val combinedText = buildString {
                    node.text?.let { append(it).append(' ') }
                    node.contentDescription?.let { append(it) }
                }.lowercase()

                if (viewId.endsWith("force_stop_button") ||
                    forceStopLabels.any { combinedText.contains(it) }
                ) {
                    return node
                }
            }
        }

        for (label in forceStopLabels) {
            val nodes = root.findAccessibilityNodeInfosByText(label)
            for (node in nodes) {
                val text = node.text?.toString()?.trim()?.lowercase() ?: ""
                val desc = node.contentDescription?.toString()?.trim()?.lowercase() ?: ""
                if (text.contains(label) || desc.contains(label)) {
                    return node
                }
            }
        }
        return null
    }

    private fun findClickableSelfOrAncestor(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var current: AccessibilityNodeInfo? = node
        var depth = 0
        while (current != null && depth < 5) {
            if (current.isClickable) return current
            current = current.parent
            depth++
        }
        return null
    }

    private fun isSettingsPackage(pkgName: String): Boolean {
        return pkgName == "com.android.settings" ||
            pkgName.contains("settings") ||
            pkgName == "com.miui.securitycenter" ||
            pkgName == "com.coloros.safecenter" ||
            pkgName == "com.oplus.safecenter"
    }
}
