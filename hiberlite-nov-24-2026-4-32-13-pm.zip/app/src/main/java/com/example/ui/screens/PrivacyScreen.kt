package com.example.ui.screens

import android.os.Build
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.BatterySaver
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.FolderOff
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.VerifiedUser
import androidx.compose.material.icons.outlined.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.HiberUiState
import com.example.ui.theme.LocalHiberColors

@Composable
fun PrivacyScreen(
    uiState: HiberUiState,
    onSetupAccessibility: () -> Unit,
    onToggleShowSystemApps: (Boolean) -> Unit,
    onToggleDynamicColor: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    val hiberColors = LocalHiberColors.current
    val colorScheme = MaterialTheme.colorScheme
    val systemDark = isSystemInDarkTheme()

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp)
                .testTag("privacy_screen_list"),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item(key = "header") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text(
                        text = stringResource(R.string.privacy_header_title),
                        style = MaterialTheme.typography.headlineMedium,
                        color = colorScheme.onBackground,
                    )
                    Text(
                        text = stringResource(R.string.privacy_header_subtitle),
                        style = MaterialTheme.typography.bodyMedium,
                        color = colorScheme.onSurfaceVariant,
                    )
                }
            }

            // Accessibility Service Setup & Status Card
            item(key = "accessibility_card") {
                val active = uiState.isAccessibilityEnabled
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    color = if (active) {
                        hiberColors.sleepingContainer.copy(alpha = 0.55f)
                    } else {
                        hiberColors.awakeContainer.copy(alpha = 0.65f)
                    },
                    border = BorderStroke(
                        1.dp,
                        if (active) hiberColors.sleeping.copy(alpha = 0.3f) else hiberColors.awake.copy(alpha = 0.35f),
                    ),
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            Icon(
                                imageVector = if (active) Icons.Filled.CheckCircle else Icons.Filled.AccessibilityNew,
                                contentDescription = null,
                                tint = if (active) hiberColors.sleeping else hiberColors.awake,
                                modifier = Modifier.size(28.dp),
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.accessibility_service_label),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = colorScheme.onSurface,
                                )
                                Text(
                                    text = stringResource(
                                        if (active) {
                                            R.string.privacy_perm_accessibility_active
                                        } else {
                                            R.string.privacy_perm_accessibility_inactive
                                        },
                                    ),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (active) hiberColors.sleeping else hiberColors.awake,
                                )
                            }
                        }

                        Text(
                            text = stringResource(R.string.accessibility_service_description),
                            style = MaterialTheme.typography.bodySmall,
                            color = colorScheme.onSurfaceVariant,
                        )

                        Button(
                            onClick = onSetupAccessibility,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("privacy_accessibility_setup_button"),
                            shape = RoundedCornerShape(14.dp),
                        ) {
                            Text(
                                text = stringResource(
                                    if (active) {
                                        R.string.accessibility_open_settings
                                    } else {
                                        R.string.accessibility_enable_action
                                    },
                                ),
                            )
                        }
                    }
                }
            }

            // Permission Audit Ledger
            item(key = "permission_ledger") {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    color = hiberColors.cardSurface,
                    border = BorderStroke(1.dp, hiberColors.cardBorder),
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.VerifiedUser,
                                contentDescription = null,
                                tint = colorScheme.primary,
                                modifier = Modifier.size(20.dp),
                            )
                            Text(
                                text = stringResource(R.string.privacy_ledger_title),
                                style = MaterialTheme.typography.titleLarge,
                                color = colorScheme.onSurface,
                            )
                        }

                        AuditRow(
                            icon = Icons.Outlined.WifiOff,
                            title = stringResource(R.string.privacy_perm_network),
                            status = stringResource(R.string.privacy_perm_network_status),
                            statusColor = hiberColors.sleeping,
                        )
                        HorizontalDivider(color = hiberColors.cardBorder)
                        AuditRow(
                            icon = Icons.Outlined.FolderOff,
                            title = stringResource(R.string.privacy_perm_storage),
                            status = stringResource(R.string.privacy_perm_storage_status),
                            statusColor = hiberColors.sleeping,
                        )
                        HorizontalDivider(color = hiberColors.cardBorder)
                        AuditRow(
                            icon = Icons.Outlined.Apps,
                            title = stringResource(R.string.privacy_perm_packages),
                            status = stringResource(R.string.privacy_perm_packages_status),
                            statusColor = hiberColors.sleeping,
                        )
                        HorizontalDivider(color = hiberColors.cardBorder)
                        AuditRow(
                            icon = Icons.Filled.AccessibilityNew,
                            title = stringResource(R.string.privacy_perm_accessibility),
                            status = stringResource(
                                if (uiState.isAccessibilityEnabled) {
                                    R.string.privacy_perm_accessibility_active
                                } else {
                                    R.string.privacy_perm_accessibility_inactive
                                },
                            ),
                            statusColor = if (uiState.isAccessibilityEnabled) hiberColors.sleeping else hiberColors.awake,
                        )
                    }
                }
            }

            // Preferences Card
            item(key = "preferences_card") {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    color = hiberColors.cardSurface,
                    border = BorderStroke(1.dp, hiberColors.cardBorder),
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        Text(
                            text = stringResource(R.string.preferences_title),
                            style = MaterialTheme.typography.titleLarge,
                            color = colorScheme.onSurface,
                        )

                        // Auto System Light/Dark Theme Indicator
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            Icon(
                                imageVector = if (systemDark) Icons.Outlined.DarkMode else Icons.Outlined.LightMode,
                                contentDescription = null,
                                tint = colorScheme.primary,
                                modifier = Modifier.size(22.dp),
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.pref_theme_auto),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = colorScheme.onSurface,
                                )
                                Text(
                                    text = stringResource(R.string.pref_theme_auto_desc),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = colorScheme.onSurfaceVariant,
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = colorScheme.secondaryContainer,
                            ) {
                                Text(
                                    text = stringResource(
                                        if (systemDark) R.string.pref_theme_badge_dark else R.string.pref_theme_badge_light,
                                    ),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = colorScheme.onSecondaryContainer,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                )
                            }
                        }

                        HorizontalDivider(color = hiberColors.cardBorder)

                        // Show System Apps Toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Apps,
                                contentDescription = null,
                                tint = colorScheme.primary,
                                modifier = Modifier.size(22.dp),
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.pref_show_system_apps),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = colorScheme.onSurface,
                                )
                                Text(
                                    text = stringResource(R.string.pref_show_system_apps_desc),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = colorScheme.onSurfaceVariant,
                                )
                            }
                            Switch(
                                checked = uiState.showSystemApps,
                                onCheckedChange = onToggleShowSystemApps,
                                modifier = Modifier.testTag("pref_show_system_apps_switch"),
                            )
                        }

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            HorizontalDivider(color = hiberColors.cardBorder)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Palette,
                                    contentDescription = null,
                                    tint = colorScheme.primary,
                                    modifier = Modifier.size(22.dp),
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = stringResource(R.string.pref_dynamic_color),
                                        style = MaterialTheme.typography.titleMedium,
                                        color = colorScheme.onSurface,
                                    )
                                    Text(
                                        text = stringResource(R.string.pref_dynamic_color_desc),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = colorScheme.onSurfaceVariant,
                                    )
                                }
                                Switch(
                                    checked = uiState.useDynamicColor,
                                    onCheckedChange = onToggleDynamicColor,
                                    modifier = Modifier.testTag("pref_dynamic_color_switch"),
                                )
                            }
                        }
                    }
                }
            }

            // Zero-Polling Architecture Info Card
            item(key = "footprint_card") {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    color = colorScheme.surfaceVariant.copy(alpha = 0.6f),
                ) {
                    Row(
                        modifier = Modifier.padding(18.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.Top,
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.BatterySaver,
                            contentDescription = null,
                            tint = colorScheme.primary,
                            modifier = Modifier.size(24.dp),
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = stringResource(R.string.footprint_card_title),
                                style = MaterialTheme.typography.titleMedium,
                                color = colorScheme.onSurface,
                            )
                            Text(
                                text = stringResource(R.string.footprint_card_body),
                                style = MaterialTheme.typography.bodySmall,
                                color = colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }

            item(key = "bottom_spacer") {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun AuditRow(
    icon: ImageVector,
    title: String,
    status: String,
    statusColor: Color,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(20.dp),
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Text(
                text = status,
                style = MaterialTheme.typography.labelSmall,
                color = statusColor,
            )
        }
    }
}
