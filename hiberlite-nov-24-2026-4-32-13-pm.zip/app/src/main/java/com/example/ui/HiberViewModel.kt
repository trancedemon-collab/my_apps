package com.example.ui

import android.app.Application
import android.content.Context
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.InstalledAppsRepository
import com.example.data.PreferencesRepository
import com.example.data.UserPreferences
import com.example.model.AppStatusFilter
import com.example.model.DeviceTelemetry
import com.example.model.HiberTab
import com.example.model.HibernationRunState
import com.example.model.HibernationTarget
import com.example.model.InstalledAppInfo
import com.example.model.LastRunSummary
import com.example.model.WhitelistFilter
import com.example.service.HibernationController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class HiberUiState(
    val isLoading: Boolean = true,
    val selectedTab: HiberTab = HiberTab.HIBERNATE,
    val allApps: List<InstalledAppInfo> = emptyList(),
    val telemetry: DeviceTelemetry = DeviceTelemetry(),
    val isAccessibilityEnabled: Boolean = false,
    val runState: HibernationRunState = HibernationRunState.Idle,
    val showSystemApps: Boolean = false,
    val useDynamicColor: Boolean = false,
    val lastRunSummary: LastRunSummary = LastRunSummary(),
    val homeSearchQuery: String = "",
    val homeStatusFilter: AppStatusFilter = AppStatusFilter.ALL,
    val whitelistSearchQuery: String = "",
    val whitelistFilter: WhitelistFilter = WhitelistFilter.ALL,
    val showAccessibilityDisclosure: Boolean = false,
) {
    val nonWhitelistedApps: List<InstalledAppInfo>
        get() = allApps.filter { !it.isWhitelisted }

    val awakeQueueApps: List<InstalledAppInfo>
        get() = allApps.filter { !it.isWhitelisted && !it.isStopped }

    val sleepingAppsCount: Int
        get() = allApps.count { !it.isWhitelisted && it.isStopped }

    val protectedAppsCount: Int
        get() = allApps.count { it.isWhitelisted }

    val filteredHomeApps: List<InstalledAppInfo>
        get() {
            val query = homeSearchQuery.trim()
            return allApps
                .asSequence()
                .filter { !it.isWhitelisted }
                .filter { app ->
                    when (homeStatusFilter) {
                        AppStatusFilter.ALL -> true
                        AppStatusFilter.AWAKE -> !app.isStopped
                        AppStatusFilter.SLEEPING -> app.isStopped
                    }
                }
                .filter { app ->
                    query.isEmpty() ||
                        app.label.contains(query, ignoreCase = true) ||
                        app.packageName.contains(query, ignoreCase = true)
                }
                .toList()
        }

    val filteredWhitelistApps: List<InstalledAppInfo>
        get() {
            val query = whitelistSearchQuery.trim()
            return allApps
                .asSequence()
                .filter { app ->
                    when (whitelistFilter) {
                        WhitelistFilter.ALL -> true
                        WhitelistFilter.PROTECTED -> app.isWhitelisted
                        WhitelistFilter.UNPROTECTED -> !app.isWhitelisted
                    }
                }
                .filter { app ->
                    query.isEmpty() ||
                        app.label.contains(query, ignoreCase = true) ||
                        app.packageName.contains(query, ignoreCase = true)
                }
                .sortedWith(
                    compareByDescending<InstalledAppInfo> { it.isWhitelisted }
                        .thenByDescending { it.isEssentialDefault }
                        .thenBy(String.CASE_INSENSITIVE_ORDER) { it.label },
                )
                .toList()
        }
}

class HiberViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext: Context = application.applicationContext
    private val appsRepository = InstalledAppsRepository(appContext)
    private val preferencesRepository = PreferencesRepository(appContext)

    private val _uiState = MutableStateFlow(HiberUiState())
    val uiState: StateFlow<HiberUiState> = _uiState.asStateFlow()

    private var cachedEssentials: Set<String> = emptySet()
    private var latestPrefs: UserPreferences = UserPreferences()

    init {
        viewModelScope.launch {
            cachedEssentials = appsRepository.detectEssentialPackages()
            preferencesRepository.ensureDefaultWhitelistInitialized(cachedEssentials)

            preferencesRepository.preferencesFlow.collectLatest { prefs ->
                latestPrefs = prefs
                _uiState.update { state ->
                    state.copy(
                        showSystemApps = prefs.showSystemApps,
                        useDynamicColor = prefs.useDynamicColor,
                        lastRunSummary = prefs.lastRunSummary,
                    )
                }
                reloadAppsAndTelemetry()
            }
        }

        viewModelScope.launch {
            HibernationController.runState.collect { runState ->
                _uiState.update { it.copy(runState = runState) }
                if (runState is HibernationRunState.Completed) {
                    preferencesRepository.recordRunSummary(
                        hibernatedCount = runState.hibernatedCount,
                        alreadySleepingCount = runState.alreadyStoppedCount,
                        timestampMs = runState.timestampMs,
                    )
                    reloadAppsAndTelemetry()
                }
            }
        }

        viewModelScope.launch {
            HibernationController.isServiceConnected.collect {
                refreshAccessibilityState()
            }
        }
    }

    fun onResumeRefresh() {
        refreshAccessibilityState()
        viewModelScope.launch {
            reloadAppsAndTelemetry()
        }
    }

    fun selectTab(tab: HiberTab) {
        _uiState.update { it.copy(selectedTab = tab) }
    }

    fun updateHomeSearch(query: String) {
        _uiState.update { it.copy(homeSearchQuery = query) }
    }

    fun selectHomeFilter(filter: AppStatusFilter) {
        _uiState.update { it.copy(homeStatusFilter = filter) }
    }

    fun updateWhitelistSearch(query: String) {
        _uiState.update { it.copy(whitelistSearchQuery = query) }
    }

    fun selectWhitelistFilter(filter: WhitelistFilter) {
        _uiState.update { it.copy(whitelistFilter = filter) }
    }

    fun requestAccessibilitySetup() {
        _uiState.update { it.copy(showAccessibilityDisclosure = true) }
    }

    fun dismissAccessibilityDisclosure() {
        _uiState.update { it.copy(showAccessibilityDisclosure = false) }
    }

    fun confirmOpenAccessibilitySettings(context: Context) {
        _uiState.update { it.copy(showAccessibilityDisclosure = false) }
        HibernationController.openAccessibilitySettings(context)
    }

    fun triggerHibernateAll(context: Context) {
        refreshAccessibilityState()
        if (!_uiState.value.isAccessibilityEnabled) {
            _uiState.update { it.copy(showAccessibilityDisclosure = true) }
            return
        }

        val targets = _uiState.value.awakeQueueApps.map {
            HibernationTarget(packageName = it.packageName, label = it.label)
        }
        if (targets.isEmpty()) return
        HibernationController.startHibernation(context, targets)
    }

    fun triggerHibernateSingle(context: Context, app: InstalledAppInfo) {
        refreshAccessibilityState()
        if (!_uiState.value.isAccessibilityEnabled) {
            // Even without Accessibility enabled, let the user jump directly to App Info manually.
            HibernationController.openAppInfoSettings(context, app.packageName)
            return
        }
        HibernationController.startHibernation(
            context = context,
            targets = listOf(HibernationTarget(packageName = app.packageName, label = app.label)),
        )
    }

    fun stopActiveHibernation(context: Context) {
        HibernationController.stopHibernation(context)
    }

    fun openAppInfoManual(context: Context, packageName: String) {
        HibernationController.openAppInfoSettings(context, packageName)
    }

    fun toggleWhitelist(packageName: String) {
        viewModelScope.launch {
            preferencesRepository.toggleWhitelist(packageName)
        }
    }

    fun restoreDefaultEssentials() {
        viewModelScope.launch {
            if (cachedEssentials.isEmpty()) {
                cachedEssentials = appsRepository.detectEssentialPackages()
            }
            preferencesRepository.restoreDefaultEssentials(cachedEssentials)
        }
    }

    fun setShowSystemApps(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setShowSystemApps(enabled)
        }
    }

    fun setUseDynamicColor(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setUseDynamicColor(enabled)
        }
    }

    fun dismissCompletedBanner() {
        HibernationController.acknowledgeCompletion()
    }

    suspend fun loadAppIcon(packageName: String): ImageBitmap? {
        return appsRepository.loadAppIcon(packageName)
    }

    private fun refreshAccessibilityState() {
        val enabled = HibernationController.isAccessibilityEnabled(appContext)
        _uiState.update { it.copy(isAccessibilityEnabled = enabled) }
    }

    private suspend fun reloadAppsAndTelemetry() {
        val telemetry = appsRepository.readDeviceTelemetry()
        val apps = appsRepository.loadLaunchableApps(
            whitelistedPackages = latestPrefs.whitelistedPackages,
            essentialDefaults = cachedEssentials,
            includeSystemApps = latestPrefs.showSystemApps,
        )
        val accessibilityReady = HibernationController.isAccessibilityEnabled(appContext)
        _uiState.update { state ->
            state.copy(
                isLoading = false,
                allApps = apps,
                telemetry = telemetry,
                isAccessibilityEnabled = accessibilityReady,
            )
        }
    }
}
