package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

@Immutable
data class HiberSemanticColors(
    val awake: Color,
    val awakeContainer: Color,
    val sleeping: Color,
    val sleepingContainer: Color,
    val shield: Color,
    val shieldContainer: Color,
    val cardSurface: Color,
    val cardBorder: Color,
)

private val LightSemanticColors = HiberSemanticColors(
    awake = AwakeAmberLight,
    awakeContainer = AwakeAmberContainerLight,
    sleeping = SleepingGreenLight,
    sleepingContainer = SleepingGreenContainerLight,
    shield = ShieldBlueLight,
    shieldContainer = ShieldBlueContainerLight,
    cardSurface = SurfaceCardLight,
    cardBorder = OutlineVariantLight,
)

private val DarkSemanticColors = HiberSemanticColors(
    awake = AwakeAmberDark,
    awakeContainer = AwakeAmberContainerDark,
    sleeping = SleepingGreenDark,
    sleepingContainer = SleepingGreenContainerDark,
    shield = ShieldBlueDark,
    shieldContainer = ShieldBlueContainerDark,
    cardSurface = SurfaceCardDark,
    cardBorder = OutlineVariantDark,
)

val LocalHiberColors = staticCompositionLocalOf { LightSemanticColors }

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldPrimaryDark,
    onPrimary = OnEmeraldPrimaryDark,
    primaryContainer = EmeraldPrimaryContainerDark,
    onPrimaryContainer = OnEmeraldPrimaryContainerDark,
    secondary = SlateSecondaryDark,
    onSecondary = OnSlateSecondaryDark,
    secondaryContainer = SlateSecondaryContainerDark,
    onSecondaryContainer = OnSlateSecondaryContainerDark,
    tertiary = TealTertiaryDark,
    onTertiary = OnTealTertiaryDark,
    tertiaryContainer = TealTertiaryContainerDark,
    onTertiaryContainer = OnTealTertiaryContainerDark,
    background = CanvasBackgroundDark,
    onBackground = OnSurfaceDark,
    surface = SurfaceDark,
    onSurface = OnSurfaceDark,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = OnSurfaceVariantDark,
    surfaceContainerLowest = Color(0xFF060B0A),
    surfaceContainerLow = Color(0xFF0E1714),
    surfaceContainer = SurfaceCardDark,
    surfaceContainerHigh = Color(0xFF172420),
    surfaceContainerHighest = Color(0xFF1F2F2A),
    outline = OutlineDark,
    outlineVariant = OutlineVariantDark,
    error = ErrorDark,
    errorContainer = ErrorContainerDark,
)

private val LightColorScheme = lightColorScheme(
    primary = EmeraldPrimaryLight,
    onPrimary = OnEmeraldPrimaryLight,
    primaryContainer = EmeraldPrimaryContainerLight,
    onPrimaryContainer = OnEmeraldPrimaryContainerLight,
    secondary = SlateSecondaryLight,
    onSecondary = OnSlateSecondaryLight,
    secondaryContainer = SlateSecondaryContainerLight,
    onSecondaryContainer = OnSlateSecondaryContainerLight,
    tertiary = TealTertiaryLight,
    onTertiary = OnTealTertiaryLight,
    tertiaryContainer = TealTertiaryContainerLight,
    onTertiaryContainer = OnTealTertiaryContainerLight,
    background = CanvasBackgroundLight,
    onBackground = OnSurfaceLight,
    surface = SurfaceLight,
    onSurface = OnSurfaceLight,
    surfaceVariant = SurfaceVariantLight,
    onSurfaceVariant = OnSurfaceVariantLight,
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFFAFDFC),
    surfaceContainer = SurfaceCardLight,
    surfaceContainerHigh = Color(0xFFEDF3F1),
    surfaceContainerHighest = Color(0xFFE3ECE9),
    outline = OutlineLight,
    outlineVariant = OutlineVariantLight,
    error = ErrorLight,
    errorContainer = ErrorContainerLight,
)

@Composable
fun HiberLiteTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    val semanticColors = if (darkTheme) {
        DarkSemanticColors.copy(
            cardSurface = if (dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                colorScheme.surfaceContainer
            } else {
                SurfaceCardDark
            },
            cardBorder = colorScheme.outlineVariant,
        )
    } else {
        LightSemanticColors.copy(
            cardSurface = if (dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                colorScheme.surfaceContainerLowest
            } else {
                SurfaceCardLight
            },
            cardBorder = colorScheme.outlineVariant,
        )
    }

    CompositionLocalProvider(LocalHiberColors provides semanticColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = HiberLiteTypography,
            content = content,
        )
    }
}
