package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.AppStatusFilter
import com.example.model.HibernationRunState
import com.example.model.InstalledAppInfo
import com.example.ui.HiberUiState
import com.example.ui.components.HibernateAppRow
import com.example.ui.components.HibernationOrbCard
import com.example.ui.theme.LocalHiberColors

@Composable
fun HibernateScreen(
    uiState: HiberUiState,
    loadIcon: suspend (String) -> ImageBitmap?,
    onHibernateAll: () -> Unit,
    onStopHibernation: () -> Unit,
    onHibernateSingle: (InstalledAppInfo) -> Unit,
    onToggleWhitelist: (String) -> Unit,
    onAccessibilityClick: () -> Unit,
    onRefresh: () -> Unit,
    onSearchChange: (String) -> Unit,
    onFilterChange: (AppStatusFilter) -> Unit,
    onDismissCompleted: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val filteredApps = uiState.filteredHomeApps
    val hiberColors = LocalHiberColors.current

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp)
                .testTag("hibernate_app_list"),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            // Top bar header
            item(key = "header") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column {
                        Text(
                            text = stringResource(R.string.app_name),
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onBackground,
                        )
                        Text(
                            text = stringResource(R.string.app_tagline),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }

                    IconButton(
                        onClick = onRefresh,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("refresh_apps_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = stringResource(R.string.refresh_apps_cd),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            // Atmospheric Hibernation Orb Card
            item(key = "orb_card") {
                HibernationOrbCard(
                    awakeCount = uiState.awakeQueueApps.size,
                    sleepingCount = uiState.sleepingAppsCount,
                    protectedCount = uiState.protectedAppsCount,
                    telemetry = uiState.telemetry,
                    isAccessibilityEnabled = uiState.isAccessibilityEnabled,
                    runState = uiState.runState,
                    onHibernateClick = onHibernateAll,
                    onStopClick = onStopHibernation,
                    onAccessibilityBadgeClick = onAccessibilityClick,
                )
            }

            // Active Run Progress Banner
            item(key = "run_banner") {
                AnimatedVisibility(
                    visible = uiState.runState is HibernationRunState.Running,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically(),
                ) {
                    val running = uiState.runState as? HibernationRunState.Running ?: return@AnimatedVisibility
                    val progress = if (running.totalCount > 0) {
                        running.completedCount.toFloat() / running.totalCount.toFloat()
                    } else {
                        0f
                    }
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("active_run_banner"),
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    text = stringResource(
                                        R.string.session_progress_format,
                                        (running.completedCount + 1).coerceAtMost(running.totalCount),
                                        running.totalCount,
                                        running.currentLabel,
                                    ),
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f),
                                )
                                TextButton(onClick = onStopHibernation) {
                                    Text(text = stringResource(R.string.hibernate_stop_action))
                                }
                            }
                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                    }
                }
            }

            // Last Run Completion Pill
            item(key = "completed_summary") {
                val completed = uiState.runState as? HibernationRunState.Completed
                val showHistorical = completed == null && uiState.lastRunSummary.timestampMs > 0L
                AnimatedVisibility(
                    visible = completed != null || showHistorical,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically(),
                ) {
                    val hibCount = completed?.hibernatedCount ?: uiState.lastRunSummary.hibernatedCount
                    val alreadyCount = completed?.alreadyStoppedCount ?: uiState.lastRunSummary.alreadySleepingCount
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = hiberColors.sleepingContainer.copy(alpha = 0.55f),
                        border = BorderStroke(1.dp, hiberColors.sleeping.copy(alpha = 0.25f)),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f),
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = null,
                                    modifier = Modifier.size(17.dp),
                                    tint = hiberColors.sleeping,
                                )
                                Text(
                                    text = stringResource(
                                        R.string.session_last_summary_format,
                                        hibCount,
                                        alreadyCount,
                                    ),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            if (completed != null) {
                                IconButton(
                                    onClick = onDismissCompleted,
                                    modifier = Modifier.size(28.dp),
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Close,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Search & Filter Controls
            item(key = "controls") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = stringResource(R.string.section_hibernation_queue),
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                    )

                    OutlinedTextField(
                        value = uiState.homeSearchQuery,
                        onValueChange = onSearchChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("home_search_input"),
                        placeholder = {
                            Text(
                                text = stringResource(R.string.search_apps_placeholder),
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.Search,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp),
                            )
                        },
                        trailingIcon = {
                            if (uiState.homeSearchQuery.isNotEmpty()) {
                                IconButton(onClick = { onSearchChange("") }) {
                                    Icon(
                                        imageVector = Icons.Filled.Close,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp),
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = hiberColors.cardSurface,
                            unfocusedContainerColor = hiberColors.cardSurface,
                            unfocusedBorderColor = hiberColors.cardBorder,
                        ),
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        FilterChip(
                            selected = uiState.homeStatusFilter == AppStatusFilter.ALL,
                            onClick = { onFilterChange(AppStatusFilter.ALL) },
                            modifier = Modifier.testTag("filter_chip_all"),
                            label = {
                                Text(
                                    text = "${stringResource(R.string.filter_all)} (${uiState.nonWhitelistedApps.size})",
                                )
                            },
                        )
                        FilterChip(
                            selected = uiState.homeStatusFilter == AppStatusFilter.AWAKE,
                            onClick = { onFilterChange(AppStatusFilter.AWAKE) },
                            modifier = Modifier.testTag("filter_chip_awake"),
                            label = {
                                Text(
                                    text = "${stringResource(R.string.filter_awake)} (${uiState.awakeQueueApps.size})",
                                )
                            },
                        )
                        FilterChip(
                            selected = uiState.homeStatusFilter == AppStatusFilter.SLEEPING,
                            onClick = { onFilterChange(AppStatusFilter.SLEEPING) },
                            modifier = Modifier.testTag("filter_chip_sleeping"),
                            label = {
                                Text(
                                    text = "${stringResource(R.string.filter_sleeping)} (${uiState.sleepingAppsCount})",
                                )
                            },
                        )
                    }
                }
            }

            if (uiState.isLoading) {
                item(key = "loading") {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        CircularProgressIndicator()
                    }
                }
            } else if (filteredApps.isEmpty()) {
                item(key = "empty_state") {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        shape = RoundedCornerShape(22.dp),
                        color = hiberColors.cardSurface,
                        border = BorderStroke(1.dp, hiberColors.cardBorder),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp, vertical = 32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Bedtime,
                                contentDescription = null,
                                modifier = Modifier.size(36.dp),
                                tint = hiberColors.sleeping,
                            )
                            Text(
                                text = stringResource(
                                    if (uiState.homeSearchQuery.isNotBlank()) {
                                        R.string.empty_search_title
                                    } else {
                                        R.string.empty_queue_title
                                    },
                                ),
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center,
                            )
                            Text(
                                text = stringResource(
                                    if (uiState.homeSearchQuery.isNotBlank()) {
                                        R.string.empty_search_body
                                    } else {
                                        R.string.empty_queue_body
                                    },
                                ),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                }
            } else {
                items(
                    items = filteredApps,
                    key = { it.packageName },
                ) { app ->
                    HibernateAppRow(
                        app = app,
                        isAccessibilityEnabled = uiState.isAccessibilityEnabled,
                        loadIcon = loadIcon,
                        onHibernateSingle = { onHibernateSingle(app) },
                        onToggleWhitelist = { onToggleWhitelist(app.packageName) },
                    )
                }
            }

            item(key = "bottom_spacer") {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
