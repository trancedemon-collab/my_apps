package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.WhitelistFilter
import com.example.ui.HiberUiState
import com.example.ui.components.WhitelistAppRow
import com.example.ui.theme.LocalHiberColors

@Composable
fun WhitelistScreen(
    uiState: HiberUiState,
    loadIcon: suspend (String) -> ImageBitmap?,
    onToggleWhitelist: (String) -> Unit,
    onRestoreDefaults: () -> Unit,
    onSearchChange: (String) -> Unit,
    onFilterChange: (WhitelistFilter) -> Unit,
    modifier: Modifier = Modifier,
) {
    val filteredApps = uiState.filteredWhitelistApps
    val hiberColors = LocalHiberColors.current

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp)
                .testTag("whitelist_app_list"),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item(key = "header") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text(
                        text = stringResource(R.string.whitelist_header_title),
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        text = stringResource(R.string.whitelist_header_subtitle),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item(key = "shield_summary") {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    color = hiberColors.shieldContainer.copy(alpha = 0.65f),
                    border = BorderStroke(1.dp, hiberColors.shield.copy(alpha = 0.25f)),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Shield,
                                contentDescription = null,
                                tint = hiberColors.shield,
                                modifier = Modifier.size(28.dp),
                            )
                            Column {
                                Text(
                                    text = "${uiState.protectedAppsCount} ${stringResource(R.string.metric_protected_apps)}",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                                Text(
                                    text = "${uiState.nonWhitelistedApps.size} ${stringResource(R.string.whitelist_filter_unprotected).lowercase()}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }

                        FilledTonalButton(
                            onClick = onRestoreDefaults,
                            modifier = Modifier.testTag("restore_essentials_button"),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Restore,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                            )
                            Spacer(modifier = Modifier.size(6.dp))
                            Text(
                                text = stringResource(R.string.whitelist_restore_defaults),
                                style = MaterialTheme.typography.labelMedium,
                            )
                        }
                    }
                }
            }

            item(key = "search_and_filters") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = uiState.whitelistSearchQuery,
                        onValueChange = onSearchChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("whitelist_search_input"),
                        placeholder = {
                            Text(
                                text = stringResource(R.string.search_apps_placeholder),
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.Search,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp),
                            )
                        },
                        trailingIcon = {
                            if (uiState.whitelistSearchQuery.isNotEmpty()) {
                                IconButton(onClick = { onSearchChange("") }) {
                                    Icon(
                                        imageVector = Icons.Filled.Close,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp),
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = hiberColors.cardSurface,
                            unfocusedContainerColor = hiberColors.cardSurface,
                            unfocusedBorderColor = hiberColors.cardBorder,
                        ),
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        FilterChip(
                            selected = uiState.whitelistFilter == WhitelistFilter.ALL,
                            onClick = { onFilterChange(WhitelistFilter.ALL) },
                            modifier = Modifier.testTag("whitelist_filter_all"),
                            label = { Text(stringResource(R.string.whitelist_filter_all)) },
                        )
                        FilterChip(
                            selected = uiState.whitelistFilter == WhitelistFilter.PROTECTED,
                            onClick = { onFilterChange(WhitelistFilter.PROTECTED) },
                            modifier = Modifier.testTag("whitelist_filter_protected"),
                            label = { Text(stringResource(R.string.whitelist_filter_protected)) },
                        )
                        FilterChip(
                            selected = uiState.whitelistFilter == WhitelistFilter.UNPROTECTED,
                            onClick = { onFilterChange(WhitelistFilter.UNPROTECTED) },
                            modifier = Modifier.testTag("whitelist_filter_unprotected"),
                            label = { Text(stringResource(R.string.whitelist_filter_unprotected)) },
                        )
                    }
                }
            }

            if (filteredApps.isEmpty()) {
                item(key = "empty_whitelist") {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        shape = RoundedCornerShape(22.dp),
                        color = hiberColors.cardSurface,
                        border = BorderStroke(1.dp, hiberColors.cardBorder),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp, vertical = 32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Shield,
                                contentDescription = null,
                                modifier = Modifier.size(34.dp),
                                tint = hiberColors.shield,
                            )
                            Text(
                                text = stringResource(
                                    if (uiState.whitelistSearchQuery.isNotBlank()) {
                                        R.string.empty_search_title
                                    } else {
                                        R.string.whitelist_empty_protected_title
                                    },
                                ),
                                style = MaterialTheme.typography.titleMedium,
                                textAlign = TextAlign.Center,
                            )
                            Text(
                                text = stringResource(
                                    if (uiState.whitelistSearchQuery.isNotBlank()) {
                                        R.string.empty_search_body
                                    } else {
                                        R.string.whitelist_empty_protected_body
                                    },
                                ),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                }
            } else {
                items(
                    items = filteredApps,
                    key = { it.packageName },
                ) { app ->
                    WhitelistAppRow(
                        app = app,
                        loadIcon = loadIcon,
                        onToggleWhitelist = { onToggleWhitelist(app.packageName) },
                    )
                }
            }

            item(key = "bottom_spacer") {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
