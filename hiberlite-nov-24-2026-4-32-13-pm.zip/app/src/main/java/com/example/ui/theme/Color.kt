package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Precision Nordic Emerald — Light Palette
val EmeraldPrimaryLight = Color(0xFF0B6B57)
val OnEmeraldPrimaryLight = Color(0xFFFFFFFF)
val EmeraldPrimaryContainerLight = Color(0xFFC8F0E4)
val OnEmeraldPrimaryContainerLight = Color(0xFF042B22)

val SlateSecondaryLight = Color(0xFF43635B)
val OnSlateSecondaryLight = Color(0xFFFFFFFF)
val SlateSecondaryContainerLight = Color(0xFFD6E9E3)
val OnSlateSecondaryContainerLight = Color(0xFF132621)

val TealTertiaryLight = Color(0xFF2B6073)
val OnTealTertiaryLight = Color(0xFFFFFFFF)
val TealTertiaryContainerLight = Color(0xFFCDE9F5)
val OnTealTertiaryContainerLight = Color(0xFF0A242E)

val CanvasBackgroundLight = Color(0xFFF4F7F6)
val SurfaceLight = Color(0xFFF4F7F6)
val SurfaceCardLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFE6EEEB)
val OnSurfaceLight = Color(0xFF101C19)
val OnSurfaceVariantLight = Color(0xFF4D605A)
val OutlineLight = Color(0xFFBCCAC5)
val OutlineVariantLight = Color(0xFFDCE5E2)

// Precision Nordic Emerald — Dark Palette
val EmeraldPrimaryDark = Color(0xFF56DFC0)
val OnEmeraldPrimaryDark = Color(0xFF023127)
val EmeraldPrimaryContainerDark = Color(0xFF0E4A3D)
val OnEmeraldPrimaryContainerDark = Color(0xFFC8F0E4)

val SlateSecondaryDark = Color(0xFFA8C9BF)
val OnSlateSecondaryDark = Color(0xFF17352D)
val SlateSecondaryContainerDark = Color(0xFF23423A)
val OnSlateSecondaryContainerDark = Color(0xFFD6E9E3)

val TealTertiaryDark = Color(0xFF9ACCE0)
val OnTealTertiaryDark = Color(0xFF0D3342)
val TealTertiaryContainerDark = Color(0xFF1E4858)
val OnTealTertiaryContainerDark = Color(0xFFCDE9F5)

val CanvasBackgroundDark = Color(0xFF0A110F)
val SurfaceDark = Color(0xFF0A110F)
val SurfaceCardDark = Color(0xFF121D1A)
val SurfaceVariantDark = Color(0xFF1A2925)
val OnSurfaceDark = Color(0xFFE6F0ED)
val OnSurfaceVariantDark = Color(0xFF8FA69F)
val OutlineDark = Color(0xFF394D47)
val OutlineVariantDark = Color(0xFF21312C)

// Semantic Status Accents
val AwakeAmberLight = Color(0xFFB45309)
val AwakeAmberContainerLight = Color(0xFFFEF0DC)
val AwakeAmberDark = Color(0xFFFBBF24)
val AwakeAmberContainerDark = Color(0xFF3A290D)

val SleepingGreenLight = Color(0xFF0F766E)
val SleepingGreenContainerLight = Color(0xFFD3F2EC)
val SleepingGreenDark = Color(0xFF4FD1B5)
val SleepingGreenContainerDark = Color(0xFF0F362E)

val ShieldBlueLight = Color(0xFF1D5B79)
val ShieldBlueContainerLight = Color(0xFFD9EDF7)
val ShieldBlueDark = Color(0xFF7DD3FC)
val ShieldBlueContainerDark = Color(0xFF123040)

val ErrorLight = Color(0xFFBA1A1A)
val ErrorContainerLight = Color(0xFFFFDAD6)
val ErrorDark = Color(0xFFFFB4AB)
val ErrorContainerDark = Color(0xFF690005)
