package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.outlined.Bedtime
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.model.HiberTab
import com.example.ui.components.AccessibilityDisclosureDialog
import com.example.ui.screens.HibernateScreen
import com.example.ui.screens.PrivacyScreen
import com.example.ui.screens.WhitelistScreen
import com.example.ui.theme.HiberLiteTheme

private data class NavDestination(
    val tab: HiberTab,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String,
)

private val NavDestinations = listOf(
    NavDestination(
        tab = HiberTab.HIBERNATE,
        labelRes = R.string.nav_hibernate,
        selectedIcon = Icons.Filled.Bedtime,
        unselectedIcon = Icons.Outlined.Bedtime,
        testTag = "nav_tab_hibernate",
    ),
    NavDestination(
        tab = HiberTab.WHITELIST,
        labelRes = R.string.nav_whitelist,
        selectedIcon = Icons.Filled.Shield,
        unselectedIcon = Icons.Outlined.Shield,
        testTag = "nav_tab_whitelist",
    ),
    NavDestination(
        tab = HiberTab.PRIVACY,
        labelRes = R.string.nav_privacy,
        selectedIcon = Icons.Filled.VerifiedUser,
        unselectedIcon = Icons.Outlined.VerifiedUser,
        testTag = "nav_tab_privacy",
    ),
)

@Composable
fun HiberLiteApp(
    viewModel: HiberViewModel = viewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // Auto-refresh app stopped status, Accessibility readiness, and telemetry on resume.
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.onResumeRefresh()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Navigate back to Hibernate home tab when pressing Back on secondary tabs.
    BackHandler(enabled = uiState.selectedTab != HiberTab.HIBERNATE) {
        viewModel.selectTab(HiberTab.HIBERNATE)
    }

    HiberLiteTheme(dynamicColor = uiState.useDynamicColor) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useNavigationRail = maxWidth >= 600.dp

            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = MaterialTheme.colorScheme.background,
                contentWindowInsets = WindowInsets.safeDrawing,
                bottomBar = {
                    if (!useNavigationRail) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surfaceContainer,
                            tonalElevation = 0.dp,
                        ) {
                            NavDestinations.forEach { dest ->
                                val selected = uiState.selectedTab == dest.tab
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { viewModel.selectTab(dest.tab) },
                                    modifier = Modifier.testTag(dest.testTag),
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = stringResource(dest.labelRes),
                                        )
                                    },
                                    label = { Text(stringResource(dest.labelRes)) },
                                )
                            }
                        }
                    }
                },
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                ) {
                    if (useNavigationRail) {
                        NavigationRail(
                            modifier = Modifier.fillMaxHeight(),
                            containerColor = MaterialTheme.colorScheme.surfaceContainer,
                        ) {
                            NavDestinations.forEach { dest ->
                                val selected = uiState.selectedTab == dest.tab
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { viewModel.selectTab(dest.tab) },
                                    modifier = Modifier.testTag(dest.testTag),
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = stringResource(dest.labelRes),
                                        )
                                    },
                                    label = { Text(stringResource(dest.labelRes)) },
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                    ) {
                        when (uiState.selectedTab) {
                            HiberTab.HIBERNATE -> HibernateScreen(
                                uiState = uiState,
                                loadIcon = { pkg -> viewModel.loadAppIcon(pkg) },
                                onHibernateAll = { viewModel.triggerHibernateAll(context) },
                                onStopHibernation = { viewModel.stopActiveHibernation(context) },
                                onHibernateSingle = { app -> viewModel.triggerHibernateSingle(context, app) },
                                onToggleWhitelist = { pkg -> viewModel.toggleWhitelist(pkg) },
                                onAccessibilityClick = {
                                    if (uiState.isAccessibilityEnabled) {
                                        viewModel.selectTab(HiberTab.PRIVACY)
                                    } else {
                                        viewModel.requestAccessibilitySetup()
                                    }
                                },
                                onRefresh = { viewModel.onResumeRefresh() },
                                onSearchChange = { viewModel.updateHomeSearch(it) },
                                onFilterChange = { viewModel.selectHomeFilter(it) },
                                onDismissCompleted = { viewModel.dismissCompletedBanner() },
                            )

                            HiberTab.WHITELIST -> WhitelistScreen(
                                uiState = uiState,
                                loadIcon = { pkg -> viewModel.loadAppIcon(pkg) },
                                onToggleWhitelist = { pkg -> viewModel.toggleWhitelist(pkg) },
                                onRestoreDefaults = { viewModel.restoreDefaultEssentials() },
                                onSearchChange = { viewModel.updateWhitelistSearch(it) },
                                onFilterChange = { viewModel.selectWhitelistFilter(it) },
                            )

                            HiberTab.PRIVACY -> PrivacyScreen(
                                uiState = uiState,
                                onSetupAccessibility = { viewModel.requestAccessibilitySetup() },
                                onToggleShowSystemApps = { viewModel.setShowSystemApps(it) },
                                onToggleDynamicColor = { viewModel.setUseDynamicColor(it) },
                            )
                        }
                    }
                }
            }

            if (uiState.showAccessibilityDisclosure) {
                AccessibilityDisclosureDialog(
                    onConfirm = { viewModel.confirmOpenAccessibilitySettings(context) },
                    onDismiss = { viewModel.dismissAccessibilityDisclosure() },
                )
            }
        }
    }
}
