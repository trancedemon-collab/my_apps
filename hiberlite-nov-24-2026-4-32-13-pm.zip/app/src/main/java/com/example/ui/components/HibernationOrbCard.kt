package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryStd
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.DeviceTelemetry
import com.example.model.HibernationRunState
import com.example.ui.theme.LocalHiberColors

@Composable
fun HibernationOrbCard(
    awakeCount: Int,
    sleepingCount: Int,
    protectedCount: Int,
    telemetry: DeviceTelemetry,
    isAccessibilityEnabled: Boolean,
    runState: HibernationRunState,
    onHibernateClick: () -> Unit,
    onStopClick: () -> Unit,
    onAccessibilityBadgeClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colorScheme = MaterialTheme.colorScheme
    val hiberColors = LocalHiberColors.current
    val isRunning = runState is HibernationRunState.Running

    val totalManaged = (awakeCount + sleepingCount).coerceAtLeast(1)
    val restedRatio = if (awakeCount + sleepingCount == 0) 1f else sleepingCount.toFloat() / totalManaged.toFloat()
    val animatedSweep by animateFloatAsState(
        targetValue = restedRatio * 360f,
        animationSpec = spring(dampingRatio = 0.8f, stiffness = 220f),
        label = "rested_ring_sweep",
    )

    val pulseTransition = rememberInfiniteTransition(label = "orb_pulse")
    val pulseAlpha by pulseTransition.animateFloat(
        initialValue = 0.14f,
        targetValue = 0.34f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "pulse_alpha",
    )

    val glowColor = when {
        isRunning -> colorScheme.primary
        awakeCount == 0 -> hiberColors.sleeping
        else -> colorScheme.primary
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        color = hiberColors.cardSurface,
        border = BorderStroke(1.dp, hiberColors.cardBorder),
        tonalElevation = 1.dp,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .drawBehind {
                    val center = Offset(size.width * 0.5f, size.height * 0.38f)
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                glowColor.copy(alpha = if (isRunning) pulseAlpha else 0.14f),
                                Color.Transparent,
                            ),
                            center = center,
                            radius = size.maxDimension * 0.65f,
                        ),
                        radius = size.maxDimension * 0.65f,
                        center = center,
                    )
                }
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // Top telemetry + accessibility readiness row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TelemetryChip(
                    icon = if (telemetry.isCharging) Icons.Filled.BatteryChargingFull else Icons.Filled.BatteryStd,
                    text = "${telemetry.batteryPercent}%",
                    tint = if (telemetry.isCharging) hiberColors.sleeping else colorScheme.onSurfaceVariant,
                )

                Surface(
                    onClick = onAccessibilityBadgeClick,
                    modifier = Modifier.testTag("accessibility_status_pill"),
                    shape = RoundedCornerShape(50),
                    color = if (isAccessibilityEnabled) {
                        hiberColors.sleepingContainer
                    } else {
                        hiberColors.awakeContainer
                    },
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Icon(
                            imageVector = if (isAccessibilityEnabled) {
                                Icons.Filled.CheckCircle
                            } else {
                                Icons.Filled.AccessibilityNew
                            },
                            contentDescription = null,
                            modifier = Modifier.size(15.dp),
                            tint = if (isAccessibilityEnabled) hiberColors.sleeping else hiberColors.awake,
                        )
                        Text(
                            text = stringResource(
                                if (isAccessibilityEnabled) {
                                    R.string.accessibility_status_active
                                } else {
                                    R.string.accessibility_status_inactive
                                },
                            ),
                            style = MaterialTheme.typography.labelMedium,
                            color = if (isAccessibilityEnabled) hiberColors.sleeping else hiberColors.awake,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }

                TelemetryChip(
                    icon = Icons.Filled.Memory,
                    text = "${telemetry.freeRamMb} MB",
                    tint = colorScheme.onSurfaceVariant,
                )
            }

            Spacer(modifier = Modifier.height(22.dp))

            // Central Manual Trigger Orb with Ratio Ring
            val buttonEnabled = isRunning || awakeCount > 0 || !isAccessibilityEnabled
            val orbSize = 156.dp

            Box(
                modifier = Modifier.size(orbSize),
                contentAlignment = Alignment.Center,
            ) {
                val trackColor = colorScheme.surfaceVariant
                val ringColor = if (awakeCount == 0 && !isRunning) hiberColors.sleeping else colorScheme.primary
                val awakeArcColor = hiberColors.awake

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val strokePx = 9.dp.toPx()
                    val inset = strokePx / 2f
                    val arcSize = Size(size.width - strokePx, size.height - strokePx)
                    val topLeft = Offset(inset, inset)

                    drawArc(
                        color = trackColor,
                        startAngle = -90f,
                        sweepAngle = 360f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokePx, cap = StrokeCap.Round),
                    )

                    if (animatedSweep > 1f) {
                        drawArc(
                            color = ringColor,
                            startAngle = -90f,
                            sweepAngle = animatedSweep,
                            useCenter = false,
                            topLeft = topLeft,
                            size = arcSize,
                            style = Stroke(width = strokePx, cap = StrokeCap.Round),
                        )
                    }

                    val awakeSweep = (360f - animatedSweep).coerceAtLeast(0f)
                    if (awakeCount > 0 && awakeSweep > 4f) {
                        drawArc(
                            color = awakeArcColor.copy(alpha = 0.72f),
                            startAngle = -90f + animatedSweep + 4f,
                            sweepAngle = (awakeSweep - 8f).coerceAtLeast(2f),
                            useCenter = false,
                            topLeft = topLeft,
                            size = arcSize,
                            style = Stroke(width = strokePx * 0.75f, cap = StrokeCap.Round),
                        )
                    }
                }

                Surface(
                    modifier = Modifier
                        .size(124.dp)
                        .clip(CircleShape)
                        .testTag("hibernate_trigger_button")
                        .clickable(enabled = buttonEnabled) {
                            if (isRunning) onStopClick() else onHibernateClick()
                        },
                    shape = CircleShape,
                    color = when {
                        isRunning -> colorScheme.errorContainer
                        awakeCount == 0 -> hiberColors.sleepingContainer
                        else -> colorScheme.primary
                    },
                    shadowElevation = if (awakeCount > 0 && !isRunning) 4.dp else 0.dp,
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        val contentColor = when {
                            isRunning -> colorScheme.error
                            awakeCount == 0 -> hiberColors.sleeping
                            else -> colorScheme.onPrimary
                        }
                        Icon(
                            imageVector = when {
                                isRunning -> Icons.Filled.Stop
                                awakeCount == 0 -> Icons.Filled.CheckCircle
                                else -> Icons.Filled.Bedtime
                            },
                            contentDescription = stringResource(
                                if (isRunning) R.string.hibernate_stop_action else R.string.hibernate_now_label,
                            ),
                            modifier = Modifier.size(34.dp),
                            tint = contentColor,
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = when {
                                isRunning -> stringResource(R.string.hibernate_stop_action)
                                awakeCount == 0 -> stringResource(R.string.hibernate_all_clear_label)
                                else -> stringResource(R.string.hibernate_now_label)
                            },
                            style = MaterialTheme.typography.labelLarge,
                            color = contentColor,
                        )
                        if (!isRunning && awakeCount > 0) {
                            Text(
                                text = "$awakeCount ${stringResource(R.string.metric_awake_apps).lowercase()}",
                                style = MaterialTheme.typography.labelSmall,
                                color = contentColor.copy(alpha = 0.85f),
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            // 3-Column Metrics Strip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                MetricTile(
                    label = stringResource(R.string.metric_awake_apps),
                    value = awakeCount.toString(),
                    accent = hiberColors.awake,
                    container = hiberColors.awakeContainer.copy(alpha = 0.6f),
                    modifier = Modifier.weight(1f),
                )
                MetricTile(
                    label = stringResource(R.string.metric_sleeping_apps),
                    value = sleepingCount.toString(),
                    accent = hiberColors.sleeping,
                    container = hiberColors.sleepingContainer.copy(alpha = 0.6f),
                    modifier = Modifier.weight(1f),
                )
                MetricTile(
                    label = stringResource(R.string.metric_protected_apps),
                    value = protectedCount.toString(),
                    accent = hiberColors.shield,
                    container = hiberColors.shieldContainer.copy(alpha = 0.6f),
                    icon = Icons.Outlined.Shield,
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun TelemetryChip(
    icon: ImageVector,
    text: String,
    tint: Color,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
            tint = tint,
        )
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = tint,
        )
    }
}

@Composable
private fun MetricTile(
    label: String,
    value: String,
    accent: Color,
    container: Color,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = container,
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
            ) {
                if (icon != null) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = accent,
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                }
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = accent,
                )
            }
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}
