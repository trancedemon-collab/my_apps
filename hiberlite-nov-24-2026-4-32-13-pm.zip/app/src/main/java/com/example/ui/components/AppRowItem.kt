package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.InstalledAppInfo
import com.example.ui.theme.LocalHiberColors

@Composable
fun AppIconBadge(
    app: InstalledAppInfo,
    loadIcon: suspend (String) -> ImageBitmap?,
    modifier: Modifier = Modifier,
) {
    val iconBitmap = produceState<ImageBitmap?>(initialValue = null, key1 = app.packageName) {
        value = loadIcon(app.packageName)
    }

    val bitmap = iconBitmap.value
    if (bitmap != null) {
        Image(
            bitmap = bitmap,
            contentDescription = app.label,
            contentScale = ContentScale.Crop,
            modifier = modifier
                .size(42.dp)
                .clip(RoundedCornerShape(12.dp)),
        )
    } else {
        Box(
            modifier = modifier
                .size(42.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.secondaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = app.label.take(1).uppercase(),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSecondaryContainer,
            )
        }
    }
}

@Composable
fun HibernateAppRow(
    app: InstalledAppInfo,
    isAccessibilityEnabled: Boolean,
    loadIcon: suspend (String) -> ImageBitmap?,
    onHibernateSingle: () -> Unit,
    onToggleWhitelist: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val hiberColors = LocalHiberColors.current
    val colorScheme = MaterialTheme.colorScheme

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("app_row_${app.packageName}"),
        shape = RoundedCornerShape(18.dp),
        color = hiberColors.cardSurface,
        border = BorderStroke(1.dp, hiberColors.cardBorder),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AppIconBadge(app = app, loadIcon = loadIcon)

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        text = app.label,
                        style = MaterialTheme.typography.titleMedium,
                        color = colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    if (app.isSystemApp) {
                        StatusMicroPill(
                            text = stringResource(R.string.badge_system),
                            textColor = colorScheme.onSurfaceVariant,
                            bgColor = colorScheme.surfaceVariant,
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(if (app.isStopped) hiberColors.sleeping else hiberColors.awake),
                    )
                    Text(
                        text = stringResource(
                            if (app.isStopped) R.string.badge_sleeping else R.string.badge_awake,
                        ),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (app.isStopped) hiberColors.sleeping else hiberColors.awake,
                    )
                    Text(
                        text = "·",
                        style = MaterialTheme.typography.labelSmall,
                        color = colorScheme.onSurfaceVariant,
                    )
                    Text(
                        text = app.packageName,
                        style = MaterialTheme.typography.labelSmall,
                        color = colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            IconButton(
                onClick = onToggleWhitelist,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("whitelist_quick_btn_${app.packageName}"),
            ) {
                Icon(
                    imageVector = Icons.Outlined.Shield,
                    contentDescription = stringResource(R.string.whitelist_toggle_cd),
                    tint = colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp),
                )
            }

            if (!app.isStopped) {
                IconButton(
                    onClick = onHibernateSingle,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("single_hibernate_btn_${app.packageName}"),
                ) {
                    Icon(
                        imageVector = if (isAccessibilityEnabled) {
                            Icons.Filled.Bedtime
                        } else {
                            Icons.Outlined.Settings
                        },
                        contentDescription = stringResource(
                            if (isAccessibilityEnabled) R.string.single_hibernate_cd else R.string.app_info_cd,
                        ),
                        tint = colorScheme.primary,
                        modifier = Modifier.size(21.dp),
                    )
                }
            }
        }
    }
}

@Composable
fun WhitelistAppRow(
    app: InstalledAppInfo,
    loadIcon: suspend (String) -> ImageBitmap?,
    onToggleWhitelist: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val hiberColors = LocalHiberColors.current
    val colorScheme = MaterialTheme.colorScheme

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("whitelist_row_${app.packageName}"),
        shape = RoundedCornerShape(18.dp),
        color = hiberColors.cardSurface,
        border = BorderStroke(
            width = 1.dp,
            color = if (app.isWhitelisted) hiberColors.shield.copy(alpha = 0.45f) else hiberColors.cardBorder,
        ),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AppIconBadge(app = app, loadIcon = loadIcon)

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        text = app.label,
                        style = MaterialTheme.typography.titleMedium,
                        color = colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    if (app.isEssentialDefault) {
                        StatusMicroPill(
                            text = stringResource(R.string.badge_essential),
                            textColor = hiberColors.shield,
                            bgColor = hiberColors.shieldContainer,
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                ) {
                    if (app.isWhitelisted) {
                        Icon(
                            imageVector = Icons.Filled.Shield,
                            contentDescription = null,
                            modifier = Modifier.size(13.dp),
                            tint = hiberColors.shield,
                        )
                        Text(
                            text = stringResource(R.string.badge_protected),
                            style = MaterialTheme.typography.labelMedium,
                            color = hiberColors.shield,
                        )
                        Text(
                            text = "·",
                            style = MaterialTheme.typography.labelSmall,
                            color = colorScheme.onSurfaceVariant,
                        )
                    }
                    Text(
                        text = app.packageName,
                        style = MaterialTheme.typography.labelSmall,
                        color = colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Switch(
                checked = app.isWhitelisted,
                onCheckedChange = { onToggleWhitelist() },
                modifier = Modifier.testTag("whitelist_switch_${app.packageName}"),
            )
        }
    }
}

@Composable
private fun StatusMicroPill(
    text: String,
    textColor: androidx.compose.ui.graphics.Color,
    bgColor: androidx.compose.ui.graphics.Color,
) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = bgColor,
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = textColor,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            maxLines = 1,
        )
    }
}
