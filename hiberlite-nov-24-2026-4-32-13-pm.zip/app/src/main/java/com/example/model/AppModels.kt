package com.example.model

import androidx.compose.runtime.Immutable

@Immutable
data class InstalledAppInfo(
    val packageName: String,
    val label: String,
    val isSystemApp: Boolean,
    val isStopped: Boolean,
    val isWhitelisted: Boolean,
    val isEssentialDefault: Boolean,
)

@Immutable
data class DeviceTelemetry(
    val batteryPercent: Int = 0,
    val isCharging: Boolean = false,
    val freeRamMb: Long = 0L,
    val totalRamMb: Long = 1L,
) {
    val usedRamRatio: Float
        get() = if (totalRamMb > 0L) {
            ((totalRamMb - freeRamMb).toFloat() / totalRamMb.toFloat()).coerceIn(0f, 1f)
        } else {
            0f
        }
}

@Immutable
data class HibernationTarget(
    val packageName: String,
    val label: String,
)

sealed interface HibernationRunState {
    data object Idle : HibernationRunState

    data class Running(
        val currentPackage: String,
        val currentLabel: String,
        val completedCount: Int,
        val totalCount: Int,
    ) : HibernationRunState

    data class Completed(
        val hibernatedCount: Int,
        val alreadyStoppedCount: Int,
        val skippedCount: Int,
        val timestampMs: Long,
    ) : HibernationRunState
}

enum class AppStatusFilter {
    ALL,
    AWAKE,
    SLEEPING,
}

enum class WhitelistFilter {
    ALL,
    PROTECTED,
    UNPROTECTED,
}

enum class HiberTab {
    HIBERNATE,
    WHITELIST,
    PRIVACY,
}

@Immutable
data class LastRunSummary(
    val hibernatedCount: Int = 0,
    val alreadySleepingCount: Int = 0,
    val timestampMs: Long = 0L,
)
