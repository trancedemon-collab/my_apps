package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.LastRunSummary
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.hiberDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "hiberlite_prefs",
)

data class UserPreferences(
    val whitelistedPackages: Set<String> = emptySet(),
    val showSystemApps: Boolean = false,
    val useDynamicColor: Boolean = false,
    val lastRunSummary: LastRunSummary = LastRunSummary(),
)

class PreferencesRepository(private val context: Context) {

    private object Keys {
        val WHITELIST_INITIALIZED = booleanPreferencesKey("whitelist_initialized")
        val WHITELISTED_PACKAGES = stringSetPreferencesKey("whitelisted_packages")
        val SHOW_SYSTEM_APPS = booleanPreferencesKey("show_system_apps")
        val USE_DYNAMIC_COLOR = booleanPreferencesKey("use_dynamic_color")
        val LAST_HIBERNATED_COUNT = intPreferencesKey("last_hibernated_count")
        val LAST_ALREADY_SLEEPING_COUNT = intPreferencesKey("last_already_sleeping_count")
        val LAST_RUN_TIMESTAMP = longPreferencesKey("last_run_timestamp")
    }

    val preferencesFlow: Flow<UserPreferences> = context.hiberDataStore.data.map { prefs ->
        UserPreferences(
            whitelistedPackages = prefs[Keys.WHITELISTED_PACKAGES] ?: emptySet(),
            showSystemApps = prefs[Keys.SHOW_SYSTEM_APPS] ?: false,
            useDynamicColor = prefs[Keys.USE_DYNAMIC_COLOR] ?: false,
            lastRunSummary = LastRunSummary(
                hibernatedCount = prefs[Keys.LAST_HIBERNATED_COUNT] ?: 0,
                alreadySleepingCount = prefs[Keys.LAST_ALREADY_SLEEPING_COUNT] ?: 0,
                timestampMs = prefs[Keys.LAST_RUN_TIMESTAMP] ?: 0L,
            ),
        )
    }

    suspend fun ensureDefaultWhitelistInitialized(defaultEssentials: Set<String>) {
        val current = context.hiberDataStore.data.first()
        if (current[Keys.WHITELIST_INITIALIZED] != true) {
            context.hiberDataStore.edit { prefs ->
                prefs[Keys.WHITELISTED_PACKAGES] = defaultEssentials
                prefs[Keys.WHITELIST_INITIALIZED] = true
            }
        }
    }

    suspend fun toggleWhitelist(packageName: String) {
        context.hiberDataStore.edit { prefs ->
            val current = prefs[Keys.WHITELISTED_PACKAGES] ?: emptySet()
            prefs[Keys.WHITELISTED_PACKAGES] = if (packageName in current) {
                current - packageName
            } else {
                current + packageName
            }
        }
    }

    suspend fun restoreDefaultEssentials(defaultEssentials: Set<String>) {
        context.hiberDataStore.edit { prefs ->
            val current = prefs[Keys.WHITELISTED_PACKAGES] ?: emptySet()
            prefs[Keys.WHITELISTED_PACKAGES] = current + defaultEssentials
            prefs[Keys.WHITELIST_INITIALIZED] = true
        }
    }

    suspend fun setShowSystemApps(enabled: Boolean) {
        context.hiberDataStore.edit { prefs ->
            prefs[Keys.SHOW_SYSTEM_APPS] = enabled
        }
    }

    suspend fun setUseDynamicColor(enabled: Boolean) {
        context.hiberDataStore.edit { prefs ->
            prefs[Keys.USE_DYNAMIC_COLOR] = enabled
        }
    }

    suspend fun recordRunSummary(hibernatedCount: Int, alreadySleepingCount: Int, timestampMs: Long) {
        context.hiberDataStore.edit { prefs ->
            prefs[Keys.LAST_HIBERNATED_COUNT] = hibernatedCount
            prefs[Keys.LAST_ALREADY_SLEEPING_COUNT] = alreadySleepingCount
            prefs[Keys.LAST_RUN_TIMESTAMP] = timestampMs
        }
    }
}
