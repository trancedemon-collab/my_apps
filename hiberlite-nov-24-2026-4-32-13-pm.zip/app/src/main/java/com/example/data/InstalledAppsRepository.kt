package com.example.data

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import com.example.model.DeviceTelemetry
import com.example.model.InstalledAppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class InstalledAppsRepository(private val context: Context) {

    private val packageManager: PackageManager = context.packageManager

    // Small bounded icon cache (max 72 icons at 96x96px) to keep memory footprint tiny.
    private val iconCache = LruCache<String, ImageBitmap>(72)

    private val knownEssentialKeywords = listOf(
        "clock", "alarm", "deskclock", "dialer", "telecom", "phone",
        "messaging", "mms", "sms", "calendar", "inputmethod", "keyboard",
        "gboard", "launcher", "systemui", "wellbeing", "health",
    )

    suspend fun detectEssentialPackages(): Set<String> = withContext(Dispatchers.IO) {
        val essentials = mutableSetOf<String>()
        essentials.add(context.packageName)

        // Resolve default dialer, SMS, alarm clock, and home launcher using scoped intents.
        val probeIntents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(AlarmClock.ACTION_SET_ALARM),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
        )
        for (intent in probeIntents) {
            val resolved = queryActivitiesCompat(intent)
            resolved.forEach { info ->
                info.activityInfo?.packageName?.let { essentials.add(it) }
            }
        }

        // Current default keyboard / IME package if exposed.
        runCatching {
            val defaultIme = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.DEFAULT_INPUT_METHOD,
            )
            defaultIme?.substringBefore('/')?.takeIf { it.isNotBlank() }?.let { essentials.add(it) }
        }

        // Also mark launcher apps whose package name matches core essential categories.
        val launchable = queryLaunchablePackages()
        for (pkg in launchable) {
            val lower = pkg.lowercase()
            if (knownEssentialKeywords.any { lower.contains(it) }) {
                essentials.add(pkg)
            }
        }
        essentials
    }

    suspend fun loadLaunchableApps(
        whitelistedPackages: Set<String>,
        essentialDefaults: Set<String>,
        includeSystemApps: Boolean,
    ): List<InstalledAppInfo> = withContext(Dispatchers.IO) {
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = queryActivitiesCompat(launcherIntent)

        val seenPackages = HashSet<String>()
        val apps = mutableListOf<InstalledAppInfo>()

        for (resolveInfo in resolved) {
            val activityInfo = resolveInfo.activityInfo ?: continue
            val pkg = activityInfo.packageName ?: continue
            if (pkg == context.packageName || !seenPackages.add(pkg)) continue

            val appInfo = runCatching { getApplicationInfoCompat(pkg) }.getOrNull() ?: continue
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val isUpdatedSystem = (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            val treatAsSystem = isSystem && !isUpdatedSystem

            if (treatAsSystem && !includeSystemApps) continue

            val isStopped = (appInfo.flags and ApplicationInfo.FLAG_STOPPED) != 0
            val label = runCatching {
                resolveInfo.loadLabel(packageManager)?.toString()?.takeIf { it.isNotBlank() }
                    ?: packageManager.getApplicationLabel(appInfo).toString()
            }.getOrDefault(pkg)

            apps.add(
                InstalledAppInfo(
                    packageName = pkg,
                    label = label,
                    isSystemApp = treatAsSystem,
                    isStopped = isStopped,
                    isWhitelisted = pkg in whitelistedPackages,
                    isEssentialDefault = pkg in essentialDefaults,
                ),
            )
        }

        apps.sortedWith(
            compareBy<InstalledAppInfo> { it.isWhitelisted }
                .thenBy { it.isStopped }
                .thenBy(String.CASE_INSENSITIVE_ORDER) { it.label },
        )
    }

    suspend fun loadAppIcon(packageName: String): ImageBitmap? {
        iconCache.get(packageName)?.let { return it }
        return withContext(Dispatchers.IO) {
            runCatching {
                val drawable = packageManager.getApplicationIcon(packageName)
                val bitmap = drawable.toBitmap(width = 96, height = 96).asImageBitmap()
                iconCache.put(packageName, bitmap)
                bitmap
            }.getOrNull()
        }
    }

    fun readDeviceTelemetry(): DeviceTelemetry {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        activityManager?.getMemoryInfo(memInfo)
        val freeRamMb = memInfo.availMem / (1024L * 1024L)
        val totalRamMb = (memInfo.totalMem / (1024L * 1024L)).coerceAtLeast(1L)

        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val batteryPct = if (level >= 0 && scale > 0) ((level * 100f) / scale).toInt().coerceIn(0, 100) else 0
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        return DeviceTelemetry(
            batteryPercent = batteryPct,
            isCharging = isCharging,
            freeRamMb = freeRamMb,
            totalRamMb = totalRamMb,
        )
    }

    private fun queryLaunchablePackages(): Set<String> {
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return queryActivitiesCompat(launcherIntent)
            .mapNotNull { it.activityInfo?.packageName }
            .toSet()
    }

    @Suppress("DEPRECATION")
    private fun queryActivitiesCompat(intent: Intent) =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            packageManager.queryIntentActivities(
                intent,
                PackageManager.ResolveInfoFlags.of(0L),
            )
        } else {
            packageManager.queryIntentActivities(intent, 0)
        }

    @Suppress("DEPRECATION")
    private fun getApplicationInfoCompat(packageName: String): ApplicationInfo =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            packageManager.getApplicationInfo(
                packageName,
                PackageManager.ApplicationInfoFlags.of(0L),
            )
        } else {
            packageManager.getApplicationInfo(packageName, 0)
        }
}
