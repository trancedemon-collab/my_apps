(() => {
  const TARGET_LUMINANCE = 128;
  const SAMPLES_TO_LOCK = 8;
  const SAMPLE_INTERVAL_MS = 10000;

  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  canvas.width = 64;
  canvas.height = 36;

  let activeInterval = null;
  let sampleHistory = [];

  const attachAutoLuma = (video) => {
    if (video.dataset.autolumaAttached) return;
    video.dataset.autolumaAttached = "true";

    video.style.transition = 'filter 1.5s ease-in-out';

    const resetAndRestart = () => {
      if (activeInterval) clearInterval(activeInterval);
      sampleHistory = [];
      video.style.filter = 'brightness(1)';
      console.log('[AutoLuma] Video state changed: reset analysis.');
      activeInterval = setInterval(analyzeAndLock, SAMPLE_INTERVAL_MS);
    };

    video.addEventListener('loadstart', resetAndRestart);
    video.addEventListener('emptied', resetAndRestart);

    const analyzeAndLock = () => {
      if (video.paused || video.ended || video.readyState < 2) return;

      try {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const data = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
        let totalLuma = 0;

        for (let i = 0; i < data.length; i += 4) {
          totalLuma += 0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2];
        }

        const avgLuma = totalLuma / (data.length / 4);

        // Discard fade-ins / solid black frames
        if (avgLuma < 15) return;

        let multiplier = TARGET_LUMINANCE / Math.max(avgLuma, 30);

        // Strict Floor Rule: Never drop below 100% (1.0), cap boost at 160% (1.6)
        multiplier = Math.min(Math.max(multiplier, 1.0), 1.6);

        sampleHistory.push(multiplier);
        video.style.filter = `brightness(${multiplier.toFixed(2)})`;
        console.log(`[AutoLuma] Sample ${sampleHistory.length}/${SAMPLES_TO_LOCK}: ${(multiplier * 100).toFixed(0)}% (Luma: ${avgLuma.toFixed(1)})`);

        // Lock baseline after reaching target samples
        if (sampleHistory.length >= SAMPLES_TO_LOCK) {
          const sorted = [...sampleHistory].sort((a, b) => a - b);
          const trimmed = sorted.slice(1, -1); // Drop outlier extremes
          let finalMultiplier = trimmed.reduce((a, b) => a + b, 0) / trimmed.length;
          finalMultiplier = Math.max(finalMultiplier, 1.0);

          video.style.filter = `brightness(${finalMultiplier.toFixed(2)})`;
          clearInterval(activeInterval);
          console.log(`[AutoLuma] LOCKED at ${(finalMultiplier * 100).toFixed(0)}% for remainder of video.`);
        }
      } catch (err) {
        clearInterval(activeInterval);
      }
    };

    activeInterval = setInterval(analyzeAndLock, SAMPLE_INTERVAL_MS);
  };

  // Attach to existing players
  document.querySelectorAll('video').forEach(attachAutoLuma);

  // Observe dynamic additions in Single Page Applications (YouTube, etc.)
  const observer = new MutationObserver(() => {
    document.querySelectorAll('video').forEach(attachAutoLuma);
  });

  observer.observe(document.body, { childList: true, subtree: true });
})();
